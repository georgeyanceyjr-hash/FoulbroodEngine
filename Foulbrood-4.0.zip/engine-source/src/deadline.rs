//! Same-frequency deadline checks without repeated tick-to-nanosecond conversion.
use std::time::{Duration, Instant};

#[derive(Clone, Copy)]
pub(crate) struct Deadline {
    instant: Instant,
    #[cfg(target_os = "macos")]
    raw: Option<u64>,
}
impl Deadline {
    pub(crate) fn at(instant: Instant) -> Self {
        Self { instant, #[cfg(target_os = "macos")] raw: mac::deadline_ticks(instant) }
    }
    #[inline(always)]
    pub(crate) fn expired(self) -> bool {
        #[cfg(target_os = "macos")]
        if let Some(deadline) = self.raw { return mac::now() >= deadline; }
        Instant::now() >= self.instant
    }
}

#[cfg(target_os = "macos")]
mod mac {
    use super::*;
    use std::sync::OnceLock;
    #[repr(C)]
    #[derive(Clone, Copy, Default)]
    struct Timebase { numer: u32, denom: u32 }
    unsafe extern "C" {
        fn mach_absolute_time() -> u64;
        fn mach_timebase_info(info: *mut Timebase) -> i32;
    }
    #[inline(always)]
    pub(super) fn now() -> u64 {
        // Apple documents this as the monotonic uptime clock also used by
        // CLOCK_UPTIME_RAW. It does not count machine sleep, matching Instant.
        unsafe { mach_absolute_time() }
    }
    fn timebase() -> Option<Timebase> {
        static INFO: OnceLock<Option<Timebase>> = OnceLock::new();
        *INFO.get_or_init(|| {
            let mut info = Timebase::default();
            let result = unsafe { mach_timebase_info(&mut info) };
            (result == 0 && info.numer != 0 && info.denom != 0).then_some(info)
        })
    }
    fn delta_ticks(duration: Duration, info: Timebase) -> Option<u64> {
        let numerator = duration.as_nanos().checked_mul(u128::from(info.denom))?;
        u64::try_from(numerator / u128::from(info.numer)).ok()
    }
    pub(super) fn deadline_ticks(deadline: Instant) -> Option<u64> {
        let info = timebase()?;
        // Sample ticks BEFORE the Instant anchor. Rounding DOWN and using
        // the later remaining duration can only shorten the original deadline.
        // A preemption between reads also shortens it; it cannot grant time.
        let ticks = now();
        let remaining = deadline.saturating_duration_since(Instant::now());
        ticks.checked_add(delta_ticks(remaining, info)?)
    }
    #[cfg(test)] mod tests {
        use super::*;
        #[test] fn rational_conversion_rounds_down_and_overflow_falls_back() {
            let info = Timebase { numer: 125, denom: 3 };
            for n in [0, 1, 41, 42, 124, 125, 126, 1_000_000] {
                let ticks = delta_ticks(Duration::from_nanos(n), info).unwrap();
                assert!(u128::from(ticks) * 125 <= u128::from(n) * 3);
                assert!(u128::from(ticks + 1) * 125 > u128::from(n) * 3);
            }
            assert!(delta_ticks(Duration::MAX, info).is_none());
        }
        #[test] fn actual_timebase_valid_and_monotonic() {
            assert!(timebase().is_some()); let a=now(); let b=now(); assert!(b>=a);
        }
    }
}

#[cfg(test)] mod tests {
    use super::*;
    #[test] fn zero_and_past_expire_future_does_not() {
        let now=Instant::now(); assert!(Deadline::at(now).expired());
        assert!(Deadline::at(now.checked_sub(Duration::from_millis(1)).unwrap()).expired());
        assert!(!Deadline::at(Instant::now()+Duration::from_secs(1)).expired());
    }
    #[test] fn independent_instant_boundary_never_grants_extra_time() {
        for ns in [1, 20, 42, 500, 10_000, 100_000, 1_000_000] {
            for _ in 0..32 {
                let target=Instant::now()+Duration::from_nanos(ns);
                let deadline=Deadline::at(target);
                while Instant::now()<target { std::hint::spin_loop(); }
                assert!(deadline.expired(),"must expire by the original Instant deadline");
            }
        }
    }
    #[test] fn standard_fallback_keeps_original_deadline() {
        let past=Deadline { instant: Instant::now(), #[cfg(target_os="macos")] raw:None };
        assert!(past.expired());
        let future=Deadline { instant:Instant::now()+Duration::from_secs(1), #[cfg(target_os="macos")] raw:None };
        assert!(!future.expired());
    }
}
