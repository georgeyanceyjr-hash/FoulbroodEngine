// Additive opaque Snapshot transport. This restores the same native state;
// replay is a validation channel and never the source of the restored TT/Board.
impl Snapshot {
    pub fn export_wire(&self, original_hard_unix_ms:u64)->Result<Vec<u8>,String> {
        if self.root_literal.len()>81920 || self.root_raw_history.len()>248 || self.generated_path.len()>64
            || self.tail.len()>4096 || self.full_legal.len()>4096 || self.prefix.len()>4096
            || self.hce_tail.as_ref().is_none_or(|x|x.len()>4096) || self.history.len()>313
            || self.table.len()!=16384 {return Err("Snapshot export envelope".into());}
        if self.transport_original_hard_unix_ms!=Some(original_hard_unix_ms) {
            return Err("export original horizon identity mismatch; no deadline reset".into());
        }
        let mut w=crate::wire::Writer::new();
        w.bytes.extend_from_slice(b"FRSNP001");w.u64(original_hard_unix_ms);
        w.text(&self.root_literal);w.moves(&self.root_raw_history);w.moves(&self.generated_path);
        w.byte(self.depth);w.byte(self.ply);w.i32(self.entry_alpha);w.i32(self.alpha);w.i32(self.beta);
        w.moves(&self.tail);w.moves(&self.full_legal);w.moves(self.hce_tail.as_ref().unwrap());
        w.u32(self.prefix.len() as u32);
        for p in &self.prefix {w.mv(p.raw_move);w.i32(p.entry_alpha);w.i32(p.beta);
            for b in [p.child,p.parent] {w.i32(b.score);w.byte(match b.kind{BoundKind::Exact=>0,BoundKind::Lower=>1,BoundKind::Upper=>2});}}
        self.board.write_wire(&mut w)?;w.u32(self.history.len() as u32);for p in &self.history{p.write_wire(&mut w);}
        w.u32(self.table.len() as u32);
        for entry in &self.table {w.flag(entry.is_some());if let Some(e)=entry{
            w.u64(e.key);e.position.write_wire(&mut w);w.byte(e.depth);w.i32(e.score);
            w.byte(match e.bound{Bound::Exact=>0,Bound::Lower=>1,Bound::Upper=>2});w.optional_move(e.best_move);
        }}
        for pair in self.killers{for mv in pair{w.optional_move(mv);}}
        w.i32(self.total);for c in self.counts{w.byte(c);}w.u64(self.nodes_at_capture);w.finish()
    }
    pub fn import_wire(raw:&[u8],expected_original_hard_unix_ms:u64)->Result<Self,String> {
        let mut r=crate::wire::Reader::new(raw)?;
        if r.take(8)?!=b"FRSNP001"||r.u64()?!=expected_original_hard_unix_ms{return Err("Snapshot version/original horizon mismatch".into());}
        let anchor=Instant::now();
        let now=std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map_err(|e|e.to_string())?.as_millis();
        let remaining=u128::from(expected_original_hard_unix_ms).checked_sub(now).filter(|&x|x>0).ok_or("original Snapshot horizon expired")?;
        let absolute_deadline=anchor.checked_add(Duration::from_millis(u64::try_from(remaining).map_err(|_|"Snapshot horizon overflow")?)).ok_or("Snapshot Instant overflow")?;
        let root_literal=r.text(81920)?;let root_raw_history=r.moves(248)?;let generated_path=r.moves(64)?;
        let depth=r.byte()?;let ply=r.byte()?;let entry_alpha=r.i32()?;let alpha=r.i32()?;let beta=r.i32()?;
        let tail=r.moves(4096)?;let full_legal=r.moves(4096)?;let hce_tail=Some(r.moves(4096)?);
        let n=r.count(4096)?;let mut prefix=Vec::with_capacity(n);
        fn score(r:&mut crate::wire::Reader<'_>)->Result<ScoreBound,String>{let score=r.i32()?;
            let kind=match r.byte()?{0=>BoundKind::Exact,1=>BoundKind::Lower,2=>BoundKind::Upper,_=>return Err("wire bound kind".into())};
            if !(-WIN-1..=WIN+1).contains(&score){return Err("wire score bound".into());}Ok(ScoreBound{score,kind})}
        for _ in 0..n{prefix.push(PrefixResult{raw_move:r.mv()?,entry_alpha:r.i32()?,beta:r.i32()?,child:score(&mut r)?,parent:score(&mut r)?});}
        let board=Board::read_wire(&mut r)?;let n=r.count(313)?;let mut history=Vec::with_capacity(n);
        for _ in 0..n{history.push(Position::read_wire(&mut r)?);}
        if r.count(16384)?!=16384{return Err("wire TT size".into());}
        let mut table=Vec::with_capacity(16384);
        for slot in 0..16384{table.push(if r.flag()?{
            let key=r.u64()?;let position=Position::read_wire(&mut r)?;let depth=r.byte()?;let score=r.i32()?;
            let bound=match r.byte()?{0=>Bound::Exact,1=>Bound::Lower,2=>Bound::Upper,_=>return Err("wire TT bound".into())};
            if key!=position.key()||(key as usize)&16383!=slot||depth>64||!(-WIN-65..=WIN+65).contains(&score){return Err("wire TT depth/score".into());}
            Some(Entry{key,position,depth,score,bound,best_move:r.optional_move()?})
        }else{None});}
        let mut killers=[[None;2];65];for pair in &mut killers{for m in pair{*m=r.optional_move()?;}}
        let total=r.i32()?;let counts=[r.byte()?,r.byte()?];let nodes_at_capture=r.u64()?;r.finish()?;
        let snapshot=Self{root_literal,root_raw_history,generated_path,depth,ply,entry_alpha,alpha,beta,
            tail,full_legal,hce_tail,prefix,board,history,table,killers,total,counts,nodes_at_capture,absolute_deadline,transport_original_hard_unix_ms:Some(expected_original_hard_unix_ms)};
        snapshot.validate_restored()?;Ok(snapshot)
    }
    fn validate_restored(&self)->Result<(),String>{
        use std::collections::HashSet;
        if self.depth!=5||self.ply!=1||self.generated_path.len()!=usize::from(self.ply)
            || self.tail.len()<8||self.alpha>=self.beta||!finite_cutoff_beta(self.beta)
            || !(-WIN-1..=WIN+1).contains(&self.entry_alpha)||self.entry_alpha>self.alpha
            || self.root_raw_history.len()<8{return Err("restored fixed context bounds".into());}
        let header=self.root_literal.split(';').next().ok_or("root header")?;
        let mut replay=UhpGame::new(crate::parse_game_type(header)?);
        for &m in &self.root_raw_history{replay.play_raw(m)?;}
        // Original source notation is retained byte-for-byte. A separate text
        // parse checks its claim, but never supplies/replaces the raw actors.
        let original=UhpGame::from_game_string(&self.root_literal)?;
        if original.history()!=self.root_raw_history || original.exact_position_history()!=replay.exact_position_history()
            || original.game_string()!=self.root_literal {
            return Err("restored original literal independent full-history claim".into());
        }
        for &m in &self.generated_path{replay.play_raw(m)?;}
        if replay.exact_position_history()!=self.history || Position::new(replay.board())!=Position::new(&self.board)
            || replay.board().ply()!=self.board.ply()||replay.board().last_move()!=self.board.last_move()
            || Color::ALL.iter().any(|&c|replay.board().turns_taken(c)!=self.board.turns_taken(c))
            || self.history.last()!=Some(&Position::new(&self.board)) {return Err("restored full native history/Board identity".into());}
        let full:HashSet<_>=self.full_legal.iter().copied().collect();
        let tail:HashSet<_>=self.tail.iter().copied().collect();
        let hce:HashSet<_>=self.hce_tail.as_ref().ok_or("HCE missing")?.iter().copied().collect();
        let prefix:HashSet<_>=self.prefix.iter().map(|p|p.raw_move).collect();
        if full.len()!=self.full_legal.len()||tail.len()!=self.tail.len()||hce!=tail
            || hce.len()!=self.hce_tail.as_ref().unwrap().len()||prefix.len()!=self.prefix.len()
            || !prefix.is_disjoint(&tail)||prefix.union(&tail).copied().collect::<HashSet<_>>()!=full
            || self.board.legal_moves()!=self.full_legal||self.total!=piece_total(&self.board)||self.counts!=queen_counts(&self.board)
            {return Err("restored legal/prefix/tail/evaluation identity".into());}
        for p in &self.prefix {if p.beta!=self.beta||p.entry_alpha>=p.beta||p.parent!=p.child.negate(){return Err("restored prefix bound identity".into());}}
        Ok(())
    }
    pub fn replayed_context(&self)->Result<UhpGame,String>{
        let mut game=UhpGame::new(crate::parse_game_type(self.root_literal.split(';').next().ok_or("root header")?)?);
        for &m in self.root_raw_history.iter().chain(&self.generated_path){game.play_raw(m)?;}Ok(game)
    }
}

#[cfg(test)]mod transport_tests{
    use super::*;
    #[test]fn board_and_position_wire_retain_exact_fixed_storage_and_history(){
        let line=include_str!("../tests/archive_repetition.txt").lines().next().unwrap();
        let mut g=UhpGame::new(crate::GameType::mlp());
        for m in line.split('|').nth(2).unwrap().split(';').take(17){g.play(m).unwrap();}
        let mut b=g.board().clone();let m=b.legal_moves()[0];let undo=b.make_generated(m);b.undo_generated(undo);
        let mut w=crate::wire::Writer::new();b.write_wire(&mut w).unwrap();let raw=w.finish().unwrap();
        let mut r=crate::wire::Reader::new(&raw).unwrap();let restored=Board::read_wire(&mut r).unwrap();r.finish().unwrap();
        assert_eq!(format!("{b:?}"),format!("{restored:?}"));
        for p in g.exact_position_history(){let mut w=crate::wire::Writer::new();p.write_wire(&mut w);let raw=w.finish().unwrap();
            let mut r=crate::wire::Reader::new(&raw).unwrap();assert_eq!(*p,Position::read_wire(&mut r).unwrap());r.finish().unwrap();}
    }
    #[test]fn snapshot_header_and_original_horizon_fail_closed(){
        assert!(Snapshot::import_wire(b"FRSNP002",0).is_err());
        let mut raw=b"FRSNP001".to_vec();raw.extend_from_slice(&1u64.to_le_bytes());
        assert!(Snapshot::import_wire(&raw,1).is_err());assert!(Snapshot::import_wire(&raw,2).is_err());
    }
}
#[cfg(test)]mod snapshot_roundtrip_tests{
    use super::*;
    #[test]fn same_snapshot_roundtrip_preserves_all_nineteen_fields_tt_killers_and_actors(){
        let line=include_str!("../tests/archive_repetition.txt").lines().next().unwrap();
        let mut root=UhpGame::new(crate::GameType::mlp());
        for m in line.split('|').nth(2).unwrap().split(';').take(17){root.play(m).unwrap();}
        let root_literal=root.game_string();let root_raw_history=root.history().to_vec();
        let mut canonical=UhpGame::new(crate::GameType::mlp());
        for &mv in &root_raw_history{canonical.play_raw(mv).unwrap();}
        assert_ne!(root_literal,canonical.game_string(),"fixture retains alternate valid source notation");
        let mv=root.board().legal_moves()[0];root.play_raw(mv).unwrap();
        let board=root.board().clone();let full=board.legal_moves();assert!(full.len()>=8);
        let mut hce=full.clone();hce.reverse();let position=Position::new(&board);
        let mut table=vec![None;16384];table[(position.key() as usize)&16383]=Some(Entry{
            key:position.key(),position,depth:4,score:-19,bound:Bound::Upper,best_move:full.first().copied()});
        let mut killers=[[None;2];65];killers[1]=[full.first().copied(),full.get(1).copied()];
        let hard=(std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_millis()+60_000) as u64;
        let s=Snapshot{root_literal,root_raw_history,generated_path:vec![mv],depth:5,ply:1,entry_alpha:-22,
            alpha:-19,beta:27,tail:full.clone(),full_legal:full,hce_tail:Some(hce),prefix:Vec::new(),
            history:root.exact_position_history().to_vec(),table,killers,total:piece_total(&board),counts:queen_counts(&board),
            board,nodes_at_capture:87,absolute_deadline:Instant::now()+Duration::from_secs(60),transport_original_hard_unix_ms:Some(hard)};
        let wire=s.export_wire(hard).unwrap();let restored=Snapshot::import_wire(&wire,hard).unwrap();
        assert_eq!(s.state_text(),restored.state_text());assert_eq!(s.raw_descriptors_json(),restored.raw_descriptors_json());
        assert_eq!(s.features(0).unwrap(),restored.features(0).unwrap());
        let mut trailing=wire.clone();trailing.push(0);assert!(Snapshot::import_wire(&trailing,hard).is_err());
        assert!(Snapshot::import_wire(&wire[..wire.len()-1],hard).is_err());
        assert!(s.export_wire(hard+5000).is_err());
    }
}


#[cfg(test)]mod wide_counter_export_contract {
    use super::*;
    #[test]
    fn snapshot_export_propagates_explicit_legacy_counter_error_without_partial_blob() {
        // Deliberately unrepresentable storage fixture, not a legal capture or
        // a new Snapshot admission envelope. Existing313-history cap stays exact.
        let mut board=Board::new(crate::GameType::mlp());
        for _ in 0..511{board.make_unchecked(HiveMove::Pass).unwrap();}
        let hard=std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_millis()as u64+60_000;
        let snapshot=Snapshot{root_literal:"Base+MLP;NotStarted;White[1]".into(),root_raw_history:vec![],generated_path:vec![],
            depth:5,ply:1,entry_alpha:-20,alpha:-10,beta:10,tail:vec![],full_legal:vec![],hce_tail:Some(vec![]),prefix:vec![],
            history:vec![],table:vec![None;16384],killers:[[None;2];65],total:piece_total(&board),counts:queen_counts(&board),
            board,nodes_at_capture:0,absolute_deadline:Instant::now()+Duration::from_secs(60),transport_original_hard_unix_ms:Some(hard)};
        let error=snapshot.export_wire(hard).unwrap_err();assert!(error.contains("legacy Snapshot White turn exceeds255"));
    }
}
