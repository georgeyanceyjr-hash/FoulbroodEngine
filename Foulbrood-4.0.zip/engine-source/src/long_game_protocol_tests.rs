//! KnownDEV counter-boundary contracts. No model fitting or strength inference.
use super::*;
use crate::search::SearchLimit;

fn long_game()->UhpGame {
    let mut game=UhpGame::new(GameType::mlp());
    for line in include_str!("../tests/long_game_raw_history.txt").lines() {
        game.play_raw(raw_move_from_fields(line).unwrap()).unwrap();
    }
    assert_eq!(game.history().len(),510);game
}
fn next_nonterminal(game:&UhpGame)->(HiveMove,UhpGame) {
    // A structural engineering fixture extension only. No evaluation/search,
    // recommendation ranking, counterfactual saving claim or training label.
    for mv in game.board().legal_moves() {
        let mut child=game.clone();child.play_raw(mv).unwrap();
        if child.state()==GameState::InProgress{return(mv,child);}
    }
    panic!("KnownDEV fixture has no nonterminal raw extension for counter test");
}

#[test]
fn exact_raw_history_headers_probe_live_commit_and_undo_cross_510_511_512() {
    let mut game=long_game();let before=game.raw_state_json();
    assert_eq!((game.board().turns_taken(Color::White),game.board().turns_taken(Color::Black)),(255,255));
    for (ply,turns,header) in [(511,[256,255],"Black[256]"),(512,[256,256],"White[257]"),(513,[257,256],"Black[257]")] {
        let(mv,expected)=next_nonterminal(&game);
        let mut engine=UhpEngine{game:game.clone(),..UhpEngine::default()};
        let probe=engine.execute(&format!("probe_raw {}",raw_move_fields(mv)));
        assert_eq!(probe.len(),1);assert!(probe[0].contains(&format!("\"raw_move\":{}",crate::search::residual::raw_action_json(mv))));
        assert!(probe[0].contains(&format!("\"board\":{}",expected.raw_board_json())));
        assert!(probe[0].contains(&format!("\"current_position\":{}",expected.witness_current_position_json())));
        assert_eq!(engine.execute("state_raw"),vec![game.raw_state_json()]);
        assert_eq!(engine.execute(&format!("play_raw {}",raw_move_fields(mv))),vec![expected.raw_state_json()]);
        game.play_raw(mv).unwrap();assert_eq!(game.raw_state_json(),expected.raw_state_json());
        assert_eq!(game.board().ply(),ply);assert_eq!(game.history().len(),usize::from(ply));
        assert_eq!(game.positions.len(),usize::from(ply)+1);
        assert_eq!([game.board().turns_taken(Color::White),game.board().turns_taken(Color::Black)],turns);
        assert_eq!(game.turn_string(),header);
        assert_eq!(game.positions.last(),Some(&Position::new(game.board())));
    }
    game.undo(3).unwrap();assert_eq!(game.raw_state_json(),before);
}

#[test]
fn full_long_history_serial_and_parallel_scores_and_counter_state_agree() {
    let mut game=long_game();for _ in 0..3{game=next_nonterminal(&game).1;}
    let before=game.raw_state_json();let serial=game.search(SearchLimit::Depth(2));
    assert!(serial.score.is_some());
    for threads in [1,2,4] {
        let run=game.search_with_threads(SearchLimit::Depth(2),threads).unwrap();
        assert_eq!(run.result.completed_depth,serial.completed_depth);assert_eq!(run.result.score,serial.score);
        assert_eq!(run.stats.spawned_threads,run.stats.joined_threads);
        assert_eq!(run.stats.worker_nodes.iter().sum::<u64>(),run.result.nodes);
        assert!(game.board().legal_moves().contains(&run.result.best_move.unwrap()));
        assert_eq!(game.raw_state_json(),before);
    }
}
