//! Fixed TRAIN-only residual model. Exploration order changes; values do not.
use super::*;
use std::cell::Cell;

mod weights { include!("trained_weights.rs"); }
pub const MODEL_SHA256: &str = weights::MODEL_SHA256;
pub const FEATURE_COUNT: usize = weights::FEATURE_COUNT;

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct Stats { pub applications: u64, pub moves_ranked: u64, pub changed_orders: u64 }
thread_local! { static STATS: Cell<Stats> = Cell::new(Stats::default()); }

pub fn mode() -> &'static str {
    match option_env!("FOULBROOD_RESIDUAL_ORDER") {
        None | Some("") => "original",
        Some("trained") => "trained",
        Some(_) => "INVALID_COMPILE_MODE",
    }
}
pub fn enabled() -> bool { mode() == "trained" }
pub fn model_sha256() -> Option<&'static str> { enabled().then_some(MODEL_SHA256) }
pub fn stats() -> Stats { if enabled() { STATS.with(Cell::get) } else { Stats::default() } }
pub(super) fn start_search() {
    assert!(mode() != "INVALID_COMPILE_MODE", "Unknown FOULBROOD_RESIDUAL_ORDER compile value");
    if enabled() {
        model().validate().expect("Invalid frozen TRAIN model; no fallback");
        STATS.with(|s| s.set(Stats::default()));
    }
}

/// Coordinator-only telemetry merge after a worker is joined. No search state,
/// values, move order or weights cross this channel.
pub(super) fn merge_worker_stats(other: Stats) {
    if enabled() { STATS.with(|cell| { let mut v=cell.get();
        v.applications=v.applications.checked_add(other.applications).expect("model application counter overflow");
        v.moves_ranked=v.moves_ranked.checked_add(other.moves_ranked).expect("model move counter overflow");
        v.changed_orders=v.changed_orders.checked_add(other.changed_orders).expect("model order counter overflow");
        cell.set(v);
    }); }
}

#[derive(Clone, Copy)]
struct Model<'a> {
    mean: &'a [f64; FEATURE_COUNT], scale: &'a [f64; FEATURE_COUNT],
    refuter: &'a [f64; FEATURE_COUNT], cost: &'a [f64; FEATURE_COUNT],
}
fn model() -> Model<'static> {
    Model { mean: &weights::MEAN, scale: &weights::SCALE,
        refuter: &weights::REFUTER, cost: &weights::LOG_NODE_COST }
}
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Prediction {
    pub probability: f64, pub log_node_cost: f64, pub predicted_cost: f64, pub priority: f64,
}
impl Model<'_> {
    fn validate(self) -> Result<(), String> {
        if self.mean.iter().chain(self.scale).chain(self.refuter).chain(self.cost).any(|x| !x.is_finite())
            || self.scale.iter().any(|&x| x <= 0.0) {
            return Err("finite exact22 arrays and positive TRAIN scales required".into());
        }
        Ok(())
    }
    fn predict(self, features: &[f64; FEATURE_COUNT]) -> Result<Prediction, String> {
        let mut logit = 0.0;
        let mut log_cost = 0.0;
        for i in 0..FEATURE_COUNT {
            if !features[i].is_finite() { return Err("nonfinite actual shared feature".into()); }
            let normalized = (features[i] - self.mean[i]) / self.scale[i];
            logit += normalized * self.refuter[i];
            log_cost += normalized * self.cost[i];
        }
        if !logit.is_finite() || !log_cost.is_finite() { return Err("nonfinite model dot product".into()); }
        // Frozen numerical safety contract, not validation-driven tuning.
        let probability = 1.0 / (1.0 + (-logit.clamp(-30.0, 30.0)).exp());
        let predicted_cost = log_cost.clamp(0.0, 20.0).exp_m1().max(1.0);
        let priority = probability / predicted_cost;
        if !priority.is_finite() { return Err("nonfinite complete priority".into()); }
        Ok(Prediction { probability, log_node_cost: log_cost, predicted_cost, priority })
    }
}
/// Pure numeric parity surface; it never generates a move or changes a board.
pub fn predict_features(features: &[f64; FEATURE_COUNT]) -> Result<Prediction, String> {
    model().validate()?;
    model().predict(features)
}

fn eligible(board: &Board, depth: u8, ply: u8, beta: i32, tail: usize) -> bool {
    board.game_type() == crate::GameType::mlp() && depth == 5 && ply == 1 && tail >= 8
        && beta.abs() < WIN - i32::from(MAX_DEPTH)
        && Color::ALL.iter().all(|&side| board.location(Piece::new(side, Bug::Queen, 1)).is_some())
}

pub(super) fn apply(worker: &Search, board: &Board, tail: &mut [HiveMove], depth: u8,
    ply: u8, alpha: i32, beta: i32, prefix_count: usize) -> Result<(), ()> {
    if !enabled() || !eligible(board, depth, ply, beta, tail.len()) { return Ok(()); }
    if worker.expired() { return Err(()); }
    // Exact same Position/key and feature implementation as Snapshot::features.
    let position = Position::new(board);
    let key = position.key();
    let tt_hit = !worker.table.is_empty() && worker.table[key as usize & (worker.table.len()-1)]
        .is_some_and(|e| e.key == key && e.position == position);
    let mut ranked = Vec::with_capacity(tail.len());
    for (hce_index, &mv) in tail.iter().enumerate() {
        if worker.expired() { return Err(()); }
        let features = residual::feature_vector(board, mv, depth, ply, alpha, beta,
            prefix_count, hce_index, tail.len(), tt_hit);
        let prediction = model().predict(&features).expect("Invalid actual model prediction; no fallback");
        ranked.push((prediction.priority, hce_index, mv));
    }
    ranked.sort_by(|a,b| b.0.total_cmp(&a.0).then_with(|| a.1.cmp(&b.1)));
    if worker.expired() { return Err(()); }
    let changed = ranked.iter().zip(tail.iter()).any(|(row, mv)| row.2 != *mv);
    // Only a complete ranking is committed, preserving every exact raw actor.
    for (slot, (_, _, mv)) in tail.iter_mut().zip(ranked) { *slot = mv; }
    STATS.with(|s| { let mut v=s.get(); v.applications+=1; v.moves_ranked+=tail.len() as u64;
        v.changed_orders+=u64::from(changed); s.set(v); });
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn analytical_two_head_predictions_and_safety_clamps() {
        let mean=[0.0;22]; let scale=[1.0;22]; let mut r=[0.0;22]; let mut c=[0.0;22];
        let mut x=[0.0;22];x[0]=1.0;
        let p=Model{mean:&mean,scale:&scale,refuter:&r,cost:&c}.predict(&x).unwrap();
        assert_eq!((p.probability,p.predicted_cost,p.priority),(0.5,1.0,0.5));
        r[0]=3.0_f64.ln();c[0]=5.0_f64.ln();
        let p=Model{mean:&mean,scale:&scale,refuter:&r,cost:&c}.predict(&x).unwrap();
        assert!((p.probability-0.75).abs()<1e-14 && (p.predicted_cost-4.0).abs()<1e-13);
        assert!((p.priority-0.1875).abs()<1e-14);
        r[0]=1000.0;c[0]=1000.0;
        let p=Model{mean:&mean,scale:&scale,refuter:&r,cost:&c}.predict(&x).unwrap();
        assert_eq!(p.predicted_cost,20.0_f64.exp_m1()); assert!(p.probability<1.0);
        c[0]=-1000.0;
        assert_eq!(Model{mean:&mean,scale:&scale,refuter:&r,cost:&c}.predict(&x).unwrap().predicted_cost,1.0);
    }
    #[test]
    fn nonfinite_inputs_and_invalid_scales_are_fatal_not_zero_rank() {
        let mean=[0.0;22];let mut scale=[1.0;22];let w=[0.0;22];let mut x=[0.0;22];
        scale[3]=0.0;assert!(Model{mean:&mean,scale:&scale,refuter:&w,cost:&w}.validate().is_err());
        x[2]=f64::NAN;assert!(predict_features(&x).is_err());
    }
    fn game()->crate::UhpGame {
        let line=include_str!("../tests/archive_repetition.txt").lines().next().unwrap();
        let mut game=crate::UhpGame::new(crate::GameType::mlp());
        for m in line.split('|').nth(2).unwrap().split(';').take(18){game.play(m).unwrap();}
        game
    }
    #[test]
    fn admission_and_deadline_leave_unadmitted_tail_and_full_history_unchanged() {
        let game=game();let board=game.board();let mut tail=board.legal_moves();assert!(tail.len()>=8);
        assert!(eligible(board,5,1,16,tail.len()));
        for(d,p,b,n)in[(4,1,16,8),(6,1,16,8),(5,2,16,8),(5,1,WIN+1,8),(5,1,16,7)]{
            assert!(!eligible(board,d,p,b,n));}
        let worker=Search{history:Some(game.exact_position_history().to_vec()),table:vec![None;16384],
            killers:[[None;2];65],deadline:Some(crate::deadline::Deadline::at(Instant::now())),nodes:0,node_limit:None};
        let before=tail.clone();let history=worker.history.clone();
        assert_eq!(apply(&worker,board,&mut tail,5,1,-12,16,0).is_err(),enabled());
        assert_eq!(tail,before);assert_eq!(worker.history,history);
    }
    #[test]
    fn complete_runtime_order_preserves_raw_membership_prefix_board_and_history() {
        let game=game();let board=game.board();let full=board.legal_moves();assert!(full.len()>=10);
        let prefix=full[..2].to_vec();let mut tail=full[2..].to_vec();
        let worker=Search{history:Some(game.exact_position_history().to_vec()),table:vec![None;16384],
            killers:[[None;2];65],deadline:None,nodes:0,node_limit:None};
        worker.order_moves(&mut board.clone(),&mut tail,1).unwrap();
        let before=tail.clone();let physical=format!("{board:?}");let history=worker.history.clone();
        start_search();apply(&worker,board,&mut tail,5,1,-12,16,2).unwrap();
        let mut actual=prefix.clone();actual.extend(tail.iter().copied());
        assert_eq!(actual.len(),full.len());
        for mv in &full{assert_eq!(actual.iter().filter(|&m|m==mv).count(),1);}
        assert_eq!(prefix,full[..2]);assert_eq!(format!("{board:?}"),physical);assert_eq!(worker.history,history);
        if enabled(){assert_eq!(stats().applications,1);assert_eq!(stats().moves_ranked,tail.len() as u64);}
        else{assert_eq!(tail,before);assert_eq!(stats(),Stats::default());}
    }
}
