//! Experimental consequences of Groundwork concepts, not named-pattern bonuses.
//! Nonmoving-side features are structural potential after a hypothetical pass;
//! they do not assert that the opponent cannot change the position first.
use crate::{Board, Bug, Color, HiveMove, Piece};

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct Features {
    pub mobile: [u8; 8],
    pub pressure_cells: u8,
    pub pressure_pieces: u8,
    pub queen_exits: u8,
    pub queen_cover: bool,
    pub pillbug_cover: bool,
    pub queen_recovery: bool,
}

pub fn features(board: &Board, color: Color) -> Features {
    let mut f=Features::default();
    if board.game_over() {return f;}
    let mut turn=board.clone();
    if turn.side_to_move()!=color {turn.make_generated(HiveMove::Pass);}
    let own_q=Piece::new(color,Bug::Queen,1);
    let enemy_q=Piece::new(color.other(),Bug::Queen,1);
    let enemy_p=Piece::new(color.other(),Bug::Pillbug,1);
    let own=turn.location(own_q);let enemy=turn.location(enemy_q);
    let old_ring=own.map_or(0,|q|q.neighbors().iter().filter(|&&h|turn.is_occupied(h)).count());
    let mut mobile=0_u32;let mut pressure=0_u32;let mut cells=0_u8;
    let mut exits=Vec::new();
    for mv in turn.legal_moves() {
        let (piece,from,to)=match mv {
            HiveMove::Place{piece,to}=>(piece,None,to),
            HiveMove::Move{piece,from,to}=>{mobile|=1<<piece.id();(piece,Some(from),to)},
            HiveMove::Pillbug{piece,from,to,..}=>(piece,Some(from),to),
            HiveMove::Pass=>continue,
        };
        // One actual move can reach many cells. Retain both distinct cells and
        // distinct resources, rather than counting every equivalent notation.
        if piece.color==color {
            if let Some(q)=enemy {
                let vacates=from.is_some_and(|h|h.distance(q)==1 && turn.stack_height(h)==1);
                if !vacates && !turn.is_occupied(to) {
                    if let Some(i)=q.neighbors().iter().position(|&h|h==to) {
                        cells|=1<<i;pressure|=1<<piece.id();
                    }
                }
            }
            // Only actual legal covering moves count, including a Mosquito
            // acting as a Beetle. Placement cannot cover an occupied cell.
            if from.is_some() {
                f.queen_cover |= turn.top(to)==Some(enemy_q);
                f.pillbug_cover |= turn.top(to)==Some(enemy_p);
                f.queen_recovery |= own==Some(to) && turn.top(to).is_some_and(|p|p.color!=color);
            }
        }
        if piece==own_q {
            let after=to.neighbors().iter().filter(|&&h|Some(h)!=from && turn.is_occupied(h)).count();
            if after<old_ring && !exits.contains(&to) {exits.push(to);}
        }
    }
    for (i,bug) in Bug::ALL.into_iter().enumerate() {
        for n in 1..=bug.copies() {
            if mobile & (1<<Piece::new(color,bug,n).id())!=0 {f.mobile[i]+=1;}
        }
    }
    f.pressure_cells=cells.count_ones() as u8;
    f.pressure_pieces=pressure.count_ones() as u8;
    f.queen_exits=exits.len().min(2) as u8;
    f
}

pub fn control(f: &Features)->i32 {
    Bug::ALL.into_iter().enumerate().map(|(i,b)| i32::from(f.mobile[i])*match b {
        Bug::Queen=>0, Bug::Ant=>12, Bug::Mosquito=>10, Bug::Beetle=>8, _=>4,
    }).sum()
}
pub fn access(f: &Features)->i32 {
    6*i32::from(f.pressure_cells)+4*i32::from(f.pressure_pieces.min(3))+8*i32::from(f.queen_exits)
}
pub fn beetle(f: &Features)->i32 {
    20*i32::from(f.queen_cover)+24*i32::from(f.pillbug_cover)+20*i32::from(f.queen_recovery)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{GameType,Hex};
    fn put(b:&mut Board,p:Piece,h:Hex) {
        if b.side_to_move()!=p.color {b.make_generated(HiveMove::Pass);}
        b.make_unchecked(HiveMove::Place{piece:p,to:h}).unwrap();
    }
    #[test]
    fn connected_ant_can_move_but_connector_cannot() {
        let mut b=Board::new(GameType::mlp());
        put(&mut b,Piece::new(Color::White,Bug::Queen,1),Hex::new(0,0));
        put(&mut b,Piece::new(Color::White,Bug::Ant,1),Hex::new(1,0));
        put(&mut b,Piece::new(Color::Black,Bug::Queen,1),Hex::new(2,0));
        b.make_generated(HiveMove::Pass);
        let ant=Bug::ALL.iter().position(|&b|b==Bug::Ant).unwrap();
        assert_eq!(features(&b,Color::White).mobile[ant],0);
        put(&mut b,Piece::new(Color::White,Bug::Spider,1),Hex::new(1,-1));
        put(&mut b,Piece::new(Color::White,Bug::Spider,2),Hex::new(2,-1));
        b.make_generated(HiveMove::Pass);
        assert_eq!(features(&b,Color::White).mobile[ant],1);
    }
    #[test]
    fn legal_beetle_cover_and_recovery_are_distinct() {
        for color in Color::ALL {
            let mut b=Board::new(GameType::mlp());
            let own=Piece::new(color,Bug::Queen,1);
            let enemy=Piece::new(color.other(),Bug::Queen,1);
            let beetle=Piece::new(color,Bug::Beetle,1);
            put(&mut b,own,Hex::new(0,0));put(&mut b,enemy,Hex::new(1,0));
            put(&mut b,beetle,Hex::new(0,1));b.make_generated(HiveMove::Pass);
            let f=features(&b,color);assert!(f.queen_cover);assert!(!f.queen_recovery);
            let attacker=Piece::new(color.other(),Bug::Beetle,1);
            put(&mut b,attacker,Hex::new(10,10));
            if b.side_to_move()!=attacker.color {b.make_generated(HiveMove::Pass);}
            b.make_unchecked(HiveMove::Move{piece:attacker,from:Hex::new(10,10),to:Hex::new(0,0)}).unwrap();
            assert!(features(&b,color).queen_recovery);
        }
    }
    #[test]
    fn extraction_does_not_mutate_board_and_is_bounded() {
        for line in include_str!("../tests/groundwork_positions.txt").lines() {
            let game=crate::UhpGame::from_game_string(line).unwrap();let b=game.board();
            let before=crate::position::Position::new(b);
            for c in Color::ALL {
                let f=features(b,c);
                let resources=crate::movement::groundwork_resources(b,c,false);
                assert_eq!(f.mobile,resources.mobile);
                let cover=crate::movement::groundwork_resources(b,c,true);
                assert_eq!((f.queen_cover,f.pillbug_cover,f.queen_recovery),(cover.queen_cover,cover.pillbug_cover,cover.queen_recovery));
                assert!(f.pressure_cells<=6 && f.pressure_pieces<=14 && f.queen_exits<=2);
                for (i,bug) in Bug::ALL.into_iter().enumerate(){assert!(f.mobile[i]<=bug.copies());}
            }
            assert_eq!(before,crate::position::Position::new(b));
        }
    }
}
