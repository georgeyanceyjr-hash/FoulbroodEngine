//! Opt-in counts ONLY. No Snapshot, child probes, model, or search-state writes.
use super::*;
use crate::UhpGame;
use std::cell::RefCell;

const AXIS: usize = 7; // Fixed D6: iterations/depths/plies are 0..=6.
const MASKS: usize = 128;
const LABELS: [&str; 24] = [
    "entries", "entry_expired", "repetition_return", "inner_entries",
    "leaf_return", "terminal_return", "tt_score_return", "preferred_cutoff",
    "tail_cutoff", "tail_exhausted", "interrupted_before_tail", "interrupted_after_tail",
    "residual_entered", "tail_order_ready", "preferred_absent", "preferred_duplicate",
    "preferred_illegal", "preferred_legal", "preferred_child_completed",
    "preferred_child_interrupted", "tail_child_interrupted", "tt_checked", "tt_hit", "tt_hint_some",
];

#[derive(Clone, Copy)]
pub(super) enum Count {
    Entry, EntryExpired, Repetition, Inner, Leaf, Terminal, TtReturn, PreferredCutoff,
    TailCutoff, TailExhausted, InterruptedBefore, InterruptedAfter, Residual, Hce,
    PreferredAbsent, PreferredDuplicate, PreferredIllegal, PreferredLegal,
    PreferredCompleted, PreferredInterrupted, TailInterrupted, TtChecked, TtHit, TtHint,
}

#[derive(Clone)]
pub struct Bucket {
    pub iteration: u8,
    pub depth: u8,
    pub ply: u8,
    pub counts: [u64; 24],
    pub predicate_masks: [u64; MASKS],
    pub full_raw_sum: u64,
    pub tail_raw_sum: u64,
    pub tried_prefix_sum: u64,
    pub preferred_cutoff_by_slot: [u64; 3],
}

impl Bucket {
    fn new(iteration: u8, depth: u8, ply: u8) -> Self {
        Self { iteration, depth, ply, counts: [0; 24], predicate_masks: [0; MASKS],
               full_raw_sum: 0, tail_raw_sum: 0, tried_prefix_sum: 0,
               preferred_cutoff_by_slot: [0; 3] }
    }
    fn add(&mut self, count: Count) -> Result<(), String> {
        let cell = &mut self.counts[count as usize];
        *cell = cell.checked_add(1).ok_or("census counter overflow")?;
        Ok(())
    }
    fn accounting_errors(&self) -> Vec<String> {
        let n = &self.counts;
        let mut errors = Vec::new();
        if n[0] != n[1] + n[2] + n[3] { errors.push("parts entry partition".into()); }
        if n[3] != n[4] + n[5] + n[6] + n[7] + n[8] + n[9] + n[10] + n[11] {
            errors.push("inner exit partition".into());
        }
        if n[12] != self.predicate_masks.iter().sum::<u64>() { errors.push("residual mask partition".into()); }
        if n[12] != n[8] + n[9] + n[11] { errors.push("residual outcome partition".into()); }
        if n[13] > n[12] { errors.push("HCE finished exceeds residual entry".into()); }
        if n[7] != self.preferred_cutoff_by_slot.iter().sum::<u64>() { errors.push("preferred cutoff slot partition".into()); }
        errors
    }
    fn json(&self) -> String {
        let counts = LABELS.iter().zip(self.counts).map(|(k,v)| format!("\"{k}\":{v}"))
            .collect::<Vec<_>>().join(",");
        let masks = self.predicate_masks.iter().enumerate().filter(|(_,v)| **v != 0)
            .map(|(i,v)| format!("{{\"mask\":{i},\"count\":{v}}}")).collect::<Vec<_>>().join(",");
        format!("{{\"iteration\":{},\"depth\":{},\"ply\":{},\"counts\":{{{counts}}},\"predicate_masks\":[{masks}],\"old_recipe_static_eligible\":{},\"full_raw_sum\":{},\"tail_raw_sum\":{},\"tried_prefix_sum\":{},\"preferred_cutoff_by_slot\":{:?}}}",
                self.iteration,self.depth,self.ply,self.predicate_masks[0],self.full_raw_sum,self.tail_raw_sum,self.tried_prefix_sum,
                self.preferred_cutoff_by_slot)
    }
}

struct State {
    end: Instant,
    iteration: u8,
    iterations_started: Vec<u8>,
    buckets: Vec<Bucket>,
    deadline_observed: bool,
    error: Option<String>,
    path: Vec<HiveMove>,
}
thread_local! { static ACTIVE: RefCell<Option<State>> = const { RefCell::new(None) }; }

/// The census is single-threaded; parallel entry must reject an active observer.
pub(super) fn is_active() -> bool { ACTIVE.with(|cell| cell.borrow().is_some()) }

fn index(iteration:u8, depth:u8, ply:u8)->Result<usize,String> {
    if iteration as usize >= AXIS || depth as usize >= AXIS || ply as usize >= AXIS {
        return Err("census coordinate outside fixedD6 envelope".into());
    }
    Ok((iteration as usize * AXIS + depth as usize) * AXIS + ply as usize)
}

fn update(depth:u8, ply:u8, action:impl FnOnce(&mut Bucket)->Result<(),String>) {
    ACTIVE.with(|cell| {
        let mut state = cell.borrow_mut();
        let Some(s) = state.as_mut() else { return; };
        let outcome = index(s.iteration,depth,ply).and_then(|i| action(&mut s.buckets[i]));
        if let Err(error) = outcome { s.error = Some(error); }
    });
}

pub(super) fn count(depth:u8,ply:u8,value:Count) {
    if matches!(value,Count::Entry) {
        ACTIVE.with(|cell|if let Some(s)=cell.borrow_mut().as_mut() {
            if s.path.len()!=usize::from(ply) {s.error=Some("census raw path/search ply mismatch".into());}
        });
    }
    update(depth,ply,|b|b.add(value));
}
pub(super) fn push(mv:HiveMove) {
    ACTIVE.with(|cell|if let Some(s)=cell.borrow_mut().as_mut() {
        if s.path.len()>=6 {s.error=Some("fixedD6 path cap".into());}
        else {s.path.push(mv);}
    });
}
pub(super) fn pop(mv:HiveMove) {
    ACTIVE.with(|cell|if let Some(s)=cell.borrow_mut().as_mut() {
        if s.path.pop()!=Some(mv) {s.error=Some("census raw path unwind mismatch".into());}
    });
}
pub(super) fn iteration(depth:u8) {
    ACTIVE.with(|cell| if let Some(s)=cell.borrow_mut().as_mut() {
        s.iteration=depth; s.iterations_started.push(depth);
    });
}
pub(super) fn fail(error:String) {
    ACTIVE.with(|cell| if let Some(s)=cell.borrow_mut().as_mut() { s.error=Some(error); });
}
pub(super) fn phase_expired()->bool {
    ACTIVE.with(|cell| {
        let mut state=cell.borrow_mut();
        let Some(s)=state.as_mut() else{return false;};
        if Instant::now()>=s.end {s.deadline_observed=true;}
        s.deadline_observed || s.error.is_some()
    })
}

/// Independent mask, not short-circuit first-reason attribution. Zero matches
/// ALL unchanged old static predicates; no first-match suppression or snapshot.
pub fn predicate_mask(depth:u8,ply:u8,tail:usize,beta:i32,queens:[bool;2])->usize {
    usize::from(depth!=5) | (usize::from(ply!=1)<<1) | (usize::from(tail<8)<<2)
        | (usize::from(beta<=-WIN+i32::from(MAX_DEPTH))<<3)
        | (usize::from(beta>=WIN-i32::from(MAX_DEPTH))<<4)
        | (usize::from(!queens[0])<<5) | (usize::from(!queens[1])<<6)
}

pub(super) fn residual(depth:u8,ply:u8,full:usize,tried:usize,tail:usize,
                       alpha:i32,beta:i32,queens:[bool;2]) {
    update(depth,ply,|b| {
        b.add(Count::Residual)?;
        let mask=predicate_mask(depth,ply,tail,beta,queens);
        b.predicate_masks[mask]=b.predicate_masks[mask].checked_add(1).ok_or("mask count overflow")?;
        b.full_raw_sum=b.full_raw_sum.checked_add(full as u64).ok_or("raw count overflow")?;
        b.tail_raw_sum=b.tail_raw_sum.checked_add(tail as u64).ok_or("tail count overflow")?;
        b.tried_prefix_sum=b.tried_prefix_sum.checked_add(tried as u64).ok_or("prefix count overflow")?;
        if full.checked_sub(tail)!=Some(tried) || alpha>=beta {return Err("residual raw-count/window contract".into());}
        Ok(())
    });
}
pub(super) fn preferred_cutoff(depth:u8,ply:u8,slot:usize) {
    update(depth,ply,|b| {
        b.add(Count::PreferredCutoff)?;
        let cell=b.preferred_cutoff_by_slot.get_mut(slot).ok_or("preferred source slot")?;
        *cell=cell.checked_add(1).ok_or("preferred count overflow")?;
        Ok(())
    });
}

pub struct CensusRun {
    pub result: SearchResult,
    pub buckets: Vec<Bucket>,
    pub iterations_started: Vec<u8>,
    pub deadline_observed: bool,
    pub error: Option<String>,
    pub accounting_errors: Vec<String>,
    pub complete: bool,
}
impl CensusRun {
    pub fn json(&self)->String {
        let rows=self.buckets.iter().filter(|b|b.counts.iter().any(|n|*n!=0))
            .map(Bucket::json).collect::<Vec<_>>().join(",");
        let error=self.error.as_ref().map_or("null".to_string(),|s|json_string(s));
        let errors=self.accounting_errors.iter().map(|s|json_string(s)).collect::<Vec<_>>().join(",");
        format!("{{\"counts_only\":true,\"snapshot_capture\":false,\"child_probes\":0,\"labels\":0,\"complete\":{},\"completed_depth\":{},\"nodes\":{},\"deadline_observed\":{},\"error\":{error},\"accounting_errors\":[{errors}],\"iterations_started\":{:?},\"predicate_mask_bits\":[\"depth_not5\",\"ply_not1\",\"tail_lt8\",\"beta_le_negative_band\",\"beta_ge_positive_band\",\"WhiteQ_absent\",\"BlackQ_absent\"],\"buckets\":[{rows}]}}",
            self.complete,self.result.completed_depth,self.result.nodes,self.deadline_observed,
            self.iterations_started)
    }
}

pub fn json_string(s:&str)->String {
    let mut out=String::from("\"");
    for c in s.chars() {match c {
        '"'=>out.push_str("\\\""),'\\'=>out.push_str("\\\\"),'\n'=>out.push_str("\\n"),
        '\r'=>out.push_str("\\r"),'\t'=>out.push_str("\\t"),
        c if c<' '=>out.push_str(&format!("\\u{:04x}",c as u32)),c=>out.push(c),
    }}
    out.push('"');out
}

/// Full actual history only. The observer owns counters, NEVER search state.
pub fn census(game:&UhpGame,end:Instant,mut progress:impl FnMut(&SearchResult)->Result<(),String>)->Result<CensusRun,String> {
    if end<=Instant::now() || game.game_string().split(';').next().is_some_and(|s|s.contains('~'))
        || game.history().len()!=usize::from(game.board().ply()) || !(8..=248).contains(&game.history().len()) {
        return Err("fresh deadline/full actual8..248ply history required".into());
    }
    if super::residual::is_active() {return Err("old snapshot observer must be inactive".into());}
    ACTIVE.with(|cell| {
        let mut state=cell.borrow_mut();
        if state.is_some(){return Err("nested census prohibited".to_string());}
        let mut buckets=Vec::with_capacity(AXIS*AXIS*AXIS);
        for iteration in 0..AXIS {for depth in 0..AXIS {for ply in 0..AXIS {
            buckets.push(Bucket::new(iteration as u8,depth as u8,ply as u8));
        }}}
        *state=Some(State{end,iteration:0,iterations_started:Vec::new(),buckets,deadline_observed:false,error:None,path:Vec::new()});
        Ok(())
    })?;
    let result=game.search_with_progress(SearchLimit::Depth(6),|row| {
        if let Err(error)=progress(row) {fail(format!("durable progress callback: {error}"));}
    });
    let mut state=ACTIVE.with(|cell|cell.borrow_mut().take()).expect("installed census");
    state.deadline_observed|=Instant::now()>=state.end;
    if !state.path.is_empty() {state.error=Some("census final raw path did not unwind".into());}
    let mut accounting_errors=Vec::new();
    for bucket in &state.buckets {
        for error in bucket.accounting_errors() {
            accounting_errors.push(format!("iteration{} depth{} ply{}: {error}",bucket.iteration,bucket.depth,bucket.ply));
        }
    }
    let counted_nodes:u64=state.buckets.iter().map(|b|b.counts[Count::Inner as usize]+b.counts[Count::Repetition as usize]).sum();
    if counted_nodes!=result.nodes {accounting_errors.push(format!("counted_nodes{counted_nodes} != search_nodes{}",result.nodes));}
    let complete=result.completed_depth==6 && !state.deadline_observed && state.error.is_none() && accounting_errors.is_empty();
    Ok(CensusRun{result,buckets:state.buckets,iterations_started:state.iterations_started,
                 deadline_observed:state.deadline_observed,error:state.error,accounting_errors,complete})
}

#[cfg(test)]
mod tests {
    use super::*;
    fn game()->UhpGame {
        // Existing DEV fixture whose ordinary D6 completion is already saved.
        // This validates observer parity, not snapshot coverage or old F PASS.
        let line=include_str!("../tests/archive_repetition.txt").lines().next().unwrap();
        let mut game=UhpGame::new(crate::GameType::mlp());
        for text in line.split('|').nth(2).unwrap().split(';').take(16) {game.play(text).unwrap();}
        game
    }
    #[test]
    fn independent_masks_keep_sentinel_tail_and_queen_failures_distinct() {
        assert_eq!(predicate_mask(5,1,8,0,[true,true]),0);
        assert_eq!(predicate_mask(5,1,8,WIN+1,[true,true]),16);
        assert_eq!(predicate_mask(5,1,7,-WIN+64,[false,true]),4|8|32);
        assert_eq!(predicate_mask(4,2,8,0,[true,false]),1|2|64);
        assert_eq!(predicate_mask(5,1,8,WIN-65,[true,true]),0);
    }
    #[test]
    fn disjoint_accounting_detects_hook_only_and_lost_return() {
        let mut b=Bucket::new(6,5,1);
        b.add(Count::Entry).unwrap(); b.add(Count::Inner).unwrap();
        b.add(Count::PreferredCutoff).unwrap();b.preferred_cutoff_by_slot[0]=1;
        assert!(b.accounting_errors().is_empty());
        b.add(Count::Residual).unwrap();b.predicate_masks[0]=1;
        assert!(b.accounting_errors().iter().any(|x|x=="residual outcome partition"));
        b.add(Count::Entry).unwrap();
        assert!(b.accounting_errors().iter().any(|x|x=="parts entry partition"));
    }
    #[test]
    fn overflow_is_error_not_silent_census_truncation() {
        let mut b=Bucket::new(1,0,1);b.counts[0]=u64::MAX;
        assert!(b.add(Count::Entry).is_err());
    }
    #[test]
    fn inactive_observer_does_not_enable_old_snapshot_or_change_ordinary_search() {
        let g=game();let before=g.game_string();
        let a=g.search(SearchLimit::Depth(2));
        count(1,1,Count::Entry); iteration(6);
        assert!(!phase_expired() && !super::super::residual::is_active());
        let b=g.search(SearchLimit::Depth(2));
        assert_eq!((a.best_move,a.score,a.completed_depth,a.nodes),(b.best_move,b.score,b.completed_depth,b.nodes));
        assert_eq!(g.game_string(),before);
    }
    #[test]
    fn completed_census_reconciles_nodes_and_preserves_fixed_depth_result() {
        let g=game();let before=g.game_string();let a=g.search(SearchLimit::Depth(6));
        let mut iterations=Vec::new();
        let run=census(&g,Instant::now()+Duration::from_secs(30),|row|{iterations.push(row.completed_depth);Ok(())}).unwrap();
        assert!(run.complete,"{:?} {:?}",run.error,run.accounting_errors);
        assert_eq!((a.best_move,a.score,a.completed_depth,a.nodes),
                   (run.result.best_move,run.result.score,run.result.completed_depth,run.result.nodes));
        assert_eq!(iterations,(1..=6).collect::<Vec<_>>());assert_eq!(g.game_string(),before);
        assert!(!super::super::residual::is_active());
    }
    #[test]
    fn callback_failure_produces_partial_accounting_and_unwinds_active_scope() {
        let g=game();let before=g.game_string();
        let run=census(&g,Instant::now()+Duration::from_secs(30),|_|Err("opaque sink failure".into())).unwrap();
        assert!(!run.complete && run.error.is_some());
        assert!(run.accounting_errors.is_empty());assert_eq!(g.game_string(),before);
        assert!(!phase_expired());
    }
    #[test]
    fn census_deadline_stops_depth_search_without_changing_fixed_root() {
        let g=game();let before=g.game_string();
        let run=census(&g,Instant::now()+Duration::from_secs(30),|_| {
            ACTIVE.with(|cell|cell.borrow_mut().as_mut().unwrap().end=Instant::now());
            Ok(())
        }).unwrap();
        assert!(!run.complete && run.deadline_observed);
        assert_eq!(run.result.completed_depth,1);
        assert!(run.accounting_errors.is_empty());assert_eq!(g.game_string(),before);
        assert!(!phase_expired());
    }
    #[test]
    fn actual_killer_cutoff_is_counted_before_any_residual_hook() {
        // Routing fixture only: a deliberately sentinel-low beta guarantees a
        // cutoff on the first valid raw killer. It is NOT a feasibility label.
        let g=game();let mut board=g.board().clone();
        let mv=board.legal_moves()[0];
        let mut buckets=Vec::new();
        for i in 0..AXIS {for d in 0..AXIS {for p in 0..AXIS {
            buckets.push(Bucket::new(i as u8,d as u8,p as u8));
        }}}
        ACTIVE.with(|cell|*cell.borrow_mut()=Some(State{end:Instant::now()+Duration::from_secs(30),
            iteration:2,iterations_started:vec![2],buckets,deadline_observed:false,error:None,path:vec![mv]}));
        let mut worker=Search{history:Some(vec![Position::new(&board)]),killers:[[None;2];65],
            table:vec![None;16384],deadline:None,nodes:0,node_limit:None};
        worker.killers[1][0]=Some(mv);
        let value=worker.negamax(&mut board,1,1,-WIN-1,-WIN);
        let state=ACTIVE.with(|cell|cell.borrow_mut().take()).unwrap();
        assert!(value.unwrap()>=-WIN);
        let bucket=&state.buckets[index(2,1,1).unwrap()];
        assert_eq!(bucket.counts[Count::PreferredCutoff as usize],1);
        assert_eq!(bucket.preferred_cutoff_by_slot,[0,1,0]);
        assert_eq!(bucket.counts[Count::Residual as usize],0);
        assert!(state.buckets.iter().all(|b|b.accounting_errors().is_empty()));
    }
}
