Foulbrood 4.0

Exact Native 2714382040445f8040eb2f395ba0344151c09cefb9fbc35291bb88785ca73052
Exact opening book 54e6e72609137b3a41e0b81644de424861da144040726d831893bffe704603b4

viewer-engine/ contains the complete installed engine profile, including the Mac ARM64 binary and revised book. Restore it as one folder; preserve executable bits (chmod +x wrapper.py foulbrood-finish book-board) and add wrapper.py through the viewer normal engine catalog.

engine-source/ contains the exact qualified production Rust source and Cargo build metadata. Compilation environment is recorded in RELEASE.json. Build with cargo build --release --bin foulbrood after setting those four FOULBROOD variables. The source retains its historical internal Cargo version; the installed wrapper release name is Foulbrood 4.0. A rebuild hash is compiler/path dependent; the exact tested executable is included.

Full test fixtures, saved games, private games, credentials, unrelated research data, logs and build caches are not exported. Full original qualification/test evidence remains in local custody.

Required physical Mzinga100x80 seed1 passed: 7518 checked positions, comprising 988 verified saved-prefix checks and 6530 new checks. The prior timed-out stage remains failed. Revised-book Black16:16W0L0D0Unknown; separate cohort, no Elo or causal gain claim. The next32White/32Black64-game cohort is pending.
