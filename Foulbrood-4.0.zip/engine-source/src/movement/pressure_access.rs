//! Targeted ONE-step net ring-fill membership, not a safe/forcing attack proof.
//! No production Board mutation, hypothetical pass or full legal vector.
use super::*;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum RingAccess { Found(HiveMove), None, Unknown }
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) struct PressureAccess {
    pub status: RingAccess,
    pub potential_only: bool,
}
impl PressureAccess {
    pub fn retain_pressure(self) -> bool { !matches!(self.status,RingAccess::None) }
}
#[derive(Clone, Copy)]
enum Probe { Found(Hex), No, Unknown }
fn adjacent(a:Hex,b:Hex)->bool {
    matches!((i32::from(b.q)-i32::from(a.q),i32::from(b.r)-i32::from(a.r)),(1,0)|(1,-1)|(0,-1)|(-1,0)|(-1,1)|(0,1))
}
fn wide_distance(a:Hex,b:Hex)->i32 {
    let q=i32::from(a.q)-i32::from(b.q);let r=i32::from(a.r)-i32::from(b.r);
    q.abs().max(r.abs()).max((q+r).abs())
}
fn interior(h:Hex,padding:i16)->bool {
    h.q>=i16::MIN+padding && h.q<=i16::MAX-padding
        && h.r>=i16::MIN+padding && h.r<=i16::MAX-padding
}
struct Context<'a> {
    b:&'a Board,
    mask:Option<Option<u32>>,
    ants:Option<Option<AntOccupancy>>,
    #[cfg(test)] ant_queue_limit:usize,
}
impl<'a> Context<'a> {
    fn new(b:&'a Board)->Self {Self{b,mask:None,ants:None,#[cfg(test)] ant_queue_limit:256}}
    fn liftable(&mut self,piece:Piece,h:Hex)->Option<bool> {
        if self.b.stack_height(h)>1 || locally_connected_after_lift(self.b,h) {return Some(true);}
        let b=self.b;
        let mask=*self.mask.get_or_insert_with(|| {
            // Cold imported coordinate-edge data retains the old pressure;
            // never turn an unrepresentable query into false no-access.
            if b.occupied_hexes().any(|h|!interior(h,1)){None}
            else{Some(articulation_piece_mask(b))}
        });
        mask.map(|mask|mask&(1_u32<<piece.id())==0)
    }
    fn ant_any(&mut self,source:Hex,holes:&[Hex])->Probe {
        if self.b.stack_height(source)!=1 {return Probe::No;}
        let b=self.b;
        #[cfg(test)] let queue_limit=self.ant_queue_limit;
        #[cfg(not(test))] let queue_limit=256;
        let Some(grid)=self.ants.get_or_insert_with(||AntOccupancy::new(b,source)).as_mut() else{return Probe::Unknown;};
        let Some((row,bit))=grid.lift_source(source)else{return Probe::Unknown;};
        // Always restore this PRIVATE occupancy snapshot, including early exits.
        let result=(|| {
            let mut targets=[None;6];
            for(i,h)in holes.iter().enumerate() {
                let x=i32::from(h.q)-i32::from(grid.grid.origin.q)+32;
                let y=i32::from(h.r)-i32::from(grid.grid.origin.r)+32;
                if x as u32>=64 || y as u32>=64{return Probe::Unknown;}
                targets[i]=Some(((y*64+x)as u16,*h));
            }
            let start=(row as u16)*64+bit.trailing_zeros()as u16;
            let mut seen=[0_u64;64];let mut queue=[0_u16;256];let mut head=0;let mut tail=1;
            queue[0]=start;seen[row]=bit;
            while head<tail {
                let current=queue[head];head+=1;
                let Some(mask)=grid.neighbor_mask_at(current)else{return Probe::Unknown;};
                let mut steps=ANT_LEGAL_STEP_MASK[mask as usize];
                while steps!=0 {
                    let i=steps.trailing_zeros()as usize;steps&=steps-1;
                    let next=(current as i16+ANT_GRID_STEPS[i])as u16;
                    if let Some((_,h))=targets.iter().flatten().find(|(index,_)|*index==next){return Probe::Found(*h);}
                    let r=(next>>6)as usize;let bit=1_u64<<(next&63);
                    if seen[r]&bit!=0{continue;}
                    seen[r]|=bit;
                    if tail>=queue_limit||tail==queue.len(){return Probe::Unknown;}
                    queue[tail]=next;tail+=1;
                }
            }
            Probe::No
        })();
        grid.grid.rows[row]|=bit;
        result
    }
    fn ordinary(&mut self,bug:Bug,source:Hex,holes:&[Hex])->Probe {
        let b=self.b;
        match bug {
            Bug::Queen|Bug::Pillbug|Bug::Beetle=> {
                for &to in holes {
                    let p=Piece::new(Color::White,bug,1);
                    if direct_step_hint(b,p,source,to)==Some(true){return Probe::Found(to);}
                }
                Probe::No
            }
            Bug::Ant=>self.ant_any(source,holes),
            Bug::Grasshopper=> {
                for direction in crate::Direction::ALL {
                    let mut cursor=source.neighbor(direction);
                    if !b.is_occupied(cursor){continue;}
                    let mut jumps=0;
                    while b.is_occupied(cursor) {
                        jumps+=1;if jumps>MAX_PIECES{return Probe::Unknown;}
                        cursor=cursor.neighbor(direction);
                    }
                    if holes.contains(&cursor){return Probe::Found(cursor);}
                }
                Probe::No
            }
            Bug::Spider=> {
                if b.stack_height(source)!=1{return Probe::No;}
                let mut path=[source;4];
                spider_any(b,source,source,0,&mut path,holes).map_or(Probe::No,Probe::Found)
            }
            Bug::Ladybug=> {
                if b.stack_height(source)!=1{return Probe::No;}
                for first in source.neighbors() {
                    if !b.is_occupied(first)||!elevated_gate_open(b,source,first,source){continue;}
                    for second in first.neighbors() {
                        if second==source||second==first||!b.is_occupied(second)
                            ||!elevated_gate_open(b,first,second,source){continue;}
                        for &to in holes {
                            if adjacent(second,to) && elevated_gate_open(b,second,to,source){return Probe::Found(to);}
                        }
                    }
                }
                Probe::No
            }
            Bug::Mosquito=> {
                if b.stack_height(source)>1{return self.ordinary(Bug::Beetle,source,holes);}
                let mut copied=0_u8;
                for h in source.neighbors(){if let Some(p)=b.top(h){if p.bug!=Bug::Mosquito{copied|=1<<p.bug as u8;}}}
                let mut unknown=false;
                for bug in Bug::ALL {
                    if copied&(1<<bug as u8)==0{continue;}
                    match self.ordinary(bug,source,holes){Probe::Found(h)=>return Probe::Found(h),Probe::Unknown=>unknown=true,Probe::No=>{}}
                }
                if unknown{Probe::Unknown}else{Probe::No}
            }
        }
    }
    fn access(&mut self,color:Color)->PressureAccess {
        let b=self.b;let potential_only=b.side_to_move()!=color;
        let result=|status|PressureAccess{status,potential_only};
        let target_piece=Piece::new(color.other(),Bug::Queen,1);
        let Some(target)=b.location(target_piece)else{return result(RingAccess::None);};
        if !interior(target,32){return result(RingAccess::Unknown);}
        if Color::ALL.into_iter().filter_map(|c|b.location(Piece::new(c,Bug::Queen,1))).any(|q|!interior(q,32)){return result(RingAccess::Unknown);}
        if b.game_over(){return result(RingAccess::None);}
        let ring=target.neighbors();let mut holes=[Hex::ORIGIN;6];let mut count=0;
        for h in ring{if !b.is_occupied(h){holes[count]=h;count+=1;}}
        if count==0{return result(RingAccess::None);}
        let holes=&holes[..count];
        // This pure color-parameter placement predicate is shared with the old
        // actual-side hint. No side flip, turn increment, history or pass.
        for bug in Bug::ALL {
            let Some(piece)=b.canonical_piece_in_hand(color,bug)else{continue;};
            for &to in holes {
                if b.is_legal_placement_for_color(color,piece,to){return result(RingAccess::Found(HiveMove::Place{piece,to}));}
            }
        }
        if !b.queen_is_placed(color){return result(RingAccess::None);}
        let immobilized=if !potential_only&&b.game_type().pillbug{b.last_physically_moved_piece()}else{None};
        let mut unknown=false;
        for bug in Bug::ALL {
            if !b.game_type().includes(bug){continue;}
            for number in 1..=bug.copies() {
                let piece=Piece::new(color,bug,number);
                let Some(from)=b.location(piece)else{continue;};
                if b.top(from)!=Some(piece)||Some(piece)==immobilized
                    || (adjacent(from,target)&&b.stack_height(from)==1){continue;}
                if !interior(from,32){unknown=true;continue;}
                if b.stack_height(from)>1&&!matches!(bug,Bug::Beetle|Bug::Mosquito){unknown=true;continue;}
                // Reject an impossible requested destination before doing graph
                // work where possible, but never accept without One-Hive.
                let probe=self.ordinary(bug,from,holes);
                match probe {
                    Probe::No=>continue,
                    Probe::Unknown=>{unknown=true;continue;},
                    Probe::Found(to)=>match self.liftable(piece,from) {
                        Some(true)=>return result(RingAccess::Found(HiveMove::Move{piece,from,to})),
                        Some(false)=>{},None=>unknown=true,
                    },
                }
            }
        }
        for bug in[Bug::Mosquito,Bug::Pillbug] {
            if !b.game_type().includes(bug){continue;}
            let actor=Piece::new(color,bug,1);let Some(h)=b.location(actor)else{continue;};
            if b.top(h)!=Some(actor)||Some(actor)==immobilized{continue;}
            if !interior(h,32){unknown=true;continue;}
            if wide_distance(h,target)>2||!can_use_pillbug_ability(b,actor,h){continue;}
            // Actor may be an articulation: it is not lifted. A donor may be
            // either color, including ownQueen, but NEVER the targetQueen.
            for from in h.neighbors() {
                let Some(piece)=b.top(from)else{continue;};
                if piece==target_piece||Some(piece)==immobilized||b.stack_height(from)!=1
                    ||adjacent(from,target)||!elevated_gate_open(b,from,h,from){continue;}
                match self.liftable(piece,from){Some(false)=>continue,None=>{unknown=true;continue;},Some(true)=>{}}
                for &to in holes {
                    if adjacent(h,to)&&to!=from&&elevated_gate_open(b,h,to,from) {
                        return result(RingAccess::Found(HiveMove::Pillbug{actor,piece,from,to}));
                    }
                }
            }
        }
        result(if unknown{RingAccess::Unknown}else{RingAccess::None})
    }
}
fn spider_any(b:&Board,lifted:Hex,current:Hex,depth:usize,path:&mut[Hex;4],holes:&[Hex])->Option<Hex> {
    if depth==3{return holes.contains(&current).then_some(current);}
    for next in current.neighbors() {
        if path[..=depth].contains(&next)||height_after_lift(b,next,lifted)!=0||!ground_gate_open(b,current,next,lifted){continue;}
        path[depth+1]=next;
        if let Some(h)=spider_any(b,lifted,next,depth+1,path,holes){return Some(h);}
    }
    None
}
/// Shared private graph/Ant workspace across requested colors. Any unsupported
/// imported-geometry membership query is UNKNOWN and keeps the original curve.
pub(crate) fn ring_pressure_access_pair(b:&Board,requested:[bool;2])->[PressureAccess;2] {
    let mut ctx=Context::new(b);
    Color::ALL.map(|c|if requested[c.index()]{ctx.access(c)}else{PressureAccess{status:RingAccess::None,potential_only:b.side_to_move()!=c}})
}
pub(crate) fn ring_pressure_access(b:&Board,color:Color)->PressureAccess {Context::new(b).access(color)}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn ant_queue_guard_restores_private_occupancy_before_reuse() {
        let w=Color::White;let b=Color::Black;let source=Hex::new(3,0);
        let board=Board::from_setup(crate::GameType::mlp(),w,20,&[
            (Piece::new(w,Bug::Queen,1),Hex::new(-2,0),0),
            (Piece::new(b,Bug::Queen,1),Hex::new(0,0),0),
            (Piece::new(w,Bug::Grasshopper,1),Hex::new(-1,0),0),
            (Piece::new(w,Bug::Grasshopper,2),Hex::new(1,0),0),
            (Piece::new(w,Bug::Spider,1),Hex::new(2,0),0),
            (Piece::new(w,Bug::Ant,1),source,0)],None).unwrap();
        let before=format!("{board:?}");let holes=[Hex::new(1,-1)];
        let mut ctx=Context::new(&board);ctx.ant_queue_limit=0;
        assert!(matches!(ctx.ant_any(source,&holes),Probe::Unknown));
        let original=AntOccupancy::new(&board,source).unwrap();
        assert_eq!(ctx.ants.as_ref().unwrap().as_ref().unwrap().grid.rows,original.grid.rows);
        ctx.ant_queue_limit=256;
        assert!(matches!(ctx.ant_any(source,&holes),Probe::Found(h)if h==holes[0]));
        assert_eq!(ctx.ants.as_ref().unwrap().as_ref().unwrap().grid.rows,original.grid.rows);
        assert_eq!(format!("{board:?}"),before);
    }
}
