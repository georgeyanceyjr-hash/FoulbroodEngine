use super::*;

#[test]
fn snapshot_and_runtime_use_identical_shared_features_and_hce_rank() {
    let line=include_str!("../tests/archive_repetition.txt").lines().next().unwrap();
    let mut root=UhpGame::new(crate::GameType::mlp());
    for text in line.split('|').nth(2).unwrap().split(';').take(17) { root.play(text).unwrap(); }
    let root_literal=root.game_string();let root_raw_history=root.history().to_vec();
    let mv=root.board().legal_moves()[0];root.play_raw(mv).unwrap();
    let board=root.board().clone();let full=board.legal_moves();assert!(full.len()>=8);
    let mut hce=full.clone();let position=Position::new(&board);let key=position.key();
    let mut table=vec![None;16384];
    table[key as usize&16383]=Some(Entry{key,position,depth:4,score:12,bound:Bound::Exact,best_move:full.first().copied()});
    let worker=Search{history:Some(root.exact_position_history().to_vec()),table:table.clone(),killers:[[None;2];65],deadline:None,nodes:0,node_limit:None};
    worker.order_moves(&mut board.clone(),&mut hce,1).unwrap();
    let snapshot=Snapshot{root_literal,root_raw_history,generated_path:vec![mv],board:board.clone(),
        history:root.exact_position_history().to_vec(),table,killers:[[None;2];65],depth:5,ply:1,
        entry_alpha:-22,alpha:-12,beta:16,total:piece_total(&board),counts:queen_counts(&board),
        nodes_at_capture:0,prefix:vec![],tail:full.clone(),hce_tail:Some(hce.clone()),full_legal:full,
        absolute_deadline:Instant::now()+std::time::Duration::from_secs(5),transport_original_hard_unix_ms:None};
    for (i,&raw) in snapshot.tail.iter().enumerate() {
        let rank=hce.iter().position(|&m|m==raw).unwrap();
        let shared=feature_vector(&board,raw,5,1,-12,16,0,rank,snapshot.tail.len(),true);
        assert_eq!(snapshot.features(i).unwrap(),shared);
        assert!(super::super::trained::predict_features(&shared).unwrap().priority.is_finite());
    }
}
