#!/usr/bin/python3
"""Explicit Finish play budgets; ordinary bounded analysis; verified holes-only book."""
import hashlib
import json
import os
import selectors
from collections import deque
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
BASE = ROOT / 'foulbrood-finish'
EXPECTED = '2714382040445f8040eb2f395ba0344151c09cefb9fbc35291bb88785ca73052'
BOOK_SHA = '54e6e72609137b3a41e0b81644de424861da144040726d831893bffe704603b4'
NAME = 'Foulbrood 4.0'


def raw_key(raw):
    if not isinstance(raw, dict) or set(raw) != {'kind', 'actor', 'piece', 'from', 'to'}:
        raise ValueError('Incomplete raw descriptor')
    def xy(v):
        if v is None: return None
        if not isinstance(v, list) or len(v) != 2 or any(type(x) is not int for x in v):
            raise ValueError('Invalid raw coordinate')
        return tuple(v)
    if any(type(raw[k]) is not int for k in ('kind', 'actor', 'piece')):
        raise ValueError('Invalid raw identity')
    return raw['kind'], raw['actor'], raw['piece'], xy(raw['from']), xy(raw['to'])


def legal_map(row):
    result = {}
    for child in row['moves']:
        key = raw_key(child['raw_move'])
        if key in result: raise ValueError('Duplicate raw identity')
        result[key] = child['notation']
    return result


def display_record(row, legal, iterations=()):
    """Raw identity -> display text only; never recover an actor from notation."""
    move = legal[raw_key(row['selected_raw'])]
    depth, score = row['completed_depth'], row['score']
    if row['event'] == 'iteration':
        if row['status'] != 'complete' or depth < 1 or type(score) is not int:
            raise ValueError('Unscored iteration')
        return f'FoulBroodScore v2;kind=iteration;depth={depth};score={score};move={move}'
    if row['event'] != 'final': raise ValueError('Unknown raw report')
    if row['status'] == 'complete':
        if depth < 1 or type(score) is not int or row['eval_raw'] != row['selected_raw']:
            raise ValueError('Inconsistent complete report')
        return f'FoulBroodScore v2;kind=final;status=complete;depth={depth};score={score};move={move};evalmove={move}'
    if row['status'] == 'partial':
        evaluated = raw_key(row['eval_raw'])
        # A delayed diagnostic may be unavailable to the display thread. In that
        # case stay unscored; never invent a completed depth or score attribution.
        matches = [r for r in iterations if raw_key(r['selected_raw']) == evaluated
                   and r['score'] == row['eval_score'] and r['completed_depth'] == depth and depth > 0]
        if matches:
            last = matches[-1]; evalmove = legal[evaluated]
            return f'FoulBroodScore v2;kind=final;status=partial;depth={last["completed_depth"]};score={row["eval_score"]};move={move};evalmove={evalmove}'
    elif row['status'] != 'fallback': raise ValueError('Unknown final status')
    return f'FoulBroodScore v2;kind=final;status=fallback;depth=0;move={move}'


class Profile:
    def __init__(self):
        if hashlib.sha256(BASE.read_bytes()).hexdigest() != EXPECTED:
            raise ValueError('Finish binary checksum mismatch')
        if hashlib.sha256((ROOT/'book.json').read_bytes()).hexdigest() != BOOK_SHA:
            raise ValueError('Book checksum mismatch')
        from book import lookup, available_moves
        self.lookup, self.available_moves = lookup, available_moves
        self.book = json.loads((ROOT/'book.json').read_text())
        self.game = 'Base;NotStarted;White[1]'
        self.choices = {}; self.review_search = False
        self.legal = None; self.iterations = []; self.diagnostic_error = None
        self.interrupted = False; self.proc = None; self.selector = None
        self.buffers = {'stdout': b'', 'stderr': b''}; self.lines = deque()
        self.proc = subprocess.Popen([str(BASE)], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                     stderr=subprocess.PIPE, bufsize=0)
        self.selector = selectors.DefaultSelector()
        for name, stream in (('stdout', self.proc.stdout), ('stderr', self.proc.stderr)):
            os.set_blocking(stream.fileno(), False)
            self.selector.register(stream, selectors.EVENT_READ, name)

    def diagnostic(self, line):
        if line.startswith('{'):
            try:
                row = json.loads(line)
                if self.legal is None or row.get('event') != 'iteration':
                    raise ValueError('Raw diagnostic outside its search request')
                if row['completed_depth'] != len(self.iterations)+1:
                    raise ValueError('Raw iterations must be contiguous for this request')
                record = display_record(row, self.legal)
                self.iterations.append(row)
                print(record, file=sys.stderr, flush=True)
            except Exception as error: self.diagnostic_error = str(error)
        else:
            print(line, file=sys.stderr, flush=True)

    def read_ready(self, name, stream):
        while True:
            try: block = os.read(stream.fileno(), 65536)
            except BlockingIOError: return
            if not block:
                self.selector.unregister(stream)
                if name == 'stdout': raise EOFError('Finish engine exited')
                return
            self.buffers[name] += block
            while b'\n' in self.buffers[name]:
                line, self.buffers[name] = self.buffers[name].split(b'\n', 1)
                text = line.rstrip(b'\r').decode('utf-8', errors='strict')
                if name == 'stdout': self.lines.append(text)
                else: self.diagnostic(text)
            if len(self.buffers[name]) > 2*1024*1024:
                raise ValueError('Native line exceeded UI protocol limit')

    def reply(self):
        lines = []
        while True:
            if self.lines:
                line = self.lines.popleft()
                if line == 'ok':
                    # Native writes all diagnostics before its stdout result/ok.
                    # Drain the actual pipe to EAGAIN here in the SAME thread;
                    # no readline buffer or delayed thread can cross requests.
                    self.read_ready('stderr', self.proc.stderr)
                    if self.buffers['stderr']:
                        raise ValueError('Incomplete Native diagnostic at reply boundary')
                    return lines
                lines.append(line)
            else:
                for key, _ in self.selector.select(timeout=1):
                    self.read_ready(key.data, key.fileobj)

    def native(self, command):
        self.proc.stdin.write((command+'\n').encode()); self.proc.stdin.flush()
        rows = self.reply()
        if any(r.startswith(('err', 'invalidmove')) for r in rows):
            raise ValueError('; '.join(rows))
        return rows

    def finish(self, soft, hard):
        if not 0 <= soft <= hard <= 86400000: raise ValueError('Invalid Finish allowances')
        legal = legal_map(json.loads(self.native('validmoves_raw')[0]))
        self.legal = legal; self.iterations = []; self.diagnostic_error = None
        try:
            row = json.loads(self.native(f'bestmove_raw finish_ms {soft} {hard}')[0])
            if self.diagnostic_error: raise ValueError(self.diagnostic_error)
            if row['status'] in ('complete', 'partial'):
                if not self.iterations or row['completed_depth'] != len(self.iterations):
                    raise ValueError('Final completed depth lacks exact iteration witness')
            if row['status'] in ('complete', 'partial'):
                if not self.iterations: raise ValueError('Final evaluation lacks iteration witness')
                last = self.iterations[-1]
                if (row['eval_raw'], row['eval_score']) != (last['selected_raw'], last['score']):
                    raise ValueError('Final evaluation does not match last complete iteration')
                if row['status'] == 'complete' and row['score'] != last['score']:
                    raise ValueError('Final score differs from last complete iteration')
                if row['status'] == 'partial' and row['score'] is not None:
                    raise ValueError('Partial selected move must remain unscored')
            elif row['status'] == 'fallback' and self.iterations:
                raise ValueError('Fallback contradicts completed iteration evidence')
            record = display_record(row, legal, self.iterations[-1:])
            print(record, file=sys.stderr, flush=True)
            print('FoulBroodFinish v1;'+json.dumps(row['completion'], separators=(',', ':')),
                  file=sys.stderr, flush=True)
            return [legal[raw_key(row['selected_raw'])]]
        finally:
            self.legal = None

    def command(self, cmd):
        verb = cmd.split(' ', 1)[0]
        if cmd == 'options get Finish': return ['Finish;bool;True']
        if cmd == 'options get NativeProcess': return [f'NativeProcess;int;{self.proc.pid}']
        if cmd.startswith('options set ReviewSearch '):
            value = cmd.removeprefix('options set ReviewSearch ')
            if value not in ('True', 'False'): raise ValueError('ReviewSearch must be True or False')
            self.review_search = value == 'True'; return []
        if cmd == 'bookmoves': return [';'.join(self.available_moves(self.game, self.book))]
        if verb == 'bestmove' and not self.review_search:
            # A book hit does not construct a raw search or consume its allowance.
            move = self.lookup(self.game, self.book, cache=self.choices)
            if move:
                print('TopBotBook v3;move='+move, file=sys.stderr, flush=True)
                return [move]
        if cmd.startswith('bestmove finish_ms '):
            m = re.fullmatch(r'bestmove finish_ms (\d+) (\d+)', cmd)
            if not m: raise ValueError('Finish requires two unsigned allowances')
            return self.finish(int(m[1]), int(m[2]))
        rows = self.native(cmd)
        if verb == 'newgame': self.choices.clear()
        if verb in ('newgame', 'play', 'undo'):
            self.game = next((r for r in rows if r.startswith('Base') and ';' in r), self.game)
        return rows

    def close(self):
        proc = getattr(self, 'proc', None)
        if proc is not None:
            if proc.poll() is None:
                if not getattr(self, 'interrupted', False):
                    try:
                        proc.stdin.write(b'exit\n'); proc.stdin.flush(); proc.wait(timeout=.2)
                    except (OSError, subprocess.TimeoutExpired): pass
                if proc.poll() is None:
                    proc.terminate()
                    try: proc.wait(timeout=.15)
                    except subprocess.TimeoutExpired: proc.kill(); proc.wait(timeout=.15)
            for stream in (proc.stdin, proc.stdout, proc.stderr): stream.close()
        selector = getattr(self, 'selector', None)
        if selector: selector.close()


def main():
    engine = None
    def stop(*_):
        if engine is not None: engine.interrupted = True
        raise SystemExit(0)
    signal.signal(signal.SIGTERM, stop)
    try:
        engine = Profile.__new__(Profile)
        Profile.__init__(engine)
        startup = engine.reply()
        engine.native('options set OpeningPlies 20')
        engine.native('options set ThreadPolicy Opening8Then4')
        for line in startup:
            print('id '+NAME if line.startswith('id ') else line, flush=True)
        print('FoulBroodBookMoves;FoulBroodReviewSearch;FoulBroodFinish', flush=True)
        print('ok', flush=True)
        for raw in sys.stdin:
            cmd = raw.strip()
            if cmd == 'exit': break
            try:
                for line in engine.command(cmd):
                    if line: print(line, flush=True)
            except Exception as error: print('err '+str(error), flush=True)
            print('ok', flush=True)
    finally:
        if engine: engine.close()


if __name__ == '__main__': main()
