//! Cooperative root alpha with private workers; one-thread search stays unchanged.
//!
//! Search the previous PV child first with the original full root window. Each
//! sibling admits the latest completed exact root score between jobs. A returned
//! score is publishable only when strictly above that job's admitted alpha: an
//! ordinary fail-low is only an upper bound, never a winning or tied witness.
//! An earlier root ordinal uses score-1 so an exact equal score can restore the
//! fixed iteration-order tie priority despite a later worker finishing first.
//! No TT/history state is shared. Cooperation and scaling require measurement.
use super::{Search, SearchLimit, SearchResult, WIN, MAX_DEPTH, Position,
    terminal, piece_total_q, queen_counts, piece_move_delta,
    projected_queen_counts, queen_moved};
use crate::{Board, Color, Bug, Piece, HiveMove};
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Mutex;
use std::time::{Duration, Instant};
use std::cell::RefCell;

pub const MAX_THREADS: u8 = 12;

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Stats {
    pub configured_threads: u8,
    pub peak_active_searches: usize,
    pub worker_nodes: Vec<u64>,
    pub worker_root_jobs: Vec<u64>,
    pub spawned_threads: u64,
    pub joined_threads: u64,
    pub worker_model_stats: Vec<super::trained::Stats>,
}

thread_local! { static LATEST: RefCell<Option<Stats>> = RefCell::new(None); }
fn publish(stats: &Stats) { LATEST.with(|s| *s.borrow_mut()=Some(stats.clone())); }
fn add_model(into: &mut super::trained::Stats, value: super::trained::Stats) {
    into.applications=into.applications.checked_add(value.applications).expect("model counter overflow");
    into.moves_ranked=into.moves_ranked.checked_add(value.moves_ranked).expect("model counter overflow");
    into.changed_orders=into.changed_orders.checked_add(value.changed_orders).expect("model counter overflow");
}
/// Immutable coordinator snapshot, published only after scoped worker joins.
/// Serial jobs are uninstrumented (empty vector), never invented zero counts.
pub fn report_json(threads: u8, nodes: u64) -> String {
    let stats=if threads==1 {
        Stats{configured_threads:1,peak_active_searches:usize::from(nodes>0),worker_nodes:vec![nodes],
            worker_root_jobs:vec![],spawned_threads:0,joined_threads:0,worker_model_stats:vec![super::trained::stats()]}
    } else {
        LATEST.with(|s|s.borrow().as_ref().expect("actual parallel snapshot before report").clone())
    };
    assert_eq!(stats.configured_threads,threads);
    let nodes=stats.worker_nodes.iter().map(u64::to_string).collect::<Vec<_>>().join(",");
    let jobs=stats.worker_root_jobs.iter().map(u64::to_string).collect::<Vec<_>>().join(",");
    format!(r#"{{"threads":{},"peak":{},"spawned":{},"joined":{},"nodes_by_worker":[{}],"jobs_by_worker":[{}]}}"#,
        threads,stats.peak_active_searches,stats.spawned_threads,stats.joined_threads,nodes,jobs)
}

#[derive(Clone, Debug)]
pub struct Run { pub result: SearchResult, pub stats: Stats }

pub fn validate_threads(threads: u8) -> Result<(), String> {
    if (1..=MAX_THREADS).contains(&threads) { Ok(()) }
    else { Err("Threads requires an integer from 1 through 12".into()) }
}

fn worker(history: &[Position], deadline: Option<crate::deadline::Deadline>) -> Search {
    Search { history:Some(history.to_vec()), table:vec![None;16384],
        killers:[[None;2];65],deadline,nodes:0,#[cfg(test)] node_limit:None }
}

/// Whole generated move identity crosses the worker boundary unchanged.
fn child(worker: &mut Search, root: &Board, mv: HiveMove, depth: u8, alpha: i32)
    -> Result<i32, ()>
{
    if worker.expired() { return Err(()); }
    let mut board = root.clone();
    let queens = Color::ALL.map(|c| root.location(Piece::new(c,Bug::Queen,1)));
    let counts = queen_counts(root);
    let total = piece_total_q(root,&queens);
    let delta = piece_move_delta(root,mv,&queens);
    let next_counts = projected_queen_counts(root,mv,&queens,counts);
    let undo = board.make_generated(mv);
    let child_counts = next_counts.unwrap_or_else(|| queen_counts(&board));
    let child_total = if queen_moved(mv) { super::piece_total(&board) } else { total+delta };
    // Full played history already contains the root. negamax_parts adds/removes
    // this actual child using Position::after and its exact original search ply.
    let result = worker.negamax_parts(&mut board,depth-1,1,-WIN-1,-alpha,
                                     child_total,child_counts,Some(mv));
    board.undo_generated(undo);
    result.map(|score| -score)
}

struct Active<'a>(&'a AtomicUsize);
impl Drop for Active<'_> {
    fn drop(&mut self) { self.0.fetch_sub(1,Ordering::SeqCst); }
}

/// The score/ordinal pair is one completed exact child witness for THIS root
/// iteration only. Ordinals index the fixed list after the unchanged PV/HCE
/// preparation, before worker scheduling; no identity comes from move notation.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct CertifiedRoot {
    score: i32,
    ordinal: usize,
}

impl CertifiedRoot {
    fn admitted_alpha(self, ordinal: usize) -> i32 {
        if ordinal < self.ordinal {
            // Scores are bounded by WIN; checked arithmetic also forbids a
            // future schema change from silently wrapping this tie window.
            self.score.checked_sub(1).expect("root score tie-window underflow")
        } else { self.score }
    }

    fn record(&mut self, ordinal: usize, admitted_alpha: i32, value: Result<i32, ()>) -> bool {
        let Ok(score) = value else { return false; };
        // child() has root upper bound WIN+1. Its completed result strictly
        // above the job's own alpha is exact; equality/fail-low is not proof.
        if score <= admitted_alpha { return false; }
        if score > self.score || (score == self.score && ordinal < self.ordinal) {
            *self = Self { score, ordinal };
            true
        } else { false }
    }
}

pub(crate) fn search(board: &Board, limit: SearchLimit, history: &[Position], threads: u8,
                    mut progress: impl FnMut(&SearchResult)) -> Result<Run,String>
{
    validate_threads(threads)?;
    super::validate_search_headroom(board,limit)?;
    if threads == 1 {
        let result = super::search_with_progress(board,limit,history,progress);
        let stats = Stats { configured_threads:1,peak_active_searches:usize::from(result.nodes>0),
            worker_nodes:vec![result.nodes],worker_root_jobs:vec![],spawned_threads:0,joined_threads:0,worker_model_stats:vec![super::trained::stats()] };
        return Ok(Run {result,stats});
    }
    // Existing snapshot/census callbacks are thread-local and single-threaded.
    // Never silently produce an incomplete diagnostic by moving work off-thread.
    if super::residual::is_active() || super::coverage::is_active() {
        return Err("Parallel search cannot run inside a single-thread snapshot/census observer".into());
    }
    let start = Instant::now();
    super::trained::start_search();
    let (depth_limit,end) = match limit {
        SearchLimit::Depth(depth) => (depth.min(MAX_DEPTH),None),
        SearchLimit::Time(time) => {
            let reserve = (time/20).min(Duration::from_millis(10));
            (MAX_DEPTH,Some(start.checked_add(time.saturating_sub(reserve)).unwrap_or(start)))
        }
    };
    let deadline = end.map(crate::deadline::Deadline::at);
    let mut result = SearchResult {best_move:None,score:terminal(board,0),completed_depth:0,
                                  nodes:0,elapsed:Duration::ZERO};
    let mut stats = Stats {configured_threads:threads,peak_active_searches:0,
        worker_nodes:vec![0;usize::from(threads)],worker_root_jobs:vec![0;usize::from(threads)],
        spawned_threads:0,joined_threads:0,worker_model_stats:vec![super::trained::Stats::default();usize::from(threads)]};
    publish(&stats);
    let root_position = Position::new(board);
    if result.score.is_none() && history.iter().filter(|p| root_position.same_repetition(p,board)).take(3).count()==3 {
        result.score=Some(0);
    }
    if result.score.is_some() {
        result.elapsed=start.elapsed();return Ok(Run {result,stats});
    }
    // Allocation, cloning, legal generation, ranking, spawning and joins all
    // consume the SAME deadline made before any of those operations.
    let mut moves = board.legal_moves();
    result.best_move=moves.first().copied();
    let mut workers=Vec::with_capacity(usize::from(threads));
    for _ in 0..threads {
        if depth_limit==0 || deadline.is_some_and(|d|d.expired()) {
            result.elapsed=start.elapsed();return Ok(Run {result,stats});
        }
        workers.push(worker(history,deadline));
    }
    let mut ordering_board=board.clone();
    for depth in 1..=depth_limit {
        if workers[0].expired() || moves.is_empty() {break;}
        if depth==2 && workers[0].order_moves(&mut ordering_board,&mut moves,0).is_err() {break;}
        if let Some(index)=moves.iter().position(|m|Some(*m)==result.best_move) {moves.swap(0,index);}
        let first = moves[0];
        stats.worker_root_jobs[0]+=1;
        stats.peak_active_searches=stats.peak_active_searches.max(1);
        let before_model=super::trained::stats();
        let first_value=child(&mut workers[0],board,first,depth,-WIN-1);
        let after_model=super::trained::stats();
        add_model(&mut stats.worker_model_stats[0],super::trained::Stats {
            applications:after_model.applications-before_model.applications,
            moves_ranked:after_model.moves_ranked-before_model.moves_ranked,
            changed_orders:after_model.changed_orders-before_model.changed_orders });
        let Ok(incumbent)=first_value else {break;};
        stats.peak_active_searches=stats.peak_active_searches.max(1);
        let mut best=first;
        let mut alpha=incumbent;
        let mut complete=true;
        if moves.len()>1 {
            let certified=Mutex::new(CertifiedRoot {score:incumbent,ordinal:0});
            let next=AtomicUsize::new(1);
            let active=AtomicUsize::new(0);
            let peak=AtomicUsize::new(0);
            let count=usize::from(threads).min(moves.len()-1);
            // scope guarantees no thread survives this iteration, including
            // unwinding. A worker panic propagates as a failed query, never a
            // fabricated completed score. Release panic=abort remains unchanged.
            let batches=std::thread::scope(|scope| {
                let mut handles=Vec::with_capacity(count);
                for (id,worker) in workers.iter_mut().take(count).enumerate() {
                    let next=&next;let active=&active;let peak=&peak;let moves=&moves;let certified=&certified;
                    handles.push(scope.spawn(move || {
                        super::trained::start_search();
                        let mut rows=Vec::new();
                        loop {
                            if worker.expired() {break;}
                            let index=next.fetch_add(1,Ordering::SeqCst);
                            let Some(&mv)=moves.get(index) else {break;};
                            let admitted_alpha=certified.lock().expect("root certificate poisoned")
                                .admitted_alpha(index);
                            let current=active.fetch_add(1,Ordering::SeqCst)+1;
                            peak.fetch_max(current,Ordering::SeqCst);
                            let _active=Active(active);
                            let value=child(worker,board,mv,depth,admitted_alpha);
                            certified.lock().expect("root certificate poisoned")
                                .record(index,admitted_alpha,value);
                            let failed=value.is_err();
                            rows.push((index,value));
                            if failed {break;}
                        }
                        (id,rows,super::trained::stats())
                    }));
                }
                handles.into_iter().map(|h|h.join().expect("Parallel worker panicked")).collect::<Vec<_>>()
            });
            stats.spawned_threads+=count as u64;stats.joined_threads+=count as u64;
            stats.peak_active_searches=stats.peak_active_searches.max(peak.load(Ordering::SeqCst));
            let mut rows=Vec::new();
            for (id,batch,model_stats) in batches {
                super::trained::merge_worker_stats(model_stats);
                add_model(&mut stats.worker_model_stats[id],model_stats);
                stats.worker_root_jobs[id]+=batch.len() as u64;
                rows.extend(batch);
            }
            rows.sort_by_key(|(index,_)|*index);
            complete=rows.len()==moves.len()-1;
            if rows.iter().any(|(_,value)|value.is_err()) {complete=false;}
            // Only certified exact witnesses select a winner. In particular,
            // never compare dynamic-window fail-low bounds as exact ties.
            let winner=*certified.lock().expect("root certificate poisoned");
            alpha=winner.score;best=moves[winner.ordinal];
        }
        if !complete {
            // Only completed strict improvements can replace the old selected
            // PV, and that partial selection has NO all-root score attached.
            if Some(best)!=result.best_move && alpha>-WIN+i32::from(MAX_DEPTH)
                && !result.score.is_some_and(|v|v.abs()>=WIN-i32::from(MAX_DEPTH)) {
                result.best_move=Some(best);result.score=None;
            }
            break;
        }
        result.best_move=Some(best);result.score=Some(alpha);result.completed_depth=depth;
        stats.worker_nodes=workers.iter().map(|w|w.nodes).collect();
        result.nodes=stats.worker_nodes.iter().sum();result.elapsed=start.elapsed();
        publish(&stats);
        progress(&result);
        if alpha.abs()>=WIN-i32::from(MAX_DEPTH) {break;}
    }
    stats.worker_nodes=workers.iter().map(|w|w.nodes).collect();
    result.nodes=stats.worker_nodes.iter().sum();result.elapsed=start.elapsed();
    publish(&stats);
    debug_assert_eq!(stats.spawned_threads,stats.joined_threads);
    Ok(Run {result,stats})
}

/// One interrupted whole raw child, with its original admitted window. The
/// worker identity is separate and retained by FinishAttempt, never inferred
/// from an actor, destination, completion order or move notation.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct FinishJob { index: usize, admitted_alpha: i32 }
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct FinishAttempt { worker: usize, job: FinishJob, value: Result<i32, ()> }

struct RootFinishGate { unopened: bool }
impl RootFinishGate {
    fn open(&mut self, at_soft: bool, at_hard: bool, diagnostic_expired: bool,
            incumbent: Option<HiveMove>, old_score: Option<i32>, best: HiveMove, alpha: i32) -> bool {
        if !self.unopened || !at_soft || at_hard || diagnostic_expired
            || !super::finish::partial_improver(incumbent,old_score,Some(best),alpha) {
            return false;
        }
        self.unopened=false;
        true
    }
}

/// Join the whole batch before returning any attempt or publishing progress.
/// A hard batch first retries each worker's own failed raw child/window; only
/// then can that worker take a previously unstarted index from the common queue.
fn finish_batch<E>(workers: &mut [Search], board: &Board, moves: &[HiveMove], depth: u8,
    certified: &Mutex<CertifiedRoot>, unstarted: &[usize], retries: &[Vec<FinishJob>],
    stats: &mut Stats, execute: &E) -> Vec<FinishAttempt>
where E: Fn(usize, &mut Search, &Board, HiveMove, u8, i32) -> Result<i32, ()> + Sync
{
    assert_eq!(workers.len(),retries.len());
    if unstarted.is_empty() && retries.iter().all(Vec::is_empty) {return Vec::new();}
    let next=AtomicUsize::new(0);let active=AtomicUsize::new(0);let peak=AtomicUsize::new(0);
    let count=workers.len();
    let batches=std::thread::scope(|scope| {
        let mut handles=Vec::with_capacity(count);
        for (id,worker) in workers.iter_mut().enumerate() {
            let next=&next;let active=&active;let peak=&peak;let local=&retries[id];
            handles.push(scope.spawn(move || {
                super::trained::start_search();let mut rows=Vec::new();let mut retry=local.iter();
                loop {
                    if worker.expired() {break;}
                    let job=if let Some(&job)=retry.next() {job} else {
                        let slot=next.fetch_add(1,Ordering::SeqCst);
                        let Some(&index)=unstarted.get(slot) else {break;};
                        FinishJob {index,admitted_alpha:certified.lock().expect("root certificate poisoned").admitted_alpha(index)}
                    };
                    let current=active.fetch_add(1,Ordering::SeqCst)+1;
                    peak.fetch_max(current,Ordering::SeqCst);let _active=Active(active);
                    let value=execute(id,worker,board,moves[job.index],depth,job.admitted_alpha);
                    certified.lock().expect("root certificate poisoned").record(job.index,job.admitted_alpha,value);
                    rows.push(FinishAttempt {worker:id,job,value});
                    if value.is_err() {break;}
                }
                (id,rows,super::trained::stats())
            }));
        }
        handles.into_iter().map(|h|h.join().expect("Parallel Finish worker panicked")).collect::<Vec<_>>()
    });
    stats.spawned_threads+=count as u64;stats.joined_threads+=count as u64;
    stats.peak_active_searches=stats.peak_active_searches.max(peak.load(Ordering::SeqCst));
    let mut rows=Vec::new();
    for (id,batch,model_stats) in batches {
        super::trained::merge_worker_stats(model_stats);
        add_model(&mut stats.worker_model_stats[id],model_stats);
        stats.worker_root_jobs[id]+=batch.len() as u64;rows.extend(batch);
    }
    rows
}

fn unfinished_finish_jobs(rows: &[FinishAttempt], move_count: usize, worker_count: usize)
    -> (Vec<Vec<FinishJob>>,Vec<usize>,Vec<bool>)
{
    let mut seen=vec![false;move_count];seen[0]=true;
    let mut complete=seen.clone();let mut retries=vec![Vec::new();worker_count];
    for row in rows {
        assert!(row.worker<worker_count && row.job.index>0 && row.job.index<move_count);
        assert!(!seen[row.job.index],"one soft attempt per raw index");seen[row.job.index]=true;
        match row.value {
            Ok(_) => complete[row.job.index]=true,
            Err(()) => retries[row.worker].push(row.job),
        }
    }
    let unstarted=(1..move_count).filter(|&i|!seen[i]).collect();
    (retries,unstarted,complete)
}

pub(crate) fn finish(board: &Board, history: &[Position], threads: u8, start: Instant,
    soft: crate::deadline::Deadline, hard: crate::deadline::Deadline, allow_extension: bool,
    progress: impl FnMut(&SearchResult, &super::finish::CompletionMeta) -> Result<(),String>)
    -> Result<(SearchResult,super::finish::CompletionMeta),String>
{
    finish_impl(board,history,threads,start,soft,hard,allow_extension,MAX_DEPTH,
        &|_,worker,board,mv,depth,alpha|child(worker,board,mv,depth,alpha),
        &|| (soft.expired(),hard.expired()),progress)
}

// The explicit executor/clock inputs permit deterministic scheduler/goal tests
// without timing races. Production always passes child() and the two original
// absolute deadlines above; no caller can replace those inputs through UHP.
fn finish_impl<E,C>(board: &Board, history: &[Position], threads: u8, start: Instant,
    soft: crate::deadline::Deadline, hard: crate::deadline::Deadline, allow_extension: bool,
    depth_limit: u8, execute: &E, clocks: &C,
    mut progress: impl FnMut(&SearchResult, &super::finish::CompletionMeta) -> Result<(),String>)
    -> Result<(SearchResult,super::finish::CompletionMeta),String>
where E: Fn(usize, &mut Search, &Board, HiveMove, u8, i32) -> Result<i32, ()> + Sync,
      C: Fn() -> (bool,bool)
{
    assert!((2..=MAX_THREADS).contains(&threads));
    super::trained::start_search();
    let mut stats=Stats {configured_threads:threads,peak_active_searches:0,
        worker_nodes:vec![0;usize::from(threads)],worker_root_jobs:vec![0;usize::from(threads)],
        spawned_threads:0,joined_threads:0,worker_model_stats:vec![super::trained::Stats::default();usize::from(threads)]};
    publish(&stats);
    let mut result=SearchResult {best_move:None,score:terminal(board,0),completed_depth:0,nodes:0,elapsed:Duration::ZERO};
    let mut completion=super::finish::CompletionMeta::default();
    let root=Position::new(board);
    if result.score.is_none() && history.iter().filter(|p|root.same_repetition(p,board)).take(3).count()==3 {
        result.score=Some(0);
    }
    if result.score.is_some() {result.elapsed=start.elapsed();return Ok((result,completion));}
    let mut moves=board.legal_moves();result.best_move=moves.first().copied();
    let mut workers=Vec::with_capacity(usize::from(threads));
    for _ in 0..threads {
        if soft.expired() {result.elapsed=start.elapsed();return Ok((result,completion));}
        workers.push(worker(history,Some(soft)));
    }
    let mut ordering_board=board.clone();let mut gate=RootFinishGate {unopened:allow_extension};
    for depth in 1..=depth_limit.min(MAX_DEPTH) {
        if workers[0].expired() || moves.is_empty() {break;}
        if depth==2 && workers[0].order_moves(&mut ordering_board,&mut moves,0).is_err() {break;}
        if let Some(i)=moves.iter().position(|m|Some(*m)==result.best_move) {moves.swap(0,i);}
        stats.worker_root_jobs[0]+=1;stats.peak_active_searches=stats.peak_active_searches.max(1);
        let before_model=super::trained::stats();
        let first=execute(0,&mut workers[0],board,moves[0],depth,-WIN-1);
        let after_model=super::trained::stats();
        add_model(&mut stats.worker_model_stats[0],super::trained::Stats {
            applications:after_model.applications-before_model.applications,
            moves_ranked:after_model.moves_ranked-before_model.moves_ranked,
            changed_orders:after_model.changed_orders-before_model.changed_orders});
        // Without a completed first child there is no certified improvement
        // that could justify Finish. Never reopen on this interruption.
        let Ok(first)=first else {break;};
        let certified=Mutex::new(CertifiedRoot {score:first,ordinal:0});
        let unstarted:Vec<_>=(1..moves.len()).collect();
        let empty=vec![Vec::new();usize::from(threads)];
        let soft_rows=finish_batch(&mut workers,board,&moves,depth,&certified,&unstarted,&empty,&mut stats,execute);
        let (retries,unstarted,mut complete)=unfinished_finish_jobs(&soft_rows,moves.len(),usize::from(threads));
        if !complete.iter().all(|&v|v) {
            let winner=*certified.lock().expect("root certificate poisoned");
            let (at_soft,at_hard)=clocks();
            if gate.open(at_soft,at_hard,super::residual::phase_expired()||super::coverage::phase_expired(),
                result.best_move,result.score,moves[winner.ordinal],winner.score) {
                completion.extended=true;completion.goal_depth=Some(depth);
                for worker in &mut workers {worker.deadline=Some(hard);}
                let hard_rows=finish_batch(&mut workers,board,&moves,depth,&certified,&unstarted,&retries,&mut stats,execute);
                for row in hard_rows {if row.value.is_ok(){complete[row.job.index]=true;}}
            }
        }
        let winner=*certified.lock().expect("root certificate poisoned");
        stats.worker_nodes=workers.iter().map(|w|w.nodes).collect();
        result.nodes=stats.worker_nodes.iter().sum();result.elapsed=start.elapsed();publish(&stats);
        if !complete.iter().all(|&v|v) {
            if super::finish::partial_improver(result.best_move,result.score,Some(moves[winner.ordinal]),winner.score) {
                result.best_move=Some(moves[winner.ordinal]);result.score=None;
            }
            break;
        }
        result.best_move=Some(moves[winner.ordinal]);result.score=Some(winner.score);result.completed_depth=depth;
        if completion.extended {completion.finished=true;}
        progress(&result,&completion)?;
        if completion.extended || winner.score.abs()>=WIN-i32::from(MAX_DEPTH) {break;}
    }
    stats.worker_nodes=workers.iter().map(|w|w.nodes).collect();
    result.nodes=stats.worker_nodes.iter().sum();result.elapsed=start.elapsed();publish(&stats);
    debug_assert_eq!(stats.spawned_threads,stats.joined_threads);
    Ok((result,completion))
}

#[cfg(test)]
mod cooperative_root_contracts {
    use super::*;
    use crate::{GameType,UhpGame,UhpEngine};

    fn archived(plies: usize) -> (Board,Vec<Position>) {
        let row=include_str!("../tests/archive_repetition.txt").lines().next().unwrap();
        let mut game=UhpGame::new(GameType::mlp());
        let mut history=vec![Position::new(game.board())];
        for text in row.split('|').nth(2).unwrap().split(';').take(plies) {
            game.play(text).unwrap();history.push(Position::new(game.board()));
        }
        (game.board().clone(),history)
    }

    #[test]
    fn completed_exact_above_own_window_only_never_upper_or_interrupted() {
        let mut root=CertifiedRoot {score:10,ordinal:0};
        for value in [Err(()),Ok(9),Ok(10)] {
            assert!(!root.record(3,10,value));
            assert_eq!(root,CertifiedRoot {score:10,ordinal:0});
        }
        assert!(root.record(5,10,Ok(20)));
        // A stale but exact completed result below the new winner is harmless.
        assert!(!root.record(4,10,Ok(15)));
        let earlier=root.admitted_alpha(2);
        assert_eq!(earlier,19);
        assert!(!root.record(2,earlier,Ok(19)),"an upper bound cannot tie");
        assert!(root.record(2,earlier,Ok(20)),"strictly above own19 proves equal20");
        assert_eq!(root,CertifiedRoot {score:20,ordinal:2});
        assert!(!root.record(7,20,Ok(20)),"later equal-window fail-low cannot replace it");
    }

    #[test]
    fn reordered_completion_and_conservative_fail_low_keep_fixed_ordinal_tie() {
        let exact=[10,20,20,15,20,7];
        for order in [[1,2,3,4,5],[5,4,3,2,1],[3,2,5,1,4]] {
            let mut root=CertifiedRoot {score:exact[0],ordinal:0};
            for ordinal in order {
                let alpha=root.admitted_alpha(ordinal);
                // Model the least informative valid fail-hard upper return.
                let value=if exact[ordinal]>alpha {exact[ordinal]} else {alpha};
                root.record(ordinal,alpha,Ok(value));
            }
            assert_eq!(root,CertifiedRoot {score:20,ordinal:1});
        }
    }

    #[test]
    fn actual_mutex_delayed_earlier_job_recovers_exact_equal_witness() {
        let root=Mutex::new(CertifiedRoot {score:5,ordinal:0});
        let shared=&root;
        let (sent,received)=std::sync::mpsc::channel();
        std::thread::scope(|scope| {
            let later=scope.spawn(move || {
                assert!(shared.lock().unwrap().record(5,5,Ok(12)));
                sent.send(()).unwrap();
            });
            let earlier=scope.spawn(move || {
                received.recv().unwrap();
                let alpha=shared.lock().unwrap().admitted_alpha(2);
                assert_eq!(alpha,11);
                assert!(shared.lock().unwrap().record(2,alpha,Ok(12)));
            });
            later.join().unwrap();earlier.join().unwrap();
        });
        assert_eq!(*root.lock().unwrap(),CertifiedRoot {score:12,ordinal:2});
    }

    #[test]
    fn mate_band_tie_window_is_original_ply_score_without_renormalization() {
        for score in [-WIN+1,WIN-1] {
            let mut root=CertifiedRoot {score,ordinal:4};
            let alpha=root.admitted_alpha(1);
            assert_eq!(alpha,score-1);
            assert!(root.record(1,alpha,Ok(score)));
            assert_eq!(root,CertifiedRoot {score,ordinal:1});
        }
    }

    #[test]
    fn actual_complete_root_scores_match_full_window_child_oracle_both_sides() {
        for plies in [0,16,17] {
            let (board,history)=archived(plies);
            let before=format!("{board:?}");
            let moves=board.legal_moves();
            let mut oracle=worker(&history,None);
            let scores=moves.iter().map(|&mv|child(&mut oracle,&board,mv,2,-WIN-1).unwrap())
                .collect::<Vec<_>>();
            let best=*scores.iter().max().unwrap();
            for threads in [2,4,12] {
                let run=search(&board,SearchLimit::Depth(2),&history,threads,|_|{}).unwrap();
                assert_eq!(run.result.score,Some(best));
                assert_eq!(run.result.completed_depth,2);
                let selected=moves.iter().position(|mv|Some(*mv)==run.result.best_move).unwrap();
                assert_eq!(scores[selected],best,"selected raw child has exact oracle value");
                assert_eq!(run.stats.worker_nodes.iter().sum::<u64>(),run.result.nodes);
                assert_eq!(run.stats.spawned_threads,run.stats.joined_threads);
            }
            assert_eq!(format!("{board:?}"),before);
            assert_eq!(oracle.history.as_deref(),Some(history.as_slice()));
        }
    }

    #[test]
    fn full_history_not_board_only_and_failed_child_cannot_publish() {
        let (board,history)=archived(16);let p=Position::new(&board);
        let repeated=[p,p,p];
        let run=search(&board,SearchLimit::Depth(2),&repeated,4,|_|panic!("root threefold is terminal")).unwrap();
        assert_eq!(run.result.score,Some(0));assert_eq!(run.result.best_move,None);
        assert_eq!(run.stats.spawned_threads,0);
        let mut probe=worker(&history,None);probe.node_limit=Some(0);
        let mut certificate=CertifiedRoot {score:0,ordinal:0};
        let value=child(&mut probe,&board,board.legal_moves()[0],3,0);
        assert_eq!(value,Err(()));assert!(!certificate.record(1,0,value));
        assert_eq!(probe.history.as_deref(),Some(history.as_slice()));
        assert_eq!(certificate,CertifiedRoot {score:0,ordinal:0});
    }

    #[test]
    fn progress_sees_all_joins_and_zero_deadline_keeps_unscored_fallback() {
        let (board,history)=archived(16);let mut depths=Vec::new();
        let run=search(&board,SearchLimit::Depth(2),&history,4,|row| {
            let current=LATEST.with(|s|s.borrow().as_ref().unwrap().clone());
            assert_eq!(current.spawned_threads,current.joined_threads);
            assert_eq!(current.worker_nodes.iter().sum::<u64>(),row.nodes);
            assert!(row.score.is_some());depths.push(row.completed_depth);
        }).unwrap();
        assert_eq!(depths,vec![1,2]);assert_eq!(run.stats.spawned_threads,run.stats.joined_threads);
        let zero=search(&board,SearchLimit::Time(Duration::ZERO),&history,4,|_|panic!("no complete zero-time iteration")).unwrap();
        assert_eq!(zero.result.completed_depth,0);assert_eq!(zero.result.score,None);
        assert!(board.legal_moves().contains(&zero.result.best_move.unwrap()));
        assert_eq!(zero.stats.spawned_threads,zero.stats.joined_threads);
    }

    #[test]
    fn serial_delegate_and_typed_pillbug_mosquito_history_stay_unchanged() {
        for (text,bug) in [
            ("Base+MLP~0~20~wQ:-1:0:0,bQ:1:0:0,wP:0:0:0,bA1:1:-1:0,wM:0:-1:0~",Bug::Pillbug),
            ("Base+MLP~0~20~wQ:-1:0:0,bQ:1:0:0,wM:0:0:0,bA1:1:-1:0,wP:0:-1:0~",Bug::Mosquito),
        ] {
            let mut game=UhpGame::from_root(text).unwrap();
            let mv=game.board().legal_moves().into_iter().find(|mv|matches!(mv,HiveMove::Pillbug{actor,..} if actor.bug==bug)).unwrap();
            game.play_raw(mv).unwrap();let before=format!("{game:?}");
            let serial=game.search(SearchLimit::Depth(2));
            let configured=game.search_with_threads(SearchLimit::Depth(2),1).unwrap();
            assert_eq!((serial.best_move,serial.score,serial.completed_depth,serial.nodes),
                (configured.result.best_move,configured.result.score,configured.result.completed_depth,configured.result.nodes));
            let parallel=game.search_with_threads(SearchLimit::Depth(2),4).unwrap();
            assert_eq!(parallel.result.score,serial.score);
            assert_eq!(format!("{game:?}"),before);assert_eq!(game.history(),[mv]);
        }
    }

    #[test]
    fn readonly_cooperation_provenance_does_not_change_threads_or_raw_shapes() {
        let mut engine=UhpEngine::default();
        assert_eq!(engine.execute("options get RootAlphaCooperation"),["RootAlphaCooperation;bool;True"]);
        assert!(engine.execute("options set RootAlphaCooperation False")[0].starts_with("err "));
        assert_eq!(engine.execute("options get Threads"),["Threads;int;1;1;12"]);
        let state=engine.execute("state_raw");
        assert!(!state[0].contains("RootAlphaCooperation"));
    }
}

#[cfg(test)]
mod threaded_finish_contracts {
    use super::*;
    use crate::{GameType,UhpGame};
    use std::sync::atomic::AtomicBool;

    fn stats(threads:u8)->Stats {
        Stats {configured_threads:threads,peak_active_searches:0,worker_nodes:vec![0;usize::from(threads)],
            worker_root_jobs:vec![0;usize::from(threads)],spawned_threads:0,joined_threads:0,
            worker_model_stats:vec![super::super::trained::Stats::default();usize::from(threads)]}
    }
    fn archived(plies:usize)->UhpGame {
        let line=include_str!("../tests/archive_repetition.txt").lines().next().unwrap();
        let mut game=UhpGame::new(GameType::mlp());
        for text in line.split('|').nth(2).unwrap().split(';').take(plies){game.play(text).unwrap();}game
    }

    #[test]
    fn one_gate_requires_soft_not_hard_and_exact_finite_improver_never_diagnostic_error() {
        let moves=Board::new(GameType::base()).legal_moves();
        for (at_soft,at_hard,diagnostic) in [(false,false,false),(true,true,false),(true,false,true)] {
            let mut gate=RootFinishGate {unopened:true};
            assert!(!gate.open(at_soft,at_hard,diagnostic,Some(moves[0]),Some(0),moves[1],10));
            assert!(gate.unopened);
        }
        let mut gate=RootFinishGate {unopened:true};
        assert!(!gate.open(true,false,false,Some(moves[0]),Some(0),moves[0],10));
        assert!(!gate.open(true,false,false,Some(moves[0]),Some(WIN-2),moves[1],10));
        assert!(!gate.open(true,false,false,Some(moves[0]),Some(0),moves[1],-WIN));
        assert!(gate.open(true,false,false,Some(moves[0]),Some(0),moves[1],10));
        assert!(!gate.open(true,false,false,Some(moves[0]),Some(0),moves[2],20));
        let mut positive_mate=RootFinishGate {unopened:true};
        assert!(positive_mate.open(true,false,false,Some(moves[0]),Some(0),moves[1],WIN-2),
            "the unchanged serial predicate permits a new positive mate candidate against an old finite score");
        // A completed fail-low equal to its admitted alpha cannot supply the
        // certificate the gate consumes, even when its raw child differs.
        let mut exact=CertifiedRoot {score:10,ordinal:0};
        assert!(!exact.record(1,10,Ok(10)));assert_eq!(exact.ordinal,0);
        assert!(!exact.record(1,10,Err(())));assert_eq!(exact.ordinal,0);
    }

    #[test]
    fn ledger_partitions_completed_retry_and_unstarted_without_duplicating_completed_children() {
        let failed=FinishJob {index:3,admitted_alpha:12};
        let rows=[FinishAttempt {worker:0,job:FinishJob {index:1,admitted_alpha:0},value:Ok(12)},
            FinishAttempt {worker:2,job:failed,value:Err(())},
            FinishAttempt {worker:1,job:FinishJob {index:4,admitted_alpha:12},value:Ok(12)}];
        let (retries,unstarted,complete)=unfinished_finish_jobs(&rows,5,3);
        assert_eq!(retries,vec![vec![],vec![],vec![failed]]);assert_eq!(unstarted,vec![2]);
        assert_eq!(complete,vec![true,true,false,false,true]);
        assert!(!unstarted.contains(&1)&&!unstarted.contains(&4));
    }

    #[test]
    fn hard_batch_retries_exact_worker_raw_child_and_window_after_all_soft_joins() {
        let game=archived(17);let board=game.board();let moves=board.legal_moves();
        let history=game.exact_position_history();let original=game.raw_state_json();
        let soft=crate::deadline::Deadline::at(Instant::now()+Duration::from_secs(60));
        let hard=crate::deadline::Deadline::at(Instant::now()+Duration::from_secs(120));
        let mut workers=vec![worker(history,Some(soft)),worker(history,Some(soft))];
        let certified=Mutex::new(CertifiedRoot {score:0,ordinal:0});let mut counts=stats(2);
        let hard_phase=AtomicBool::new(false);let calls=Mutex::new(Vec::new());
        let execute=|id:usize,w:&mut Search,_:&Board,mv:HiveMove,_:u8,alpha:i32| {
            let index=moves.iter().position(|&m|m==mv).unwrap();
            assert_eq!(w.history.as_deref(),Some(history));w.nodes+=1;
            calls.lock().unwrap().push((id,index,alpha,hard_phase.load(Ordering::SeqCst)));
            if index==2 && !hard_phase.load(Ordering::SeqCst) {
                w.killers[1][0]=Some(mv);return Err(());
            }
            if index==2 {assert_eq!(w.killers[1][0],Some(mv));}
            Ok(if index==2{20}else if index==1{10}else{0})
        };
        let soft_rows=finish_batch(&mut workers,board,&moves,2,&certified,&[1,2,3],&[vec![],vec![]],&mut counts,&execute);
        assert_eq!(counts.spawned_threads,counts.joined_threads);
        let (retries,unstarted,mut complete)=unfinished_finish_jobs(&soft_rows,4,2);
        hard_phase.store(true,Ordering::SeqCst);for w in &mut workers {w.deadline=Some(hard);}
        let hard_rows=finish_batch(&mut workers,board,&moves,2,&certified,&unstarted,&retries,&mut counts,&execute);
        for row in hard_rows {if row.value.is_ok(){complete[row.job.index]=true;}}
        assert!(complete.iter().all(|&v|v));assert_eq!(counts.spawned_threads,counts.joined_threads);
        let calls=calls.lock().unwrap();let retried:Vec<_>=calls.iter().filter(|r|r.1==2).collect();
        assert_eq!(retried.len(),2);assert_eq!((retried[0].0,retried[0].2),(retried[1].0,retried[1].2));
        for i in [1,3] {assert_eq!(calls.iter().filter(|r|r.1==i).count(),1);}
        assert_eq!(game.raw_state_json(),original);
        assert!(workers.iter().all(|w|w.history.as_deref()==Some(history)));
    }

    #[test]
    fn actual_interrupted_child_restores_history_then_retries_on_same_private_search() {
        let game=archived(19);let before=game.raw_state_json();
        let mv=game.board().legal_moves().into_iter().find(|&mv| {
            let mut physical=game.clone();physical.play_raw(mv).unwrap();
            physical.state()==crate::uhp::GameState::InProgress
        }).unwrap();
        let history=game.exact_position_history();let mut same=worker(history,None);
        same.node_limit=Some(1);
        assert!(child(&mut same,game.board(),mv,3,-WIN-1).is_err());
        assert!(same.nodes>0);let spent=same.nodes;
        assert_eq!(same.history.as_deref(),Some(history));assert_eq!(game.raw_state_json(),before);
        same.node_limit=None;
        let retried=child(&mut same,game.board(),mv,3,-WIN-1).unwrap();
        let mut fresh=worker(history,None);
        let exact=child(&mut fresh,game.board(),mv,3,-WIN-1).unwrap();
        assert_eq!(retried,exact);assert!(same.nodes>spent);
        assert_eq!(same.history.as_deref(),Some(history));assert_eq!(game.raw_state_json(),before);
    }

    #[test]
    fn deterministic_goal_finishes_once_or_preserves_prior_eval_with_unscored_partial() {
        // Logical soft-expiry injection plus a controlled child executor avoids
        // a wall-clock race. Production uses actual child() and original clocks.
        for finish_goal in [true,false] {
            let game=UhpGame::new(GameType::base());let board=game.board();let raw=board.legal_moves();
            let before=game.raw_state_json();let calls=Mutex::new(Vec::new());
            let soft_seen=AtomicBool::new(false);let failures=AtomicUsize::new(0);
            let execute=|id:usize,w:&mut Search,_:&Board,mv:HiveMove,depth:u8,alpha:i32| {
                let index=raw.iter().position(|&m|m==mv).unwrap();w.nodes+=1;
                assert_eq!(w.history.as_deref(),Some(game.exact_position_history()));
                calls.lock().unwrap().push((depth,index,id,alpha));
                if depth==2 && index==2 {
                    let attempt=failures.fetch_add(1,Ordering::SeqCst);
                    if attempt==0 || !finish_goal {soft_seen.store(true,Ordering::SeqCst);return Err(());}
                }
                Ok(if depth==1{0}else if index==2{20}else if index==1{10}else{0})
            };
            let start=Instant::now();let soft=crate::deadline::Deadline::at(start+Duration::from_secs(60));
            let hard=crate::deadline::Deadline::at(start+Duration::from_secs(120));let mut reports=Vec::new();
            let (result,meta)=finish_impl(board,game.exact_position_history(),2,start,soft,hard,true,4,
                &execute,&|| (soft_seen.load(Ordering::SeqCst),false),|row,meta| {
                    let actual=LATEST.with(|s|s.borrow().as_ref().unwrap().clone());
                    assert_eq!(actual.spawned_threads,actual.joined_threads);
                    assert_eq!(actual.worker_nodes.iter().sum::<u64>(),row.nodes);
                    reports.push((row.clone(),*meta));Ok(())
                }).unwrap();
            assert!(meta.extended);assert_eq!(meta.goal_depth,Some(2));assert_eq!(meta.finished,finish_goal);
            assert_eq!(reports[0].0.completed_depth,1);assert_eq!(reports[0].0.score,Some(0));
            if finish_goal {
                assert_eq!(result.completed_depth,2);assert_eq!(result.score,Some(20));
                assert_eq!(result.best_move,Some(raw[2]));assert_eq!(reports.len(),2);
            } else {
                assert_eq!(result.completed_depth,1);assert_eq!(result.score,None);
                assert_eq!(result.best_move,Some(raw[1]));assert_eq!(reports.len(),1);
            }
            let calls=calls.lock().unwrap();assert!(calls.iter().all(|r|r.0<=2),"no deeper goal after extension");
            let retry:Vec<_>=calls.iter().filter(|r|r.0==2&&r.1==2).collect();
            assert_eq!(retry.len(),2);assert_eq!((retry[0].2,retry[0].3),(retry[1].2,retry[1].3));
            assert_eq!(game.raw_state_json(),before);
        }
    }

    #[test]
    fn completed_real_full_history_horizons_match_ordinary_parallel_oracle_and_all_joins() {
        if super::super::trained::mode()!="original" {return;}
        let mut games=vec![archived(17)];
        for (setup,bug) in [
            ("Base+MLP~0~20~wQ:-1:0:0,bQ:1:0:0,wP:0:0:0,bA1:1:-1:0,wM:0:-1:0~",Bug::Pillbug),
            ("Base+MLP~0~20~wQ:-1:0:0,bQ:1:0:0,wM:0:0:0,bA1:1:-1:0,wP:0:-1:0~",Bug::Mosquito)] {
            let mut game=UhpGame::from_root(setup).unwrap();
            let raw=game.board().legal_moves().into_iter().find(|m|matches!(m,HiveMove::Pillbug{actor,..}if actor.bug==bug)).unwrap();
            game.play_raw(raw).unwrap();games.push(game);
        }
        for game in games {
            let before=game.raw_state_json();let expected=game.search_with_threads(SearchLimit::Depth(3),4).unwrap();
            let start=Instant::now();let soft=crate::deadline::Deadline::at(start+Duration::from_secs(60));
            let hard=crate::deadline::Deadline::at(start+Duration::from_secs(120));
            let (result,meta)=finish_impl(game.board(),game.exact_position_history(),4,start,soft,hard,false,3,
                &|_,w,b,m,d,a|child(w,b,m,d,a),&|| (soft.expired(),hard.expired()),|row,_| {
                    let current=LATEST.with(|s|s.borrow().as_ref().unwrap().clone());
                    assert_eq!(current.spawned_threads,current.joined_threads);
                    assert_eq!(current.worker_nodes.iter().sum::<u64>(),row.nodes);Ok(())
                }).unwrap();
            assert_eq!((result.best_move,result.score,result.completed_depth),
                (expected.result.best_move,expected.result.score,expected.result.completed_depth));
            assert_eq!(meta,super::super::finish::CompletionMeta::default());assert_eq!(game.raw_state_json(),before);
        }
    }

    #[test]
    fn progress_failure_is_fatal_after_joins_without_another_iteration_or_allowance() {
        if super::super::trained::mode()!="original" {return;}
        let game=archived(17);let before=game.raw_state_json();let start=Instant::now();
        let soft=crate::deadline::Deadline::at(start+Duration::from_secs(60));
        let hard=crate::deadline::Deadline::at(start+Duration::from_secs(120));let mut reports=0;
        let error=finish_impl(game.board(),game.exact_position_history(),4,start,soft,hard,true,3,
            &|_,w,b,m,d,a|child(w,b,m,d,a),&|| (soft.expired(),hard.expired()),|row,meta| {
                reports+=1;assert_eq!(row.completed_depth,1);assert!(!meta.extended);
                let current=LATEST.with(|s|s.borrow().as_ref().unwrap().clone());
                assert_eq!(current.spawned_threads,current.joined_threads);
                Err("synthetic durable Finish progress failure".into())
            }).unwrap_err();
        assert!(error.contains("durable Finish progress"));assert_eq!(reports,1);assert_eq!(game.raw_state_json(),before);
    }
}

#[cfg(test)]
mod threaded_finish_no_extension_contracts {
    use super::*;
    use crate::{GameType,UhpGame};

    #[test]
    fn interrupted_first_or_no_certified_changed_pv_never_reopens_hard_allowance() {
        for first_fails in [true,false] {
            let game=UhpGame::new(GameType::base());let raw=game.board().legal_moves();
            let before=game.raw_state_json();let calls=Mutex::new(Vec::new());
            let execute=|id:usize,w:&mut Search,_:&Board,mv:HiveMove,depth:u8,alpha:i32| {
                let index=raw.iter().position(|&m|m==mv).unwrap();w.nodes+=1;
                calls.lock().unwrap().push((id,index,depth,alpha));
                if first_fails || (depth==2&&index==2) {Err(())}else{Ok(0)}
            };
            let start=Instant::now();let soft=crate::deadline::Deadline::at(start+Duration::from_secs(60));
            let hard=crate::deadline::Deadline::at(start+Duration::from_secs(120));
            let (result,meta)=finish_impl(game.board(),game.exact_position_history(),2,start,soft,hard,true,3,
                &execute,&|| (true,false),|_,_|Ok(())).unwrap();
            assert_eq!(meta,super::super::finish::CompletionMeta::default());
            let calls=calls.lock().unwrap();
            if first_fails {assert_eq!(calls.len(),1);assert_eq!(result.completed_depth,0);}
            else {
                assert_eq!(result.completed_depth,1);assert_eq!(result.score,Some(0));
                assert_eq!(calls.iter().filter(|r|r.2==2&&r.1==2).count(),1,"no hard retry without improvement");
            }
            let stats=LATEST.with(|s|s.borrow().as_ref().unwrap().clone());
            assert_eq!(stats.spawned_threads,stats.joined_threads);assert_eq!(game.raw_state_json(),before);
        }
    }
}
