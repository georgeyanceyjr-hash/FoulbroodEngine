// Additive exact raw developer protocol. Ordinary UHP methods stay unchanged.
fn raw_json_quote(text: &str) -> String {
    let mut out=String::from("\"");
    for c in text.chars() { match c {
        '"'=>out.push_str("\\\""), '\\'=>out.push_str("\\\\"), '\n'=>out.push_str("\\n"),
        '\r'=>out.push_str("\\r"), '\t'=>out.push_str("\\t"),
        c if c<' '=>out.push_str(&format!("\\u{:04x}",c as u32)), c=>out.push(c),
    }} out.push('"');out
}
fn raw_json_move(mv: Option<HiveMove>) -> String {
    mv.map_or("null".into(),crate::search::residual::raw_action_json)
}
fn raw_model_identity() -> String {
    crate::search::trained::model_sha256().map_or("null".into(),raw_json_quote)
}

/// Exactly seven decimal/underscore fields, never notation or actor inference.
pub fn raw_move_from_fields(text: &str) -> Result<HiveMove,String> {
    let parts:Vec<_>=text.split_whitespace().collect();
    if parts.len()!=7 {return Err("raw move requires KIND ACTOR PIECE FQ FR TQ TR".into());}
    let number=|x:&str|x.parse::<u8>().map_err(|_|"invalid raw kind/piece ID".to_string());
    let (kind,actor,piece)=(number(parts[0])?,number(parts[1])?,number(parts[2])?);
    let coordinate=|a:&str,b:&str|->Result<Option<Hex>,String>{
        if a=="_"&&b=="_" {return Ok(None);}
        if a=="_"||b=="_" {return Err("raw coordinates must both be absent or both be i16".into());}
        Ok(Some(Hex::new(a.parse::<i16>().map_err(|_|"raw q must be i16")?,
            b.parse::<i16>().map_err(|_|"raw r must be i16")?)))
    };
    let from=coordinate(parts[3],parts[4])?;let to=coordinate(parts[5],parts[6])?;
    let physical=|id:u8|->Result<Piece,String>{
        if id>=28 {return Err("physical raw piece ID must be0..27".into());}
        Color::ALL.into_iter().flat_map(|c|Piece::all_for(c,GameType::mlp()))
            .find(|p|p.id()==usize::from(id)).ok_or("raw piece ID not in exact slot map".into())
    };
    match(kind,actor,piece,from,to) {
        (3,28,28,None,None)=>Ok(HiveMove::Pass),
        (0,a,p,None,Some(to))if a==p=>Ok(HiveMove::Place{piece:physical(p)?,to}),
        (1,a,p,Some(from),Some(to))if a==p=>Ok(HiveMove::Move{piece:physical(p)?,from,to}),
        (2,a,p,Some(from),Some(to))=>Ok(HiveMove::Pillbug{actor:physical(a)?,piece:physical(p)?,from,to}),
        _=>Err("raw kind/actor/piece/from/to shape mismatch".into()),
    }
}
pub fn raw_move_fields(mv: HiveMove) -> String {
    let coordinate=|x:Option<Hex>|x.map_or("_ _".into(),|p|format!("{} {}",p.q,p.r));
    let(kind,actor,piece,from,to)=match mv {
        HiveMove::Place{piece,to}=>(0,piece.id(),piece.id(),None,Some(to)),
        HiveMove::Move{piece,from,to}=>(1,piece.id(),piece.id(),Some(from),Some(to)),
        HiveMove::Pillbug{actor,piece,from,to}=>(2,actor.id(),piece.id(),Some(from),Some(to)),
        HiveMove::Pass=>(3,28,28,None,None),
    };
    format!("{kind} {actor} {piece} {} {}",coordinate(from),coordinate(to))
}

impl UhpGame {
    pub fn raw_board_json(&self) -> String {
        let b=&self.board;let mut pieces=Vec::new();let mut reserve=Vec::new();
        for color in Color::ALL { for piece in Piece::all_for(color,b.game_type()) {
            if b.is_in_hand(piece){reserve.push(piece.id().to_string());}
            else if let Some(hex)=b.location(piece){
                let level=b.stack(hex).expect("located stack").iter().position(|p|*p==piece).expect("located piece");
                pieces.push(format!(r#"{{"id":{},"q":{},"r":{},"level":{}}}"#,piece.id(),hex.q,hex.r,level));
            }
        }}
        let variant=b.game_type();
        format!(r#"{{"variant":{{"mosquito":{},"ladybug":{},"pillbug":{}}},"pieces":[{}],"reserve":[{}],"side":{},"ply":{},"turns_taken":[{},{}],"last_move":{},"last_physically_moved_piece":{}}}"#,
            variant.mosquito,variant.ladybug,variant.pillbug,pieces.join(","),reserve.join(","),b.side_to_move().index(),b.ply(),
            b.turns_taken(Color::White),b.turns_taken(Color::Black),raw_json_move(self.history().last().copied()),
            b.last_physically_moved_piece().map_or("null".into(),|p|p.id().to_string()))
    }
    pub fn raw_state_json(&self) -> String {
        format!(r#"{{"schema_version":1,"game":{},"board":{},"raw_history":[{}],"positions":{},"current_position":{},"residual_order":{},"model_sha256":{}}}"#,
            raw_json_quote(&self.game_string()),self.raw_board_json(),self.moves.iter().copied().map(crate::search::residual::raw_action_json).collect::<Vec<_>>().join(","),
            self.witness_positions_json(),self.witness_current_position_json(),raw_json_quote(crate::search::trained::mode()),raw_model_identity())
    }
}

fn raw_limit(args:&str)->Result<crate::search::SearchLimit,String>{
    use crate::search::SearchLimit;
    let parts:Vec<_>=args.split_whitespace().collect();
    if parts.len()!=2 {return Err("bestmove_raw requires depth N, time hh:mm:ss, or milliseconds N".into());}
    match parts[0] {
        "time"=>parse_time_limit(parts[1]).map(SearchLimit::Time),
        "depth"=>parts[1].parse::<u8>().ok().filter(|&d|d<=64).map(SearchLimit::Depth)
            .ok_or("raw depth requires integer0..64".into()),
        "milliseconds"=>{
            if !parts[1].bytes().all(|c|c.is_ascii_digit()) {return Err("raw milliseconds requires unsigned decimal".into());}
            parts[1].parse::<u64>().ok().filter(|&n|n<=86_400_000)
                .map(|n|SearchLimit::Time(std::time::Duration::from_millis(n)))
                .ok_or("raw milliseconds requires integer0..86400000".into())
        },
        _=>Err("unknown bestmove_raw limit".into()),
    }
}
fn raw_search_report(event:&str,status:&str,result:&crate::search::SearchResult,
    evaluated:Option<&crate::search::SearchResult>,threads:u8)->String {
    let score=result.score.filter(|_|result.completed_depth>0);
    let evaluated_score=evaluated.and_then(|r|r.score);
    let stats=crate::search::trained::stats();
    format!(r#"{{"schema_version":1,"event":{},"status":{},"completed_depth":{},"score":{},"selected_raw":{},"eval_raw":{},"eval_score":{},"nodes":{},"elapsed_ns":{},"residual_order":{},"model_sha256":{},"residual_applications":{},"residual_moves_ranked":{},"residual_changed_orders":{},"threads":{},"parallel":{}}}"#,
        raw_json_quote(event),raw_json_quote(status),result.completed_depth,score.map_or("null".into(),|s|s.to_string()),
        raw_json_move(result.best_move),raw_json_move(evaluated.and_then(|r|r.best_move)),evaluated_score.map_or("null".into(),|s|s.to_string()),
        result.nodes,result.elapsed.as_nanos(),raw_json_quote(crate::search::trained::mode()),raw_model_identity(),
        stats.applications,stats.moves_ranked,stats.changed_orders,threads,crate::search::parallel::report_json(threads,result.nodes))
}

fn raw_finish_budget(args:&str)->Result<crate::search::finish::CompletionBudget,String>{
    let parts:Vec<_>=args.split_whitespace().collect();
    if parts.len()!=2 || parts.iter().any(|s|s.is_empty() || !s.bytes().all(|b|b.is_ascii_digit())) {
        return Err("finish_ms requires exactly two unsigned decimal millisecond allowances".into());
    }
    let soft=parts[0].parse::<u64>().map_err(|_|"invalid finish_ms soft allowance")?;
    let hard=parts[1].parse::<u64>().map_err(|_|"invalid finish_ms hard allowance")?;
    crate::search::finish::CompletionBudget::new(soft,hard)
}
fn raw_finish_report(event:&str,status:&str,result:&crate::search::SearchResult,
    evaluated:Option<&crate::search::SearchResult>,budget:crate::search::finish::CompletionBudget,
    completion:crate::search::finish::CompletionMeta)->String {
    let mut json=raw_search_report(event,status,result,evaluated,1);
    assert_eq!(json.pop(),Some('}'));
    json.push_str(&format!(",\"completion\":{}}}",completion.json(budget)));
    json
}

fn raw_threaded_finish_report(event:&str,status:&str,result:&crate::search::SearchResult,
    evaluated:Option<&crate::search::SearchResult>,budget:crate::search::finish::CompletionBudget,
    completion:crate::search::finish::CompletionMeta,threads:u8)->String {
    if threads==1 {return raw_finish_report(event,status,result,evaluated,budget,completion);}
    let mut json=raw_search_report(event,status,result,evaluated,threads);
    assert_eq!(json.pop(),Some('}'));
    json.push_str(&format!(",\"completion\":{}}}",completion.json(budget)));
    json
}

impl UhpEngine {
    fn cmd_play_raw_all_actors(&mut self, args: &str) -> Vec<String> {
        match raw_move_from_fields(args).and_then(|mv| self.game.play_raw_all_actors(mv)) {
            Ok(()) => vec![format!(r#"{{"schema_version":1,"membership_domain":"all_legal_actor_aliases_v1","state":{}}}"#,
                self.game.raw_state_json())],
            Err(e) => vec![format!("invalidmove {e}")],
        }
    }
    fn cmd_probe_raw_all_actors(&self, args: &str) -> Vec<String> {
        let mv = match raw_move_from_fields(args) {
            Ok(mv) => mv, Err(e) => return vec![format!("invalidmove {e}")],
        };
        let mut child = self.game.clone();
        match child.play_raw_all_actors(mv) {
            Ok(()) => vec![format!(r#"{{"schema_version":1,"membership_domain":"all_legal_actor_aliases_v1","raw_move":{},"state":{}}}"#,
                raw_json_move(Some(mv)), child.raw_state_json())],
            Err(e) => vec![format!("invalidmove {e}")],
        }
    }
    fn cmd_validmoves_raw_all_actors(&self, args: &str) -> Vec<String> {
        if !args.is_empty() { return vec!["err validmoves_raw_all_actors takes no parameters".into()]; }
        let mut rows = Vec::new();
        if !matches!(self.game.state(), GameState::Draw | GameState::WhiteWins | GameState::BlackWins) {
            for mv in self.game.board.legal_moves_all_actors() {
                match move_to_uhp(&self.game.board, mv) {
                    Ok(text) => rows.push(format!(r#"{{"raw_move":{},"notation":{}}}"#,
                        raw_json_move(Some(mv)), raw_json_quote(&text))),
                    Err(e) => return vec![format!("err {e}")],
                }
            }
        }
        vec![format!(r#"{{"schema_version":1,"membership_domain":"all_legal_actor_aliases_v1","state":{},"moves":[{}]}}"#,
            self.game.raw_state_json(), rows.join(","))]
    }
    fn cmd_model_predict_raw(&self,args:&str)->Vec<String>{
        let parts:Vec<_>=args.split_whitespace().collect();
        if parts.len()!=22{return vec!["err model_predict_raw requires exactly22 finite features".into()];}
        let mut features=[0.0;22];
        for(i,text)in parts.iter().enumerate(){
            match text.parse::<f64>() {Ok(x)if x.is_finite()=>features[i]=x,
                _=>return vec!["err model_predict_raw requires finite f64 features".into()]}
        }
        match crate::search::trained::predict_features(&features){
            Ok(p)=>vec![format!(r#"{{"schema_version":1,"probability":{},"log_node_cost":{},"predicted_cost":{},"priority":{},"model_sha256":{}}}"#,
                p.probability,p.log_node_cost,p.predicted_cost,p.priority,raw_json_quote(crate::search::trained::MODEL_SHA256))],
            Err(e)=>vec![format!("err {e}")],
        }
    }
    fn cmd_state_raw(&self,args:&str)->Vec<String>{
        if !args.is_empty(){return vec!["err state_raw takes no parameters".into()];}
        vec![self.game.raw_state_json()]
    }
    fn cmd_play_raw(&mut self,args:&str)->Vec<String>{
        match raw_move_from_fields(args).and_then(|mv|self.game.play_raw(mv)) {
            Ok(())=>vec![self.game.raw_state_json()],Err(e)=>vec![format!("invalidmove {e}")],
        }
    }
    /// Observe one exact legal child on a disposable FULL-history clone.
    /// No notation roundtrip, live mutation, search, model call or cached result.
    fn cmd_probe_raw(&self,args:&str)->Vec<String>{
        let mv=match raw_move_from_fields(args){Ok(mv)=>mv,Err(e)=>return vec![format!("invalidmove {e}")]};
        let mut child=self.game.clone();
        match child.play_raw(mv){
            Ok(())=>vec![format!(r#"{{"schema_version":1,"raw_move":{},"game":{},"board":{},"current_position":{}}}"#,
                raw_json_move(Some(mv)),raw_json_quote(&child.game_string()),child.raw_board_json(),child.witness_current_position_json())],
            Err(e)=>vec![format!("invalidmove {e}")],
        }
    }
    fn cmd_validmoves_raw(&self,args:&str)->Vec<String>{
        if !args.is_empty(){return vec!["err validmoves_raw takes no parameters".into()];}
        let mut rows=Vec::new();
        if !matches!(self.game.state(),GameState::Draw|GameState::WhiteWins|GameState::BlackWins){
            for mv in self.game.board.legal_moves(){
                match move_to_uhp(&self.game.board,mv){
                    Ok(text)=>rows.push(format!(r#"{{"raw_move":{},"notation":{}}}"#,
                        crate::search::residual::raw_action_json(mv),raw_json_quote(&text))),
                    Err(e)=>return vec![format!("err {e}")],
                }
            }
        }
        vec![format!(r#"{{"schema_version":1,"game":{},"moves":[{}],"residual_order":{},"model_sha256":{}}}"#,
            raw_json_quote(&self.game.game_string()),rows.join(","),raw_json_quote(crate::search::trained::mode()),raw_model_identity())]
    }
    fn cmd_bestmove_raw(&self,args:&str)->Vec<String>{
        if let Some(finish_args)=args.strip_prefix("finish_ms "){return self.cmd_finish_raw(finish_args);}
        let limit=match raw_limit(args){Ok(v)=>v,Err(e)=>return vec![format!("err {e}")]};
        if matches!(self.game.state(),GameState::Draw|GameState::WhiteWins|GameState::BlackWins){
            return vec!["err game is over; no raw recommendation".into()];
        }
        let threads=self.effective_threads();
        let mut complete=None;
        let run=self.game.search_with_threads_and_progress(limit,threads,|row|{
            if row.completed_depth>0&&row.score.is_some()&&row.best_move.is_some(){
                eprintln!("{}",raw_search_report("iteration","complete",row,Some(row),threads));
                complete=Some(row.clone());
            }
        });
        let result=match run {Ok(run)=>run.result,Err(error)=>return vec![format!("err {error}")]};
        if result.best_move.is_none(){return vec!["err no raw recommendation".into()];}
        let(status,evaluated)=if result.completed_depth>0&&result.score.is_some(){("complete",Some(&result))}
            else if complete.is_some(){("partial",complete.as_ref())}else{("fallback",None)};
        vec![raw_search_report("final",status,&result,evaluated,threads)]
    }
    fn cmd_finish_raw(&self,args:&str)->Vec<String>{
        let budget=match raw_finish_budget(args){Ok(v)=>v,Err(e)=>return vec![format!("err {e}")]};
        let threads=self.effective_threads();
        if crate::search::trained::mode()!="original"{return vec!["err finish_ms requires original compile mode".into()];}
        if matches!(self.game.state(),GameState::Draw|GameState::WhiteWins|GameState::BlackWins){
            return vec!["err game is over; no raw recommendation".into()];
        }
        let mut complete=None;
        let run=self.game.finish_with_threads_and_progress(budget,threads,|row,meta|{
            if row.completed_depth>0&&row.score.is_some()&&row.best_move.is_some(){
                eprintln!("{}",raw_threaded_finish_report("iteration","complete",row,Some(row),budget,*meta,threads));
                complete=Some(row.clone());
            }
            Ok(())
        });
        let run=match run{Ok(run)=>run,Err(error)=>return vec![format!("err {error}")]};
        let result=&run.result;
        if result.best_move.is_none(){return vec!["err no raw recommendation".into()];}
        let(status,evaluated)=if result.completed_depth>0&&result.score.is_some(){("complete",Some(result))}
            else if complete.is_some(){("partial",complete.as_ref())}else{("fallback",None)};
        let report=raw_threaded_finish_report("final",status,result,evaluated,budget,run.completion,threads);
        if let Err(error)=run.check_publication(){return vec![format!("err {error}")];}
        vec![report]
    }
}

#[cfg(test)]
mod raw_protocol_unit_tests {
    use super::*;
    #[test]
    fn raw_time_transport_matches_original_seconds_and_rejects_overflow(){
        match(raw_limit("time 00:00:02").unwrap(),raw_limit("milliseconds 2000").unwrap()){
            (crate::search::SearchLimit::Time(a),crate::search::SearchLimit::Time(b))=>assert_eq!(a,b),_=>panic!("time")}
        for text in ["milliseconds -1","milliseconds +1","milliseconds 86400001","milliseconds 1 extra","depth 65"]{
            assert!(raw_limit(text).is_err());}
        assert!(matches!(raw_limit("milliseconds 0"),Ok(crate::search::SearchLimit::Time(d))if d.is_zero()));
    }
}

#[cfg(test)]
mod finish_raw_contracts {
    use super::*;
    use crate::search::{SearchLimit, SearchResult, finish::{CompletionBudget,CompletionMeta}};
    use std::time::Duration;

    #[test]
    fn finish_wire_requires_two_strict_allowances_and_original_compile_mode() {
        for args in ["", "1", "1 2 3", "+1 2", "-1 2", "2 1", "0 86400001", "NaN 2"] {
            assert!(raw_finish_budget(args).is_err(),"{args}");
        }
        assert_eq!(raw_finish_budget("0 0").unwrap(),CompletionBudget::new(0,0).unwrap());
        assert_eq!(raw_finish_budget("5 20").unwrap(),CompletionBudget::new(5,20).unwrap());
        let mut engine=UhpEngine::default();let before=engine.game.raw_state_json();
        assert!(engine.execute("options set Threads 2").is_empty());
        let parallel=engine.execute("bestmove_raw finish_ms 0 0");
        if crate::search::trained::mode()=="original" {
            assert!(parallel[0].contains("\"threads\":2")&&parallel[0].contains("\"completion\":"));
        } else {assert!(parallel[0].contains("original compile mode"));}
        assert_eq!(engine.game.raw_state_json(),before);
        assert!(engine.execute("options set Threads 1").is_empty());
        if crate::search::trained::mode()!="original" {
            assert!(engine.execute("bestmove_raw finish_ms 0 1")[0].contains("original compile mode"));
            assert_eq!(engine.game.raw_state_json(),before);
        }
    }

    #[test]
    fn ordinary_machine_response_shape_stays_exact_and_finish_is_explicit_only() {
        let game=UhpGame::new(GameType::mlp());
        let mut zero=game.search(SearchLimit::Time(Duration::ZERO));
        let mut engine=UhpEngine{game,..UhpEngine::default()};let before=engine.game.raw_state_json();
        let actual=engine.execute("bestmove_raw milliseconds 0");assert_eq!(actual.len(),1);
        // Two actual searches cannot have identical elapsed_ns. Parse ONLY
        // that independently measured field, then compare every other byte.
        let elapsed=actual[0].split_once("\"elapsed_ns\":").unwrap().1.split(',').next().unwrap();
        assert!(!elapsed.is_empty()&&elapsed.bytes().all(|b|b.is_ascii_digit()));
        zero.elapsed=Duration::from_nanos(elapsed.parse::<u64>().unwrap());
        assert_eq!(actual,vec![raw_search_report("final","fallback",&zero,None,1)]);
        assert!(!engine.execute("bestmove_raw depth 0")[0].contains("\"completion\""));
        if crate::search::trained::mode()=="original" {
            let row=engine.execute("bestmove_raw finish_ms 0 0");
            assert_eq!(row.len(),1);assert!(row[0].contains("\"status\":\"fallback\""));
            assert!(row[0].contains("\"completed_depth\":0,\"score\":null"));
            assert!(row[0].contains("\"nodes\":0"));
            assert!(row[0].ends_with("\"completion\":{\"soft_ms\":0,\"hard_ms\":0,\"extended\":false,\"finished\":false,\"goal_depth\":null}}"));
        }
        assert_eq!(engine.game.raw_state_json(),before);
    }

    #[test]
    fn finish_partial_report_keeps_evaluated_score_separate_from_selected_whole_actor() {
        let game=UhpGame::from_root("Base+MLP~0~20~wQ:-1:0:0,bQ:1:0:0,wP:0:0:0,bA1:1:-1:0,wM:0:-1:0~").unwrap();
        let raw=game.board().legal_moves().into_iter().find(|m|matches!(m,HiveMove::Pillbug{..})).unwrap();
        let previous=game.board().legal_moves().into_iter().find(|m|*m!=raw).unwrap();
        let completed=SearchResult{best_move:Some(previous),score:Some(17),completed_depth:2,nodes:90,elapsed:Duration::ZERO};
        let partial=SearchResult{best_move:Some(raw),score:None,completed_depth:2,nodes:100,elapsed:Duration::ZERO};
        let meta=CompletionMeta{extended:true,finished:false,goal_depth:Some(3)};
        let report=raw_finish_report("final","partial",&partial,Some(&completed),CompletionBudget::new(5,20).unwrap(),meta);
        assert!(report.contains("\"score\":null"));assert!(report.contains("\"eval_score\":17"));
        assert!(report.contains(&format!("\"selected_raw\":{}",raw_json_move(Some(raw)))));
        assert!(report.contains(&format!("\"eval_raw\":{}",raw_json_move(Some(previous)))));
        assert!(report.ends_with("\"completion\":{\"soft_ms\":5,\"hard_ms\":20,\"extended\":true,\"finished\":false,\"goal_depth\":3}}"));
    }

    #[test]
    fn finish_retains_exact_pillbug_mosquito_actor_and_whole_native_history() {
        if crate::search::trained::mode()!="original" {return;}
        for (setup,bug) in [
            ("Base+MLP~0~20~wQ:-1:0:0,bQ:1:0:0,wP:0:0:0,bA1:1:-1:0,wM:0:-1:0~",Bug::Pillbug),
            ("Base+MLP~0~20~wQ:-1:0:0,bQ:1:0:0,wM:0:0:0,bA1:1:-1:0,wP:0:-1:0~",Bug::Mosquito)] {
            let mut game=UhpGame::from_root(setup).unwrap();
            let raw=game.board().legal_moves().into_iter().find(|m|matches!(m,HiveMove::Pillbug{actor,..}if actor.bug==bug)).unwrap();
            game.play_raw(raw).unwrap();let before=game.raw_state_json();
            let expected=game.search(SearchLimit::Time(Duration::ZERO));
            // Direct typed clone, NEVER game_string()->newgame actor recovery.
            let mut engine=UhpEngine{game:game.clone(),..UhpEngine::default()};
            let row=engine.execute("bestmove_raw finish_ms 0 0");
            assert_eq!(row.len(),1);assert!(row[0].contains(&format!("\"selected_raw\":{}",raw_json_move(expected.best_move))));
            assert_eq!(engine.execute("state_raw"),vec![before]);
            assert_eq!(engine.game.history(),[raw]);
            assert_eq!(engine.game.exact_position_history(),game.exact_position_history());
        }
    }
}


#[cfg(test)]
mod multicore_raw_contracts {
    use super::*;
    use crate::search::{SearchLimit,trained};
    use std::time::Duration;

    fn integer(json:&str,key:&str)->u64 {
        let prefix=format!("\"{key}\":");
        let value=json.split_once(&prefix).expect("actual JSON field").1;
        value.chars().take_while(|c|c.is_ascii_digit()).collect::<String>().parse().unwrap()
    }
    fn vector(json:&str,key:&str)->Vec<u64> {
        let prefix=format!("\"{key}\":[");
        let values=json.split_once(&prefix).expect("actual JSON array").1.split(']').next().unwrap();
        if values.is_empty(){Vec::new()}else{values.split(',').map(|x|x.parse().unwrap()).collect()}
    }
    fn assert_counters(json:&str,threads:u8,nodes:u64) {
        assert_eq!(integer(json,"threads"),u64::from(threads));
        assert_eq!(json.matches(&format!("\"threads\":{threads}")).count(),2,"outer and actual nested thread setting");
        let workers=vector(json,"nodes_by_worker");
        assert_eq!(workers.len(),usize::from(threads));assert_eq!(workers.iter().sum::<u64>(),nodes);
        assert_eq!(integer(json,"spawned"),integer(json,"joined"));
        assert!(integer(json,"peak")<=u64::from(threads));
        assert_eq!(vector(json,"jobs_by_worker").len(),if threads==1{0}else{usize::from(threads)});
        if threads==1 {assert_eq!(integer(json,"spawned"),0);}
    }
    fn archived(n:usize)->UhpGame {
        let line=include_str!("../tests/archive_repetition.txt").lines().next().unwrap();
        let mut game=UhpGame::new(GameType::mlp());
        for text in line.split('|').nth(2).unwrap().split(';').take(n){game.play(text).unwrap();}
        game
    }
    fn engine(game:&UhpGame,threads:u8)->UhpEngine {
        let mut engine=UhpEngine{game:game.clone(),..UhpEngine::default()};
        assert!(engine.execute(&format!("options set Threads {threads}")).is_empty());engine
    }

    #[test]
    fn default_machine_search_keeps_serial_nodes_score_raw_choice_and_state_exact() {
        let game=archived(17);let before=game.raw_state_json();
        let serial=game.search(SearchLimit::Depth(3));let mut e=engine(&game,1);
        let reply=e.execute("bestmove_raw depth 3");assert_eq!(reply.len(),1);
        assert!(reply[0].contains(&format!("\"selected_raw\":{}",raw_json_move(serial.best_move))));
        assert_eq!(integer(&reply[0],"nodes"),serial.nodes);
        assert!(reply[0].contains(&format!("\"score\":{}",serial.score.unwrap())));
        assert_counters(&reply[0],1,serial.nodes);
        assert_eq!(e.execute("state_raw"),vec![before]);
    }

    #[test]
    fn every_completed_machine_iteration_has_joined_worker_nodes_and_exact_depth_cursor() {
        let game=UhpGame::new(GameType::mlp());let mut depths=Vec::new();
        let run=game.search_with_threads_and_progress(SearchLimit::Depth(3),4,|row|{
            let report=raw_search_report("iteration","complete",row,Some(row),4);
            assert_counters(&report,4,row.nodes);
            assert_eq!(integer(&report,"completed_depth"),u64::from(row.completed_depth));
            assert!(report.contains(&format!("\"selected_raw\":{}",raw_json_move(row.best_move))));
            assert!(row.score.is_some());depths.push(row.completed_depth);
        }).unwrap();
        assert_eq!(depths,vec![1,2,3]);assert!(run.stats.spawned_threads>0);
        assert_counters(&raw_search_report("final","complete",&run.result,Some(&run.result),4),4,run.result.nodes);
    }

    #[test]
    fn configured_raw_queries_preserve_exact_pillbug_mosquito_actor_history_and_child_identity() {
        for (setup,bug) in [
            ("Base+MLP~0~20~wQ:-1:0:0,bQ:1:0:0,wP:0:0:0,bA1:1:-1:0,wM:0:-1:0~",Bug::Pillbug),
            ("Base+MLP~0~20~wQ:-1:0:0,bQ:1:0:0,wM:0:0:0,bA1:1:-1:0,wP:0:-1:0~",Bug::Mosquito)] {
            let mut game=UhpGame::from_root(setup).unwrap();
            let raw=game.board().legal_moves().into_iter().find(|m|matches!(m,HiveMove::Pillbug{actor,..}if actor.bug==bug)).unwrap();
            game.play_raw(raw).unwrap();let before=game.raw_state_json();
            let serial=game.search(SearchLimit::Depth(2));let mut e=engine(&game,2);
            let reply=e.execute("bestmove_raw depth 2");assert_eq!(reply.len(),1);
            assert!(reply[0].contains(&format!("\"score\":{}",serial.score.unwrap())));
            let selected:Vec<_>=game.board().legal_moves().into_iter().filter(|&mv|
                reply[0].contains(&format!("\"selected_raw\":{}",raw_json_move(Some(mv))))).collect();
            assert_eq!(selected.len(),1);
            let mut actual=game.clone();actual.play_raw(selected[0]).unwrap();
            let probe=e.execute(&format!("probe_raw {}",raw_move_fields(selected[0])));
            assert!(probe[0].contains(&format!("\"current_position\":{}",actual.witness_current_position_json())));
            assert_eq!(e.execute("state_raw"),vec![before]);assert_eq!(e.game().history(),[raw]);
            assert_counters(&reply[0],2,integer(&reply[0],"nodes"));
        }
    }

    #[test]
    fn zero_deadline_machine_fallback_is_legal_unscored_and_all_workers_joined() {
        let game=archived(16);let before=game.raw_state_json();
        for threads in [2,12] {
            let mut e=engine(&game,threads);let reply=e.execute("bestmove_raw milliseconds 0");
            assert!(reply[0].contains("\"status\":\"fallback\""));
            assert!(reply[0].contains("\"score\":null")&&reply[0].contains("\"eval_score\":null"));
            assert_eq!(integer(&reply[0],"completed_depth"),0);
            assert_counters(&reply[0],threads,0);
            assert_eq!(game.board().legal_moves().into_iter().filter(|&mv|
                reply[0].contains(&format!("\"selected_raw\":{}",raw_json_move(Some(mv))))).count(),1);
            assert_eq!(e.execute("state_raw"),vec![before.clone()]);
        }
        // Actual cooperative interruption also returns only after its scoped joins.
        let run=game.search_with_threads(SearchLimit::Time(Duration::from_millis(10)),2).unwrap();
        assert_eq!(run.stats.spawned_threads,run.stats.joined_threads);
    }

    #[test]
    fn whole_played_threefold_blocks_raw_search_without_worker_or_board_substitution() {
        let line=include_str!("../tests/archive_repetition.txt").lines().next().unwrap();
        let end=line.split('|').nth(1).unwrap().parse::<usize>().unwrap();let game=archived(end);
        let mut e=engine(&game,12);let before=e.execute("state_raw");
        assert!(e.execute("bestmove_raw depth 2")[0].starts_with("err game is over"));
        assert_eq!(e.execute("state_raw"),before);
        assert_eq!(e.game().witness_positions_json(),game.witness_positions_json());
    }

    #[test]
    fn model_telemetry_is_sum_of_actual_joined_workers_and_does_not_change_weights_or_game() {
        let game=archived(17);let before=game.raw_state_json();
        let run=game.search_with_threads(SearchLimit::Depth(6),2).unwrap();
        let mut sums=trained::Stats::default();
        for row in &run.stats.worker_model_stats {
            sums.applications+=row.applications;sums.moves_ranked+=row.moves_ranked;sums.changed_orders+=row.changed_orders;
        }
        assert_eq!(sums,trained::stats());
        if !trained::enabled(){assert_eq!(sums,trained::Stats::default());}
        assert_eq!(run.stats.worker_model_stats.len(),2);
        assert_eq!(run.result.completed_depth,6);assert_eq!(run.stats.spawned_threads,run.stats.joined_threads);
        assert_eq!(game.raw_state_json(),before);
    }
}

#[cfg(test)]
mod adaptive_raw_contracts {
    use super::*;
    use super::adaptive_thread_contracts::{archived,automatic};
    use crate::search::SearchLimit;
    use std::time::Duration;

    fn integer(json:&str,key:&str)->u64 {
        let key=format!("\"{key}\":");
        json.split_once(&key).unwrap().1.chars().take_while(|c|c.is_ascii_digit())
            .collect::<String>().parse().unwrap()
    }
    fn vector(json:&str,key:&str)->Vec<u64> {
        let key=format!("\"{key}\":[");let text=json.split_once(&key).unwrap().1.split(']').next().unwrap();
        if text.is_empty(){Vec::new()}else{text.split(',').map(|v|v.parse().unwrap()).collect()}
    }
    fn actual_workers(json:&str,threads:u8) {
        assert_eq!(json.matches(&format!("\"threads\":{threads}")).count(),2);
        let nodes=vector(json,"nodes_by_worker");assert_eq!(nodes.len(),usize::from(threads));
        assert_eq!(nodes.iter().sum::<u64>(),integer(json,"nodes"));
        assert_eq!(integer(json,"spawned"),integer(json,"joined"));
        assert!(integer(json,"peak")<=u64::from(threads));
        assert_eq!(vector(json,"jobs_by_worker").len(),if threads==1{0}else{usize::from(threads)});
    }

    #[test]
    fn default_fixed_raw_bytes_and_ordinary_serial_path_remain_unchanged() {
        let game=archived(19);let before=game.raw_state_json();
        let mut result=game.search(SearchLimit::Time(Duration::ZERO));
        let mut e=UhpEngine{game:game.clone(),..UhpEngine::default()};
        let reply=e.execute("bestmove_raw milliseconds 0");
        // Only elapsed_ns is independently measured in the two actual runs.
        result.elapsed=Duration::from_nanos(integer(&reply[0],"elapsed_ns"));
        assert_eq!(reply,vec![raw_search_report("final","fallback",&result,None,1)]);
        actual_workers(&reply[0],1);
        let ordinary=game.bestmove(SearchLimit::Depth(2)).unwrap();
        assert_eq!(e.execute("bestmove depth 2"),vec![ordinary]);
        assert_eq!(e.execute("state_raw"),vec![before]);
    }

    #[test]
    fn boundary_zero_fallback_uses_actual_root_threads_and_preserves_raw_state_schema() {
        for (ply,threads) in [(19,8),(20,4),(21,4)] {
            let game=archived(ply);let before=game.raw_state_json();let mut e=automatic(&game);
            let reply=e.execute("bestmove_raw milliseconds 0");assert_eq!(reply.len(),1);
            assert!(reply[0].contains("\"status\":\"fallback\""));
            assert!(reply[0].contains("\"score\":null")&&reply[0].contains("\"eval_score\":null"));
            assert_eq!(integer(&reply[0],"completed_depth"),0);actual_workers(&reply[0],threads);
            assert_eq!(game.board().legal_moves().into_iter().filter(|&mv|
                reply[0].contains(&format!("\"selected_raw\":{}",raw_json_move(Some(mv))))).count(),1);
            assert!(!reply[0].contains("\"completion\"")&&!reply[0].contains("ThreadPolicy"));
            assert_eq!(e.execute("state_raw"),vec![before]);
        }
    }

    #[test]
    fn automatic_complete_requests_match_fixed_controls_and_ordinary_bestmove() {
        for (ply,threads) in [(19,8),(20,4),(21,4)] {
            let game=archived(ply);let before=game.raw_state_json();
            let mut e=automatic(&game);let mut fixed=UhpEngine{game:game.clone(),..UhpEngine::default()};
            assert!(fixed.execute(&format!("options set Threads {threads}")).is_empty());
            let a=e.execute("bestmove_raw depth 2");let b=fixed.execute("bestmove_raw depth 2");
            actual_workers(&a[0],threads);actual_workers(&b[0],threads);
            assert_eq!(integer(&a[0],"completed_depth"),2);
            for key in ["score","selected_raw","eval_raw","eval_score"] {
                // Nested raw descriptors include commas; compare the whole
                // score/move prefix through nodes, excluding execution costs.
                assert!(a[0].contains(&format!("\"{key}\":")));
            }
            assert_eq!(a[0].split(",\"nodes\":").next(),b[0].split(",\"nodes\":").next());
            assert_eq!(e.execute("bestmove depth 2"),fixed.execute("bestmove depth 2"));
            e.execute("options set ReportFoulBroodScores True");
            assert_eq!(e.execute("bestmove depth 2"),fixed.execute("bestmove depth 2"));
            assert_eq!(e.execute("state_raw"),vec![before]);
        }
    }

    #[test]
    fn every_iteration_keeps_once_selected_root_count_when_children_cross_the_cutoff() {
        let game=archived(19);let e=automatic(&game);let before=e.game.raw_state_json();
        let threads=e.effective_threads();assert_eq!(threads,8);let mut depths=Vec::new();
        let run=e.game.search_with_threads_and_progress(SearchLimit::Depth(2),threads,|row|{
            let report=raw_search_report("iteration","complete",row,Some(row),threads);
            actual_workers(&report,8);depths.push(row.completed_depth);
            assert_eq!(e.game.board().ply(),19);assert_eq!(e.effective_threads(),8);
        }).unwrap();
        assert_eq!(depths,vec![1,2]);assert_eq!(run.stats.configured_threads,8);
        assert_eq!(run.stats.spawned_threads,run.stats.joined_threads);
        actual_workers(&raw_search_report("final","complete",&run.result,Some(&run.result),threads),8);
        assert_eq!(e.game.raw_state_json(),before);
    }

    #[test]
    fn typed_actor_history_and_automatic_finish_use_actual_root_threads_without_fallback() {
        for (setup,bug) in [
            ("Base+MLP~0~20~wQ:-1:0:0,bQ:1:0:0,wP:0:0:0,bA1:1:-1:0,wM:0:-1:0~",Bug::Pillbug),
            ("Base+MLP~0~20~wQ:-1:0:0,bQ:1:0:0,wM:0:0:0,bA1:1:-1:0,wP:0:-1:0~",Bug::Mosquito)] {
            let mut game=UhpGame::from_root(setup).unwrap();
            let mv=game.board().legal_moves().into_iter().find(|m|
                matches!(m,HiveMove::Pillbug{actor,..}if actor.bug==bug)).unwrap();
            game.play_raw(mv).unwrap();let before=game.raw_state_json();let mut e=automatic(&game);
            let reply=e.execute("bestmove_raw milliseconds 0");actual_workers(&reply[0],4);
            assert_eq!(e.game.history(),[mv]);assert_eq!(e.game.exact_position_history(),game.exact_position_history());
            let finish=e.execute("bestmove_raw finish_ms 0 0");
            if crate::search::trained::mode()=="original" {
                actual_workers(&finish[0],4);assert!(finish[0].contains("\"completion\":"));
            } else {assert_eq!(finish,vec!["err finish_ms requires original compile mode"]);}
            assert_eq!(e.execute("state_raw"),vec![before.clone()]);
            assert!(e.execute("options set OpeningPlies 65535").is_empty());
            let finish=e.execute("bestmove_raw finish_ms 0 0");
            if crate::search::trained::mode()=="original" {actual_workers(&finish[0],8);}
            else {assert_eq!(finish,vec!["err finish_ms requires original compile mode"]);}
            assert!(e.execute("options set Threads 1").is_empty());
            let finish=e.execute("bestmove_raw finish_ms 0 0");
            if crate::search::trained::mode()=="original" {
                assert!(finish[0].contains("\"completion\":")&&finish[0].contains("\"threads\":1"));
            } else {assert_eq!(finish,vec!["err finish_ms requires original compile mode"]);}
            assert_eq!(e.execute("state_raw"),vec![before]);
        }
    }

    #[test]
    fn threaded_finish_formatter_keeps_partial_selected_score_separate_from_completed_eval() {
        let game=archived(19);let moves=game.board().legal_moves();
        let evaluated=crate::search::SearchResult {best_move:Some(moves[0]),score:Some(17),completed_depth:3,
            nodes:0,elapsed:Duration::ZERO};
        let partial=crate::search::SearchResult {best_move:Some(moves[1]),score:None,completed_depth:3,
            nodes:0,elapsed:Duration::ZERO};
        // Populate real joined accounting for the formatter's actual thread
        // source. The synthetic score rows only test explicit wire provenance.
        let run=game.search_with_threads(SearchLimit::Time(Duration::ZERO),4).unwrap();
        assert_eq!(run.stats.spawned_threads,run.stats.joined_threads);
        let budget=crate::search::finish::CompletionBudget::new(5,20).unwrap();
        let meta=crate::search::finish::CompletionMeta {extended:true,finished:false,goal_depth:Some(4)};
        let row=raw_threaded_finish_report("final","partial",&partial,Some(&evaluated),budget,meta,4);
        assert!(row.contains("\"score\":null")&&row.contains("\"eval_score\":17"));
        assert!(row.contains(&format!("\"selected_raw\":{}",raw_json_move(partial.best_move))));
        assert!(row.contains(&format!("\"eval_raw\":{}",raw_json_move(evaluated.best_move))));
        assert!(row.contains("\"completed_depth\":3")&&row.contains("\"goal_depth\":4"));
        assert!(row.contains("\"finished\":false"));
        // The original one-thread formatter stays byte-for-byte the same.
        assert_eq!(raw_threaded_finish_report("final","partial",&partial,Some(&evaluated),budget,meta,1),
            raw_finish_report("final","partial",&partial,Some(&evaluated),budget,meta));
    }
}
