//! First search milestone: deterministic iterative deepening and alpha-beta.
//! Evaluation weights are starting hypotheses, not tournament-tuned values.
use crate::{Board, Bug, Color, HiveMove, Piece};
use std::time::{Duration, Instant};

#[path = "residual_labels.rs"]
pub mod residual;
#[path = "coverage.rs"]
pub mod coverage;
#[path = "trained_residual.rs"]
pub mod trained;
#[path = "parallel.rs"]
pub mod parallel;
#[path = "finish.rs"]
pub mod finish;

const WIN: i32 = 100_000;
const MAX_DEPTH: u8 = 64;

/// Compile-time symmetric development treatment; never a runtime switch.
pub fn development_balance_enabled() -> bool {
    matches!(option_env!("FOULBROOD_DEVELOPMENT_BALANCE"), Some("symmetric_v1"))
}

/// Fixed cautious evaluation treatment. No runtime tuning or search policy switch.
fn checked_cautious_style_label(value: Option<&'static str>) -> &'static str {
    match value {
        None | Some("off") => "off",
        Some("pin_develop_v1") => "pin_develop_v1",
        Some("pin_pressure_v2") => "pin_pressure_v2",
        Some(other) => panic!("Unknown fixed cautious treatment: {other}"),
    }
}
pub fn cautious_style_label() -> &'static str {
    checked_cautious_style_label(option_env!("FOULBROOD_CAUTIOUS_STYLE"))
}
#[inline]
fn proximity_weight() -> i32 {
    if matches!(cautious_style_label(),"pin_develop_v1"|"pin_pressure_v2") { 0 } else { 3 }
}
fn pin_pressure_enabled()->bool {cautious_style_label()=="pin_pressure_v2"}
fn development_envelope()->i32 {
    if pin_pressure_enabled()&&development_weights_label()=="deployment_higher" {284}else{128}
}
// Actual Queen cover damage stays unchanged. Both cautious styles suppress
// prospective Queen-cover credit; only pin_pressure_v2 contextualizes the
// nonterminal occupancy ladder. P restriction and Q recovery stay.
fn beetle_strategy_value(f: &crate::groundwork::Features) -> i32 {
    let queen_cover = if matches!(cautious_style_label(),"pin_develop_v1"|"pin_pressure_v2") { 0 } else { 20 };
    queen_cover * i32::from(f.queen_cover)
        + 24 * i32::from(f.pillbug_cover) + 20 * i32::from(f.queen_recovery)
}

const DEVELOPMENT_BALANCE_BOUND: i32 = 128;
/// Read-only compile-time treatment label; no runtime tuning or mutable weights.
pub fn development_weights_label() -> &'static str {
    match option_env!("FOULBROOD_DEVELOPMENT_WEIGHTS").unwrap_or("reference") {
        "reference"=>"reference", "deployment_lower"=>"deployment_lower",
        "deployment_higher"=>"deployment_higher", "pinning_lower"=>"pinning_lower",
        "pinning_higher"=>"pinning_higher", "support_shortfall"=>"support_shortfall",
        other=>panic!("Unknown fixed development-weight treatment: {other}"),
    }
}
fn development_coefficients()->(i32,i32) {
    match development_weights_label() {
        "deployment_lower"=>(6,12), "deployment_higher"=>(10,12),
        "pinning_lower"=>(8,9), "pinning_higher"=>(8,15),
        _=>(8,12),
    }
}
fn development_benefit_with_shortfall(deployed:u8,pinned:u8,shortfall:u8)->i32 {
    let (deployment,pin)=development_coefficients();
    let penalty=if development_weights_label()=="support_shortfall"{2*i32::from(shortfall)}else{0};
    if pin_pressure_enabled() && development_weights_label()=="deployment_higher" {
        // At most13 physical nonQueens per color, including all M/L/P.
        // Keep the original deployment cap but preserve EVERY12-point pin.
        debug_assert!(deployed<=13&&pinned<=13);
        return (deployment*i32::from(deployed)).clamp(0,DEVELOPMENT_BALANCE_BOUND)
            +pin*i32::from(pinned);
    }
    // Clamp BOTH ends: each color benefit remains[0,128], so its White−Black
    // difference keeps the existing rigorous128 envelope. No all-deployed
    // coefficient switches at the readiness boundary.
    (deployment*i32::from(deployed)+pin*i32::from(pinned)-penalty).clamp(0,DEVELOPMENT_BALANCE_BOUND)
}
fn development_benefit(deployed:u8,pinned:u8)->i32 {
    development_benefit_with_shortfall(deployed,pinned,0)
}
fn development_balance(board: &Board) -> i32 {
    if !development_balance_enabled() { return 0; }
    if development_weights_label()=="support_shortfall" {
        let values=crate::movement::development_readiness_counts(board);
        let benefit=|c:Color| {
            let ((deployed,pinned),support)=values[c.index()];
            development_benefit_with_shortfall(deployed,pinned,support.shortfall())
        };
        benefit(Color::White)-benefit(Color::Black)
    } else {
        let counts = crate::movement::development_counts(board);
        development_benefit(counts[Color::White.index()].0, counts[Color::White.index()].1)
            - development_benefit(counts[Color::Black.index()].0, counts[Color::Black.index()].1)
    }
}

#[derive(Clone, Copy, Debug)]
pub enum SearchLimit {
    Depth(u8),
    Time(Duration),
}

#[derive(Clone, Debug)]
pub struct SearchResult {
    pub best_move: Option<HiveMove>,
    /// Score from the root side's perspective; None means a fallback or incompletely compared root choice.
    pub score: Option<i32>,
    pub completed_depth: u8,
    pub nodes: u64,
    pub elapsed: Duration,
}

use crate::position::Position;

#[derive(Clone, Copy, Debug, PartialEq)]
enum Bound { Exact, Lower, Upper }
#[derive(Clone, Copy, Debug, PartialEq)]
struct Entry { key: u64, position: Position, depth: u8, score: i32, bound: Bound, best_move: Option<HiveMove> }

fn store_score(score: i32, ply: u8) -> i32 {
    if score >= WIN - i32::from(MAX_DEPTH) { score + i32::from(ply) }
    else if score <= -WIN + i32::from(MAX_DEPTH) { score - i32::from(ply) }
    else { score }
}
fn load_score(score: i32, ply: u8) -> i32 {
    if score >= WIN - i32::from(MAX_DEPTH) { score - i32::from(ply) }
    else if score <= -WIN + i32::from(MAX_DEPTH) { score + i32::from(ply) }
    else { score }
}

struct Search {
    history: Option<Vec<Position>>,
    table: Vec<Option<Entry>>,
    killers: [[Option<HiveMove>; 2]; 65],
    deadline: Option<crate::deadline::Deadline>,
    nodes: u64,
    #[cfg(test)]
    node_limit: Option<u64>,
}

impl Search {
    fn expired(&self) -> bool {
        if residual::phase_expired() { return true; }
        if coverage::phase_expired() { return true; }
        #[cfg(test)]
        if self.node_limit.is_some_and(|n| self.nodes >= n) { return true; }
        self.deadline.is_some_and(|d| d.expired())
    }

    // Score child positions from the mover's perspective. Sorting changes only
    // exploration order, never evaluation, legality or alpha-beta bounds.
    fn order_moves(&self, board: &mut Board, moves: &mut [HiveMove], ply: u8)
        -> Result<(), ()>
    {
        let parent_queens = Color::ALL.map(|c| board.location(Piece::new(c,Bug::Queen,1)));
        let parent_total = piece_total_q(board,&parent_queens);
        let parent_counts = queen_counts(board);
        let readiness = Color::ALL.map(|c| pillbug_queen_readiness(board,c));
        let mut ranked = Vec::with_capacity(moves.len());
        for &mv in moves.iter() {
            if self.expired() { return Err(()); }
            let score = if let Some(score) = projected_ranking_score_cached(board,mv,ply+1,&parent_queens,parent_counts,parent_total,Some(readiness)) {
                score
            } else {
                let undo = board.make_generated(mv);
                let score = -terminal(board, ply+1).unwrap_or_else(|| evaluate_ordering(board));
                board.undo_generated(undo);
                score
            };
            ranked.push((score, mv));
        }
        ranked.sort_by_key(|&(score, _)| std::cmp::Reverse(score));
        for (slot, (_, mv)) in moves.iter_mut().zip(ranked) { *slot = mv; }
        Ok(())
    }

    #[cfg(test)]
    fn negamax(&mut self, board: &mut Board, depth: u8, ply: u8,
               alpha: i32, beta: i32) -> Result<i32, ()> {
        let total = piece_total(board);
        self.negamax_parts(board, depth, ply, alpha, beta, total, queen_counts(board), None)
    }
    fn negamax_parts(&mut self, board: &mut Board, depth: u8, ply: u8,
               alpha: i32, beta: i32, total: i32, counts: [u8;2], played: Option<HiveMove>) -> Result<i32, ()> {
        coverage::count(depth,ply,coverage::Count::Entry);
        if self.expired() { coverage::count(depth,ply,coverage::Count::EntryExpired); return Err(()); }
        // A placement strictly reduces reserve inventory. No earlier position
        // on this path can match it. At a leaf there are no descendants or TT
        // probes needing a history entry, so avoid constructing/copying one.
        if depth==0 && (matches!(played,Some(HiveMove::Place{..})) || (played.is_some() && self.history.as_ref().is_some_and(|h| {
            // Three occurrences of the same side require at least four plies
            // with unchanged inventory. Any recent placement rules that out.
            h.last().is_some_and(|p| ((p.state^h[h.len().saturating_sub(4)].state)&((1<<28)-1))!=0)
        }))) {
            return self.negamax_inner(board,depth,ply,alpha,beta,total,counts);
        }
        let repeated = if let Some(history) = self.history.as_mut() {
            let position = match (history.last(), played) {
                (Some(parent), Some(mv)) => parent.after(board, mv),
                _ => Position::new(board),
            };
            // Reserve inventory only decreases on a legal path. Earlier entries
            // beyond the last placement cannot repeat this position.
            let repeated = history.iter().rev().take_while(|p| ((p.state ^ position.state) & ((1_u64 << 28)-1)) == 0)
                .filter(|p| position.same_repetition(p,board)).take(2).count() == 2;
            history.push(position);
            repeated
        } else { false };
        let result = if repeated {
            coverage::count(depth,ply,coverage::Count::Repetition);
            self.nodes += 1;
            Ok(counted_terminal(board, ply, counts).unwrap_or(0))
        } else {
            self.negamax_inner(board, depth, ply, alpha, beta, total, counts)
        };
        // Pop even when the subtree exits through an error or cutoff.
        if let Some(history) = self.history.as_mut() { history.pop(); }
        result
    }
    fn negamax_inner(&mut self, board: &mut Board, depth: u8, ply: u8,
               mut alpha: i32, beta: i32, total: i32, counts: [u8;2]) -> Result<i32, ()> {
        // The sole caller, negamax_parts, checks expiry before history bookkeeping.
        // Subsequent move-loop checks still bound longer work in this node.
        self.nodes += 1;
        coverage::count(depth,ply,coverage::Count::Inner);
        debug_assert_eq!(evaluate_parts(board, total), evaluate(board));
        debug_assert_eq!(counts, queen_counts(board));
        if depth == 0 { coverage::count(depth,ply,coverage::Count::Leaf); return Ok(evaluate_windowed_leaf(board,total,ply,counts,alpha,beta)); }
        if let Some(score) = counted_terminal(board, ply, counts) { coverage::count(depth,ply,coverage::Count::Terminal); return Ok(score); }
        let original_alpha = alpha;
        let mut hint = None;
        // Require the same horizon for score reuse, preserving exact fixed-depth
        // semantics across transpositions reached at different plies.
        let cached = if depth >= 2 && !self.table.is_empty() {
            coverage::count(depth,ply,coverage::Count::TtChecked);
            let position = self.history.as_ref().and_then(|h| h.last()).copied().unwrap_or_else(|| Position::new(board));
            let key = position.key();
            let slot = key as usize & (self.table.len() - 1);
            if let Some(entry) = self.table[slot] {
                if entry.key == key && entry.position == position {
                    coverage::count(depth,ply,coverage::Count::TtHit);
                    hint = entry.best_move;
                    if hint.is_some() {coverage::count(depth,ply,coverage::Count::TtHint);}
                    let value = load_score(entry.score, ply);
                    // Board identity alone cannot validate a history-dependent score.
                    // Keep the legal move hint, but require a future exact history context
                    // before enabling score reuse in repetition-aware searches.
                    if self.history.is_none() && entry.depth == depth && (entry.bound == Bound::Exact
                        || (entry.bound == Bound::Lower && value >= beta)
                        || (entry.bound == Bound::Upper && value <= alpha)) {
                        coverage::count(depth,ply,coverage::Count::TtReturn);
                        return Ok(value);
                    }
                }
            }
            Some((key, slot, position))
        } else { None };
        // Validate each remembered move before paying for the full move list.
        // Capture the priority once; unsupported move kinds use the full oracle.
        let mut preferred = [hint, self.killers[ply as usize][0], self.killers[ply as usize][1]].into_iter().enumerate();
        let mut tried = [None; 3];
        let mut tried_len = 0;
        let mut moves: Option<Vec<HiveMove>> = None;
        let mut remainder_ready = false;
        let mut index = 0;
        let queens = Color::ALL.map(|c| board.location(Piece::new(c,Bug::Queen,1)));
        let mut best_move = None;
        let mut best_score = -WIN - 1;
        let mut residual_prefix = Vec::new();
        loop {
            let mut preferred_slot = None;
            let mv = if let Some((slot,candidate)) = preferred.next() {
                let Some(mv) = candidate else { coverage::count(depth,ply,coverage::Count::PreferredAbsent); continue; };
                if tried[..tried_len].contains(&Some(mv)) { coverage::count(depth,ply,coverage::Count::PreferredDuplicate); continue; }
                preferred_slot = Some(slot);
                // Empty/duplicate hint slots do no board work; check before validation.
                if self.expired() { coverage::count(depth,ply,coverage::Count::InterruptedBefore); return Err(()); }
                let legal = if let Some(all) = moves.as_ref() { all.contains(&mv) }
                    else { match board.is_legal_search_hint(mv) {
                        Some(legal) => legal,
                        None => moves.get_or_insert_with(|| board.legal_moves()).contains(&mv),
                    }};
                if !legal { coverage::count(depth,ply,coverage::Count::PreferredIllegal); continue; }
                coverage::count(depth,ply,coverage::Count::PreferredLegal);
                tried[tried_len] = Some(mv);
                tried_len += 1;
                mv
            } else {
                if self.expired() {
                    coverage::count(depth,ply,if remainder_ready {coverage::Count::InterruptedAfter} else {coverage::Count::InterruptedBefore});
                    return Err(());
                }
                let remaining = moves.get_or_insert_with(|| board.legal_moves());
                if !remainder_ready {
                    // Removing the prefix preserves the generator's stable order.
                    let generator_full_count = remaining.len();
                    let full_raw = residual::is_active().then(|| remaining.clone());
                    remaining.retain(|mv| !tried[..tried_len].contains(&Some(*mv)));
                    coverage::residual(depth,ply,generator_full_count,tried_len,remaining.len(),alpha,beta,
                        [queens[0].is_some(),queens[1].is_some()]);
                    residual::observe(self, board, depth, ply, original_alpha, alpha, beta,
                        total, counts, remaining, full_raw.as_deref().unwrap_or(remaining), &residual_prefix);
                    if depth >= 2 {
                        if self.order_moves(board, remaining, ply).is_err() {
                            coverage::count(depth,ply,coverage::Count::InterruptedAfter); return Err(());
                        }
                    }
                    coverage::count(depth,ply,coverage::Count::Hce);
                    residual::after_hce(depth, ply, remaining);
                    if trained::apply(self, board, remaining, depth, ply, alpha, beta, tried_len).is_err() {
                        return Err(());
                    }
                    remainder_ready = true;
                }
                let Some(mv) = remaining.get(index).copied() else { break; };
                index += 1;
                mv
            };
            // Child entry checks the deadline after the bounded make/update work.
            // Its error path still undoes this move before returning.
            let delta = piece_move_delta(board,mv,&queens);
            let next_counts = projected_queen_counts(board,mv,&queens,counts);
            let undo = board.make_generated(mv);
            let child_counts = next_counts.unwrap_or_else(|| queen_counts(board));
            let child_total = if queen_moved(mv) {piece_total(board)} else {total+delta};
            let alpha_at_entry = alpha;
            residual::push(mv);
                coverage::push(mv);
            let child = self.negamax_parts(board, depth - 1, ply + 1, -beta, -alpha, child_total, child_counts, Some(mv));
            residual::pop(mv);
                coverage::pop(mv);
            // Always restore, including an interrupted subtree.
            board.undo_generated(undo);
            let score = match child {
                Ok(value) => {
                    if preferred_slot.is_some() {coverage::count(depth,ply,coverage::Count::PreferredCompleted);}
                    -value
                },
                Err(()) => {
                    coverage::count(depth,ply,if preferred_slot.is_some() {coverage::Count::PreferredInterrupted} else {coverage::Count::TailInterrupted});
                    coverage::count(depth,ply,if remainder_ready {coverage::Count::InterruptedAfter} else {coverage::Count::InterruptedBefore});
                    return Err(());
                },
            };
            if !remainder_ready && residual::is_active() {
                let child = residual::ScoreBound::from_window(-score, -beta, -alpha_at_entry).map_err(|_| ())?;
                residual_prefix.push(residual::PrefixResult { raw_move: mv,
                    entry_alpha: alpha_at_entry, beta, child, parent: child.negate() });
            }
            if score > best_score { best_score = score; best_move = Some(mv); }
            if score >= beta {
                if let Some(slot)=preferred_slot {coverage::preferred_cutoff(depth,ply,slot);}
                else {coverage::count(depth,ply,coverage::Count::TailCutoff);}
                let killers = &mut self.killers[ply as usize];
                if killers[0] != Some(mv) { killers[1] = killers[0]; killers[0] = Some(mv); }
                if let Some((key, slot, position)) = cached {
                    self.table[slot] = Some(Entry { key, position, depth,
                        score: store_score(score, ply), bound: Bound::Lower, best_move: Some(mv) });
                }
                return Ok(score);
            }
            alpha = alpha.max(score);
        }
        coverage::count(depth,ply,coverage::Count::TailExhausted);
        if let Some((key, slot, position)) = cached {
            self.table[slot] = Some(Entry { key, position, depth, score: store_score(alpha, ply),
                bound: if alpha <= original_alpha { Bound::Upper } else { Bound::Exact }, best_move });
        }
        Ok(alpha)
    }
}

/// Search a private clone, treating this board as the start of known history.
/// Use UhpGame::search when the played history is available.
/// A legal fallback is retained even when no iteration fits the budget.
/// Deadline checks are cooperative, with a 5% (at most 10ms) output reserve;
/// operating-system scheduling and one move generation can still cause overshoot.
/// Unrepresentable deadlines return the fallback rather than searching unbounded.
/// Preserve the finite native ply domain without saturation or invented scores.
/// Timed search may enter any of the original64 iterations; depth0 needs no child.
pub fn validate_search_headroom(board: &Board, limit: SearchLimit) -> Result<(),String> {
    let depth=match limit {SearchLimit::Depth(d)=>d.min(MAX_DEPTH),SearchLimit::Time(_)=>MAX_DEPTH};
    if board.ply().checked_add(u16::from(depth)).is_none() {
        return Err("finite u16 ply capacity lacks requested search-depth headroom".into());
    }
    Ok(())
}

pub fn search(board: &Board, limit: SearchLimit) -> SearchResult {
    // Board-only callers have no preceding game history. UHP callers use UhpGame::search.
    search_with_history(board, limit, &[Position::new(board)])
}

pub(crate) fn search_with_history(board: &Board, limit: SearchLimit, history: &[Position]) -> SearchResult {
    search_with_progress(board, limit, history, |_| {})
}

pub(crate) fn search_with_progress(board: &Board, limit: SearchLimit, history: &[Position], progress: impl FnMut(&SearchResult)) -> SearchResult {
    search_with_progress_limited(board, limit, history, None, progress)
}
fn search_with_progress_limited(board: &Board, limit: SearchLimit, history: &[Position], _node_limit: Option<u64>, mut progress: impl FnMut(&SearchResult)) -> SearchResult {
    let start = Instant::now();
    validate_search_headroom(board,limit).expect("search rejected before mutation: insufficient finite ply headroom");
    trained::start_search();
    let (depth_limit, deadline) = match limit {
        SearchLimit::Depth(d) => (d.min(MAX_DEPTH), None),
        SearchLimit::Time(t) => {
            let reserve = (t / 20).min(Duration::from_millis(10));
            (MAX_DEPTH, Some(start.checked_add(t.saturating_sub(reserve)).unwrap_or(start)))
        }
    };
    let deadline = deadline.map(crate::deadline::Deadline::at);
    let mut worker = Search { history: Some(history.to_vec()), killers: [[None; 2]; 65], table: vec![None; 16384], deadline, nodes: 0, #[cfg(test)] node_limit: _node_limit };
    let mut result = SearchResult { best_move: None, score: terminal(board, 0),
        completed_depth: 0, nodes: 0, elapsed: Duration::ZERO };
    let root_position = Position::new(board);
    if result.score.is_none() && history.iter().filter(|p| root_position.same_repetition(p,board)).take(3).count() == 3 {
        result.score = Some(0);
    }
    if result.score.is_none() {
        let mut moves = board.legal_moves();
        result.best_move = moves.first().copied();
        let mut position = board.clone();
        let root_queens = Color::ALL.map(|c| board.location(Piece::new(c,Bug::Queen,1)));
        let root_total = piece_total_q(board,&root_queens);
        let root_counts = queen_counts(board);
        for depth in 1..=depth_limit {
            coverage::iteration(depth);
            if worker.expired() { break; }
            // Rank the root once; later depths reuse it with the completed PV first.
            if depth == 2 && worker.order_moves(&mut position, &mut moves, 0).is_err() {
                break;
            }
            // Previous completed iteration's winner is searched first.
            if let Some(i) = moves.iter().position(|m| Some(*m) == result.best_move) {
                moves.swap(0, i);
            }
            let mut best = None;
            let mut alpha = -WIN - 1;
            let mut complete = true;
            for &mv in &moves {
                if worker.expired() { complete = false; break; }
                let delta = piece_move_delta(&position,mv,&root_queens);
                let next_counts = projected_queen_counts(&position,mv,&root_queens,root_counts);
                let undo = position.make_generated(mv);
                let child_counts = next_counts.unwrap_or_else(|| queen_counts(&position));
                let child_total = if queen_moved(mv) {piece_total(&position)} else {root_total+delta};
                residual::push(mv);
                coverage::push(mv);
                let child = worker.negamax_parts(&mut position, depth - 1, 1, -WIN - 1, -alpha, child_total, child_counts, Some(mv));
                residual::pop(mv);
                coverage::pop(mv);
                position.undo_generated(undo);
                match child {
                    Ok(value) => {
                        let score = -value;
                        if score > alpha { alpha = score; best = Some(mv); }
                    }
                    Err(()) => { complete = false; break; }
                }
            }
            if !complete {
                // The previous winner was searched first. Only a fully completed
                // child can replace it; a later alpha improvement is exact against
                // that same-depth incumbent. Unsearched moves might be better.
                if best.is_some() && best != result.best_move
                    && alpha > -WIN + i32::from(MAX_DEPTH)
                    && !result.score.is_some_and(|v| v.abs() >= WIN - i32::from(MAX_DEPTH)) {
                    result.best_move = best;
                    // No exact all-root score exists for the selected partial line.
                    result.score = None;
                }
                break;
            }
            result.best_move = best.or(result.best_move);
            result.score = Some(alpha);
            result.completed_depth = depth;
            result.nodes = worker.nodes;
            result.elapsed = start.elapsed();
            progress(&result);
            if alpha.abs() >= WIN - i32::from(MAX_DEPTH) { break; }
        }
    }
    result.nodes = worker.nodes;
    result.elapsed = start.elapsed();
    result
}

fn terminal(board: &Board, ply: u8) -> Option<i32> {
    let side = board.side_to_move();
    match (board.queen_surrounded(side), board.queen_surrounded(side.other())) {
        (true, true) => Some(0),
        (true, false) => Some(-WIN + i32::from(ply)),
        (false, true) => Some(WIN - i32::from(ply)),
        _ => None,
    }
}


fn stack_value(board: &Board, hex: crate::Hex, stack: &[Piece], queens: &[Option<crate::Hex>; 2]) -> i32 {
    let mut total = 0;
    for (level, &piece) in stack.iter().enumerate() {
        if !board.game_type().includes(piece.bug) { continue; }
        let mut score = 12 - if level + 1 < stack.len() { 15 } else { 0 };
        if level > 0 && level + 1 == stack.len() && matches!(piece.bug, Bug::Beetle | Bug::Mosquito) { score += 12; }
        if piece.bug != Bug::Queen {
            if let Some(q) = queens[piece.color.other().index()] {
                score += proximity_weight() * (6 - i32::from(hex.distance(q)).min(6));
            }
        }
        total += if piece.color == Color::White { score } else { -score };
    }
    total
}
fn piece_total_q(board: &Board, queens: &[Option<crate::Hex>; 2]) -> i32 {
    board.occupied_stacks().map(|(hex, stack)| stack_value(board, hex, stack, queens)).sum()
}
fn piece_total(board: &Board) -> i32 {
    piece_total_q(board, &Color::ALL.map(|c| board.location(Piece::new(c,Bug::Queen,1))))
}
// Rank non-Queen children without mutating the board. Search still makes the
// selected move normally; Queen movement retains the reference ranking path.
#[cfg(test)]
fn projected_ranking_score(board:&Board,mv:HiveMove,ply:u8,queens:&[Option<crate::Hex>;2],parent_counts:[u8;2],total:i32)->Option<i32> {
    projected_ranking_score_cached(board,mv,ply,queens,parent_counts,total,None)
}
fn projected_ranking_score_cached(board:&Board,mv:HiveMove,ply:u8,queens:&[Option<crate::Hex>;2],parent_counts:[u8;2],total:i32,ready:Option<[i32;2]>)->Option<i32> {
    let counts=projected_queen_counts(board,mv,queens,parent_counts)?;
    let side=board.side_to_move();
    match (counts[side.index()]==6,counts[side.other().index()]==6) {
        (true,true)=>return Some(0),
        (true,false)=>return Some(-WIN+i32::from(ply)),
        (false,true)=>return Some(WIN-i32::from(ply)),
        _=>{},
    }
    let (from,to)=match mv {
        HiveMove::Place{to,..}=>(None,Some(to)),
        HiveMove::Move{from,to,..}|HiveMove::Pillbug{from,to,..}=>(Some(from),Some(to)),
        HiveMove::Pass=>(None,None),
    };
    let mut white=total+piece_move_delta(board,mv,queens)
        +cached_readiness_after(board,Color::White,mv,ready)-cached_readiness_after(board,Color::Black,mv,ready);
    for color in Color::ALL {
        let Some(hex)=queens[color.index()] else {continue};
        let queen=Piece::new(color,Bug::Queen,1);
        let covered=if to==Some(hex) {true} else if from==Some(hex) {
            let stack=board.stack(hex).expect("queen source missing");
            stack.get(stack.len().saturating_sub(2)).copied()!=Some(queen)
        } else {board.top(hex)!=Some(queen)};
        let penalty=[0,20,55,110,220,450,0][usize::from(counts[color.index()])]+if covered {80} else {0};
        white+=if color==Color::White {-penalty} else {penalty};
    }
    Some(if side==Color::White {white} else {-white})
}

// Exact white-perspective piece-score change for a generated move. Queen
// movement changes every enemy distance term and keeps the full-recompute path.
fn piece_move_delta(board: &Board, mv: HiveMove, queens: &[Option<crate::Hex>; 2]) -> i32 {
    let (piece, from, to) = match mv {
        HiveMove::Place {piece,to} => (piece,None,to),
        HiveMove::Move {piece,from,to} | HiveMove::Pillbug {piece,from,to,..} => (piece,Some(from),to),
        HiveMove::Pass => return 0,
    };
    if piece.bug == Bug::Queen || from == Some(to) { return 0; }
    let sign = |p:Piece| if p.color == Color::White {1} else {-1};
    let mut delta = 0;
    if board.game_type().includes(piece.bug) {
        let proximity = |h:crate::Hex| queens[piece.color.other().index()]
            .map_or(0, |q| proximity_weight() * (6 - i32::from(h.distance(q)).min(6)));
        delta = sign(piece) * (proximity(to) - from.map_or(-12, proximity));
        if matches!(piece.bug, Bug::Beetle | Bug::Mosquito) {
            delta += 12 * sign(piece) * (i32::from(board.is_occupied(to)) - i32::from(from.is_some_and(|h| board.stack_height(h) > 1)));
        }
    }
    if let Some(from) = from {
        let stack = board.stack(from).expect("generated source missing");
        if stack.len() >= 2 {
            let uncovered = stack[stack.len()-2];
            if board.game_type().includes(uncovered.bug) {
                delta += 15 * sign(uncovered);
                if stack.len() >= 3 && matches!(uncovered.bug, Bug::Beetle | Bug::Mosquito) { delta += 12 * sign(uncovered); }
            }
        }
    }
    if let Some(covered) = board.top(to) {
        if board.game_type().includes(covered.bug) {
            delta -= 15 * sign(covered);
            if board.stack_height(to) > 1 && matches!(covered.bug, Bug::Beetle | Bug::Mosquito) { delta -= 12 * sign(covered); }
        }
    }
    delta
}
#[cfg(test)]
fn changed_cells(mv: HiveMove) -> [Option<crate::Hex>; 2] {
    match mv {
        HiveMove::Place {to,..} => [Some(to),None],
        HiveMove::Move {from,to,..} | HiveMove::Pillbug {from,to,..} => [Some(from), if from != to {Some(to)} else {None}],
        HiveMove::Pass => [None,None],
    }
}
#[cfg(test)]
fn changed_total_q(board: &Board, mv: HiveMove, queens: &[Option<crate::Hex>; 2]) -> i32 {
    changed_cells(mv).into_iter().flatten().map(|h| stack_value(board,h,board.stack(h).unwrap_or(&[]),queens)).sum()
}
#[cfg(test)]
fn changed_total(board: &Board, mv: HiveMove) -> i32 {
    changed_total_q(board,mv,&Color::ALL.map(|c| board.location(Piece::new(c,Bug::Queen,1))))
}
fn queen_moved(mv: HiveMove) -> bool {
    match mv { HiveMove::Place{piece,..} | HiveMove::Move{piece,..} | HiveMove::Pillbug{piece,..} => piece.bug == Bug::Queen, HiveMove::Pass => false }
}
// Terminal detection and static Queen safety share the same ring counts.
#[cfg(test)]
fn evaluate_leaf(board: &Board, total: i32, ply: u8) -> i32 {
    let mut white=total+pillbug_readiness_balance(board)+functional_defense_balance(board)
        +pressure_adjustment(board,queen_counts(board));
    let mut surrounded=[false;2];
    for color in Color::ALL {
        let queen=Piece::new(color,Bug::Queen,1);
        if let Some(hex)=board.location(queen) {
            let occupied=hex.neighbors().iter().filter(|&&h|board.is_occupied(h)).count();
            surrounded[color.index()]=occupied==6;
            let penalty=[0,20,55,110,220,450,0][occupied]
                + if board.top(hex)!=Some(queen) {80} else {0};
            white+=if color==Color::White {-penalty} else {penalty};
        }
    }
    let side=board.side_to_move();
    match (surrounded[side.index()],surrounded[side.other().index()]) {
        (true,true)=>0,
        (true,false)=>-WIN+i32::from(ply),
        (false,true)=>WIN-i32::from(ply),
        _=>if side==Color::White {white} else {-white},
    }
}


fn queen_counts(board: &Board) -> [u8;2] {
    Color::ALL.map(|c| board.location(Piece::new(c,Bug::Queen,1)).map_or(0, |h|
        h.neighbors().iter().filter(|&&n| board.is_occupied(n)).count() as u8))
}
fn projected_queen_counts(board: &Board, mv: HiveMove, queens: &[Option<crate::Hex>;2], mut counts: [u8;2]) -> Option<[u8;2]> {
    if queen_moved(mv) { return None; }
    let (from,to) = match mv {
        HiveMove::Place{to,..} => (None,Some(to)),
        HiveMove::Move{from,to,..} | HiveMove::Pillbug{from,to,..} => (Some(from),Some(to)),
        HiveMove::Pass => return Some(counts),
    };
    let removed = from.filter(|&h| board.stack_height(h)==1);
    let added = to.filter(|&h| !board.is_occupied(h));
    for (i,queen) in queens.iter().enumerate() {
        let Some(q)=queen else {continue};
        let adjacent=|h:crate::Hex| matches!((i32::from(h.q)-i32::from(q.q),i32::from(h.r)-i32::from(q.r)),(1,0)|(1,-1)|(0,-1)|(-1,0)|(-1,1)|(0,1));
        if removed.is_some_and(adjacent) {counts[i]-=1;}
        if added.is_some_and(adjacent) {counts[i]+=1;}
    }
    Some(counts)
}
fn counted_terminal(board:&Board,ply:u8,counts:[u8;2])->Option<i32> {
    let side=board.side_to_move();
    match (counts[side.index()]==6,counts[side.other().index()]==6) {
        (true,true)=>Some(0), (true,false)=>Some(-WIN+i32::from(ply)),
        (false,true)=>Some(WIN-i32::from(ply)), _=>None,
    }
}
fn evaluate_counted_base(board: &Board, total: i32, ply: u8, counts: [u8;2]) -> i32 {
    let mut white=total+pillbug_readiness_balance(board);
    let mut surrounded=[false;2];
    for color in Color::ALL {
        let queen=Piece::new(color,Bug::Queen,1);
        if let Some(hex)=board.location(queen) {
            let occupied=usize::from(counts[color.index()]);
            surrounded[color.index()]=occupied==6;
            let penalty=[0,20,55,110,220,450,0][occupied]
                + if board.top(hex)!=Some(queen) {80} else {0};
            white+=if color==Color::White {-penalty} else {penalty};
        }
    }
    let side=board.side_to_move();
    match (surrounded[side.index()],surrounded[side.other().index()]) {
        (true,true)=>0,
        (true,false)=>-WIN+i32::from(ply),
        (false,true)=>WIN-i32::from(ply),
        _=>if side==Color::White {white} else {-white},
    }
}
fn strategy_bound() -> i32 {
    let baseline = match option_env!("FOULBROOD_STRATEGY").unwrap_or("defense") {
        "control"=>90, "access"=>64, "beetle"=>64, "all"=>278, _=>60,
    };
    // A per-color benefit in [0,M] has signed difference in [-M,M],
    // not [-2M,2M]. M=284 only for new deployment_higher; every other
    // fixed mode retains128. This bounds the residual after pressure access.
    baseline + if development_balance_enabled() { development_envelope() } else { 0 }
}
#[cfg(test)]
fn evaluate_counted_leaf(board:&Board,total:i32,ply:u8,counts:[u8;2])->i32 {
    evaluate_windowed_leaf(board,total,ply,counts,-WIN-1,WIN+1)
}
// Old cheap base/order retain the raw occupancy ladder. Only this full leaf
// applies contextual pressure. Until exact access is known, use its rigorous
// BASE interval, never the old base +/-192 as a speculative cutoff.
fn pressure_drop(n:u8)->i32 {
    if (2..=5).contains(&n) {[0,20,55,110,220,450][usize::from(n)]-20}else{0}
}
fn pressure_interval(board:&Board,counts:[u8;2])->(i32,i32) {
    if !pin_pressure_enabled() {return (0,0);}
    let white=pressure_drop(counts[Color::White.index()]);
    let black=pressure_drop(counts[Color::Black.index()]);
    if board.side_to_move()==Color::White {(-black,white)}else{(-white,black)}
}
// WHITE perspective: lowering White's danger helps White; lowering Black's
// danger helps Black. UNKNOWN is conservative retained old curve, not noaccess.
fn pressure_adjustment(board:&Board,counts:[u8;2])->i32 {
    if !pin_pressure_enabled()||counts.contains(&6) {return 0;}
    let requested=Color::ALL.map(|attacker|pressure_drop(counts[attacker.other().index()])>0);
    if !requested.contains(&true){return 0;}
    let access=crate::movement::ring_pressure_access_pair(board,requested);
    let mut white=0;
    for target in Color::ALL {
        if !access[target.other().index()].retain_pressure() {
            let drop=pressure_drop(counts[target.index()]);
            white+=if target==Color::White{drop}else{-drop};
        }
    }
    white
}
fn evaluate_windowed_leaf(board:&Board,total:i32,ply:u8,counts:[u8;2],alpha:i32,beta:i32)->i32 {
    let raw_base=evaluate_counted_base(board,total,ply,counts);
    if counts.contains(&6) {return raw_base;}
    let bound=strategy_bound();
    let (lo,hi)=pressure_interval(board,counts);
    if raw_base+hi+bound<=alpha {return raw_base+hi+bound;}
    if raw_base+lo-bound>=beta {return raw_base+lo-bound;}
    let white_pressure=pressure_adjustment(board,counts);
    let base=raw_base+if board.side_to_move()==Color::White{white_pressure}else{-white_pressure};
    // Each side's nonnegative feature total is bounded by `bound`, hence the
    // signed difference is in [-bound,bound]. Outside the window these are
    // rigorous alpha-beta bounds, not approximate evaluations or pruning guesses.
    if base+bound<=alpha {return base+bound;}
    if base-bound>=beta {return base-bound;}
    let correction=functional_defense_balance(board);
    debug_assert!(correction.abs()<=bound);
    base+if board.side_to_move()==Color::White {correction} else {-correction}
}


const PILLBUG_SUPPORT: i32 = 69;
const PILLBUG_TWO_WINDOWS: i32 = 12;
const PILLBUG_ONE_WINDOW: i32 = 5;

// Readiness is strategic support, not proof of an immediate legal rescue.
// Project the changed stacks for move ordering without cloning/mutating Board.
fn pillbug_readiness_after(board: &Board, color: Color, mv: Option<HiveMove>) -> i32 {
    if !board.game_type().pillbug { return 0; }
    let (moved,from,to) = match mv {
        Some(HiveMove::Place{piece,to}) => (Some(piece),None,Some(to)),
        Some(HiveMove::Move{piece,from,to}) | Some(HiveMove::Pillbug{piece,from,to,..}) => (Some(piece),Some(from),Some(to)),
        _ => (None,None,None),
    };
    let location = |piece| if moved==Some(piece) {to} else {board.location(piece)};
    let top = |h| {
        if to==Some(h) {moved}
        else if from==Some(h) {board.stack(h).and_then(|s| s.len().checked_sub(2).map(|i| s[i]))}
        else {board.top(h)}
    };
    let queen=Piece::new(color,Bug::Queen,1);
    let Some(q)=location(queen) else {return 0;};
    if top(q)!=Some(queen) {return 0;}
    let pillbug=Piece::new(color,Bug::Pillbug,1);
    if let Some(p)=location(pillbug) {
        return if p.distance(q)==1 && top(p)==Some(pillbug) {PILLBUG_SUPPORT} else {0};
    }
    let mut windows=0;
    for h in q.neighbors() {
        if top(h).is_none() && !h.neighbors().iter().any(|&n| top(n).is_some_and(|p|p.color!=color)) {
            windows+=1;
            if windows==2 {return PILLBUG_TWO_WINDOWS;}
        }
    }
    if windows==1 {PILLBUG_ONE_WINDOW} else {0}
}
// Actual leaf positions need no projected-stack closure.
fn pillbug_queen_readiness(board:&Board,color:Color)->i32 {
    if !board.game_type().pillbug {return 0;}
    let queen=Piece::new(color,Bug::Queen,1);
    let Some(q)=board.location(queen) else {return 0;};
    if board.top(q)!=Some(queen) {return 0;}
    let pillbug=Piece::new(color,Bug::Pillbug,1);
    if let Some(p)=board.location(pillbug) {
        return if p.distance(q)==1 && board.top(p)==Some(pillbug) {PILLBUG_SUPPORT} else {0};
    }
    let mut windows=0;
    for h in q.neighbors() {
        if board.top(h).is_none() && !h.neighbors().iter().any(|&n|board.top(n).is_some_and(|p|p.color!=color)) {
            windows+=1;
            if windows==2 {return PILLBUG_TWO_WINDOWS;}
        }
    }
    if windows==1 {PILLBUG_ONE_WINDOW} else {0}
}
// A reserve window depends only on tops within two steps of its Queen.
// Deployed support depends only on the Queen and Pillbug squares and locations.
fn cached_readiness_after(board:&Board,color:Color,mv:HiveMove,ready:Option<[i32;2]>)->i32 {
    let Some(values)=ready else {return pillbug_readiness_after(board,color,Some(mv));};
    let queen=Piece::new(color,Bug::Queen,1);
    let pillbug=Piece::new(color,Bug::Pillbug,1);
    let (piece,from,to)=match mv {
        HiveMove::Place{piece,to}=>(piece,None,to),
        HiveMove::Move{piece,from,to}|HiveMove::Pillbug{piece,from,to,..}=>(piece,Some(from),to),
        HiveMove::Pass=>return values[color.index()],
    };
    if piece!=queen && piece!=pillbug {
        let Some(q)=board.location(queen) else {return values[color.index()];};
        let affected=if let Some(p)=board.location(pillbug) {
            to==q || to==p || from==Some(q) || from==Some(p)
        } else {to.distance(q)<=2 || from.is_some_and(|h|h.distance(q)<=2)};
        if !affected {return values[color.index()];}
    }
    pillbug_readiness_after(board,color,Some(mv))
}
fn pillbug_readiness_balance(board:&Board)->i32 {
    pillbug_queen_readiness(board,Color::White)-pillbug_queen_readiness(board,Color::Black)
}

fn evaluate_parts(board: &Board, total: i32) -> i32 {
    let mut white = total+pillbug_readiness_balance(board)+functional_defense_balance(board)
        +pressure_adjustment(board,queen_counts(board));
    for color in Color::ALL {
        if let Some(hex) = board.location(Piece::new(color,Bug::Queen,1)) {
            let occupied = hex.neighbors().iter().filter(|&&h| board.is_occupied(h)).count();
            let penalty = [0,20,55,110,220,450,0][occupied]
                + if board.top(hex) != Some(Piece::new(color,Bug::Queen,1)) {80} else {0};
            white += if color == Color::White {-penalty} else {penalty};
        }
    }
    if board.side_to_move()==Color::White {white} else {-white}
}

fn functional_defense(board: &Board, color: Color) -> i32 {
    let (removed, escape) = crate::movement::queen_relocation_defense(board, color);
    18 * i32::from(removed) + if escape {24} else {0}
}
fn functional_defense_balance(board: &Board) -> i32 {
    let mode=option_env!("FOULBROOD_STRATEGY").unwrap_or("defense");
    let mut score=if mode=="defense" || mode=="all" {
        functional_defense(board, Color::White)-functional_defense(board, Color::Black)
    } else {0};
    if matches!(mode,"control"|"access"|"beetle"|"all") {
        let value=|c| {
            let f=match mode {
                "control"=>crate::movement::groundwork_resources(board,c,false),
                "beetle"=>crate::movement::groundwork_resources(board,c,true),
                _=>crate::groundwork::features(board,c),
            };
            (if mode=="control" || mode=="all" {crate::groundwork::control(&f)} else {0})
            +(if mode=="access" || mode=="all" {crate::groundwork::access(&f)} else {0})
            +(if mode=="beetle" || mode=="all" {beetle_strategy_value(&f)} else {0})
        };
        score+=value(Color::White)-value(Color::Black);
    }
    // Equal fixed coefficients for both colors, in WHITE perspective on
    // both actual leaf sides. Cheap HCE ordering/cached totals are unchanged.
    score + development_balance(board)
}
fn evaluate(board: &Board) -> i32 {
    let delta = functional_defense_balance(board);
    let pressure=pressure_adjustment(board,queen_counts(board));
    evaluate_ordering(board) + if board.side_to_move() == Color::White {delta+pressure} else {-delta-pressure}
}
// Move ordering deliberately retains the cheap baseline heuristic. The full
// functional-defense term is evaluated at search leaves, not for every sibling.
fn evaluate_ordering(board: &Board) -> i32 {
    let queens = Color::ALL.map(|color| board.location(Piece::new(color, Bug::Queen, 1)));
    let mut scores = Color::ALL.map(|c|pillbug_queen_readiness(board,c));
    for color in Color::ALL {
        if let Some(hex) = queens[color.index()] {
            let occupied = hex.neighbors().iter().filter(|&&h| board.is_occupied(h)).count();
            scores[color.index()] -= [0, 20, 55, 110, 220, 450, 0][occupied];
            if board.top(hex) != Some(Piece::new(color, Bug::Queen, 1)) {
                scores[color.index()] -= 80;
            }
        }
    }
    for (hex, stack) in board.occupied_stacks() {
        for (level, &piece) in stack.iter().enumerate() {
            if !board.game_type().includes(piece.bug) { continue; }
            let score = &mut scores[piece.color.index()];
            *score += 12;
            if level + 1 < stack.len() { *score -= 15; }
            if level > 0 && level + 1 == stack.len() && matches!(piece.bug, Bug::Beetle | Bug::Mosquito) { *score += 12; }
            if piece.bug != Bug::Queen {
                if let Some(target) = queens[piece.color.other().index()] {
                    *score += proximity_weight() * (6 - i32::from(hex.distance(target)).min(6));
                }
            }
        }
    }
    scores[board.side_to_move().index()] - scores[board.side_to_move().other().index()]
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn elevated_resources_cover_uncover_and_color_delta() {
        for color in Color::ALL {
            let mut b = Board::new(GameType {mosquito:true,ladybug:true,pillbug:true});
            let h=crate::Hex::new(0,0); let n=h.neighbors();
            let ant=Piece::new(color,Bug::Ant,1);
            let beetle=Piece::new(color,Bug::Beetle,1);
            let mosquito=Piece::new(color.other(),Bug::Mosquito,1);
            let other=Piece::new(color.other(),Bug::Beetle,1);
            for (piece,to) in [(ant,h),(beetle,n[0]),(mosquito,n[1]),(other,n[2])] {
                if b.side_to_move()!=piece.color { b.make_unchecked(HiveMove::Pass).unwrap(); }
                b.make_unchecked(HiveMove::Place{piece,to}).unwrap();
            }
            for mv in [
                HiveMove::Move{piece:beetle,from:n[0],to:h},
                HiveMove::Move{piece:mosquito,from:n[1],to:h},
                HiveMove::Move{piece:other,from:n[2],to:h},
                HiveMove::Move{piece:other,from:h,to:n[2]},
                HiveMove::Move{piece:mosquito,from:h,to:n[1]},
                HiveMove::Move{piece:beetle,from:h,to:n[0]},
            ] {
                let HiveMove::Move{piece,..}=mv else {unreachable!()};
                if b.side_to_move()!=piece.color { b.make_unchecked(HiveMove::Pass).unwrap(); }
                let before=piece_total(&b); let delta=piece_move_delta(&b,mv,&[None,None]);
                b.make_unchecked(mv).unwrap();
                assert_eq!(piece_total(&b),before+delta);
                // The eager reference includes the full leaf correction;
                // ordering deliberately retains its unchanged cheap formula.
                let correction=functional_defense_balance(&b)
                    * if b.side_to_move()==Color::White {1}else{-1};
                let pressure=super::pin_pressure_contracts::reference_pressure_balance(&b)
                    *if b.side_to_move()==Color::White{1}else{-1};
                assert_eq!(evaluate_ordering(&b),reference_evaluate(&b)-correction-pressure);
                let expected: i32=b.occupied_hexes().map(|hex| {
                    let stack=b.stack(hex).unwrap();
                    stack.iter().enumerate().map(|(i,p)| {
                        let score=12-if i+1<stack.len(){15}else{0}
                            +if i>0&&i+1==stack.len()&&matches!(p.bug,Bug::Beetle|Bug::Mosquito){12}else{0};
                        if p.color==Color::White {score}else{-score}
                    }).sum::<i32>()
                }).sum();
                assert_eq!(piece_total(&b),expected);
            }
        }
    }

    #[test]
    fn groundwork_lazy_bounds_never_discard_in_window_values() {
        for line in include_str!("../tests/groundwork_positions.txt").lines() {
            let b=crate::UhpGame::from_game_string(line).unwrap().board().clone();
            let total=piece_total(&b);let counts=queen_counts(&b);
            let exact=evaluate_counted_leaf(&b,total,0,counts);
            for alpha in [-500,-150,-50,0,50,150,500] {
                for width in [1,40,200] {
                    let beta=alpha+width;
                    let bounded=evaluate_windowed_leaf(&b,total,0,counts,alpha,beta);
                    if bounded<=alpha {assert!(exact<=alpha && bounded>=exact);}
                    else if bounded>=beta {assert!(exact>=beta && bounded<=exact);}
                    else {assert_eq!(bounded,exact);}
                }
            }
        }
    }

    #[test]
    fn pillbug_readiness_respects_color_coverage_and_variant() {
        for color in Color::ALL {
            for offset in [0, 40, -40] {
                let mut b = Board::new(GameType { mosquito:true, ladybug:true, pillbug:true });
                let q = Piece::new(color,Bug::Queen,1);
                let p = Piece::new(color,Bug::Pillbug,1);
                let h = crate::Hex::new(offset,-offset);
                assert_eq!(pillbug_queen_readiness(&b,color),0);
                if b.side_to_move()!=color { b.make_unchecked(HiveMove::Pass).unwrap(); }
                b.make_unchecked(HiveMove::Place{piece:q,to:h}).unwrap();
                assert_eq!(pillbug_queen_readiness(&b,color),PILLBUG_TWO_WINDOWS);
                let ph=h.neighbors()[0];
                if b.side_to_move()!=color { b.make_unchecked(HiveMove::Pass).unwrap(); }
                b.make_unchecked(HiveMove::Place{piece:p,to:ph}).unwrap();
                assert_eq!(pillbug_queen_readiness(&b,color),PILLBUG_SUPPORT);
                assert_eq!(pillbug_queen_readiness(&b,color.other()),0);
                let cover=Piece::new(color.other(),Bug::Beetle,1);
                b.make_unchecked(HiveMove::Place{piece:cover,to:h.neighbors()[3]}).unwrap();
                b.make_unchecked(HiveMove::Pass).unwrap();
                let undo=b.make_unchecked(HiveMove::Move{piece:cover,from:h.neighbors()[3],to:ph}).unwrap();
                assert_eq!(pillbug_queen_readiness(&b,color),0);
                b.undo(undo).unwrap();
                b.make_unchecked(HiveMove::Move{piece:cover,from:h.neighbors()[3],to:h}).unwrap();
                assert_eq!(pillbug_queen_readiness(&b,color),0);
            }
        }
        assert_eq!(pillbug_queen_readiness(&Board::new(GameType { mosquito:false, ladybug:false, pillbug:false }),Color::White),0);
    }

    #[test]
    fn pillbug_last_placement_window_and_deployment() {
        let root=r#"Base+MLP;InProgress;White[8];wA1;bM \wA1;wG1 /wA1;bQ bM/;wQ wG1-;bP \bQ;wL wQ-;bB1 bP/;wA2 -wG1;bG1 -bQ;wA2 bQ-;bA1 /bG1;wA3 wA2\;bG1 wQ\"#;
        let mut game=crate::UhpGame::from_game_string(root).unwrap();
        assert_eq!(pillbug_queen_readiness(game.board(),Color::White),PILLBUG_ONE_WINDOW);
        let placements:Vec<_>=game.board().legal_placements().into_iter().filter(|mv| matches!(mv,HiveMove::Place{piece,..} if piece.bug==Bug::Pillbug)).collect();
        assert!(placements.iter().any(|&mv|crate::move_to_uhp(game.board(),mv).unwrap()=="wP wQ/"));
        game.play("wP wQ/").unwrap();
        assert_eq!(pillbug_queen_readiness(game.board(),Color::White),PILLBUG_SUPPORT);
        game.undo(1).unwrap();
        game.play("wL wA1/").unwrap();game.play("bA1 wQ-").unwrap();
        assert_eq!(pillbug_queen_readiness(game.board(),Color::White),0);
    }

    #[test]
    fn carried_queen_counts_match_full_recount() {
        let mut checked=0;
        for line in include_str!("../tests/search_positions.txt").lines().filter(|x| !x.is_empty()) {
            let game=crate::UhpGame::from_game_string(line).unwrap();
            let mut board=game.board().clone();
            for _ in 0..12 {
                let queens=Color::ALL.map(|c|board.location(Piece::new(c,Bug::Queen,1)));
                let counts=queen_counts(&board);
                let moves=board.legal_moves();
                if moves.is_empty() {break;}
                for &mv in &moves {
                    let before=Position::new(&board);
                    let next=projected_queen_counts(&board,mv,&queens,counts);
                    let undo=board.make_generated(mv);
                    let child=next.unwrap_or_else(||queen_counts(&board));
                    assert_eq!(child,queen_counts(&board));
                    for ply in [0,3,64] {
                        assert_eq!(counted_terminal(&board,ply,child),terminal(&board,ply));
                        assert_eq!(evaluate_counted_leaf(&board,piece_total(&board),ply,child),evaluate_leaf(&board,piece_total(&board),ply));
                    }
                    board.undo_generated(undo);
                    assert_eq!(Position::new(&board),before);
                    assert_eq!(queen_counts(&board),counts);
                    checked+=1;
                }
                board.make_generated(moves[checked % moves.len()]);
            }
        }
        assert!(checked>1000,"{checked}");
    }

    use crate::GameType;

    // Frozen eager-ranking reference from v0.10.4. It deliberately retains
    // full ranking before hint selection to verify scheduling equivalence.
    fn eager_negamax(worker: &mut Search, board: &mut Board, depth: u8, ply: u8,
               mut alpha: i32, beta: i32) -> Result<i32, ()> {
        if worker.expired() { return Err(()); }
        worker.nodes += 1;
        if let Some(score) = terminal(board, ply) { return Ok(score); }
        if depth == 0 { return Ok(evaluate(board)); }
        let original_alpha = alpha;
        let mut hint = None;
        // Require the same horizon for score reuse, preserving exact fixed-depth
        // semantics across transpositions reached at different plies.
        let cached = if depth >= 2 && !worker.table.is_empty() {
            let position = Position::new(board);
            let key = position.key();
            let slot = key as usize & (worker.table.len() - 1);
            if let Some(entry) = worker.table[slot] {
                if entry.key == key && entry.position == position {
                    hint = entry.best_move;
                    let value = load_score(entry.score, ply);
                    if entry.depth == depth && (entry.bound == Bound::Exact
                        || (entry.bound == Bound::Lower && value >= beta)
                        || (entry.bound == Bound::Upper && value <= alpha)) {
                        return Ok(value);
                    }
                }
            }
            Some((key, slot, position))
        } else { None };
        let mut moves = board.legal_moves();
        if depth >= 2 { worker.order_moves(board, &mut moves, ply)?; }
        // Reuse sibling cutoff moves only if present in this node's legal list.
        // Keep remaining static order stable and prefer the position-specific hint.
        let mut front = 0;
        for preferred in [hint, worker.killers[ply as usize][0], worker.killers[ply as usize][1]] {
            if let Some(mv) = preferred {
                if moves[..front].contains(&mv) { continue; }
                if let Some(offset) = moves[front..].iter().position(|m| *m == mv) {
                    moves[front..=front + offset].rotate_right(1);
                    front += 1;
                }
            }
        }
        let mut best_move = None;
        let mut best_score = -WIN - 1;
        for mv in moves {
            if worker.expired() { return Err(()); }
            let undo = board.make_generated(mv);
            let child = eager_negamax(worker, board, depth - 1, ply + 1, -beta, -alpha);
            // Always restore, including an interrupted subtree.
            board.undo_generated(undo);
            let score = -child?;
            if score > best_score { best_score = score; best_move = Some(mv); }
            if score >= beta {
                let killers = &mut worker.killers[ply as usize];
                if killers[0] != Some(mv) { killers[1] = killers[0]; killers[0] = Some(mv); }
                if let Some((key, slot, position)) = cached {
                    worker.table[slot] = Some(Entry { key, position, depth,
                        score: store_score(score, ply), bound: Bound::Lower, best_move: Some(mv) });
                }
                return Ok(score);
            }
            alpha = alpha.max(score);
        }
        if let Some((key, slot, position)) = cached {
            worker.table[slot] = Some(Entry { key, position, depth, score: store_score(alpha, ply),
                bound: if alpha <= original_alpha { Bound::Upper } else { Bound::Exact }, best_move });
        }
        Ok(alpha)
    }

    #[test]
    fn deferred_ranking_matches_eager_tree_and_restores_on_interrupt() {
        for text in include_str!("../tests/search_positions.txt").lines() {
            let game = crate::UhpGame::from_game_string(text).unwrap();
            for slots in [0, 1, 16384] {
                let mut eager = Search { history: None, killers: [[None; 2]; 65], table: vec![None; slots], deadline: None, nodes: 0, node_limit: None };
                let mut deferred = Search { history: None, killers: [[None; 2]; 65], table: vec![None; slots], deadline: None, nodes: 0, node_limit: None };
                let mut a = game.board().clone();
                let mut b = a.clone();
                for depth in 1..=3 {
                    assert_eq!(eager_negamax(&mut eager, &mut a, depth, 0, -WIN-1, WIN+1),
                        deferred.negamax(&mut b, depth, 0, -WIN-1, WIN+1));
                    assert_eq!(eager.nodes, deferred.nodes);
                    assert_eq!(eager.killers, deferred.killers);
                    assert_eq!(Position::new(&a), Position::new(game.board()));
                    assert_eq!(Position::new(&b), Position::new(game.board()));
                }
                deferred.table.fill(None);
                deferred.node_limit = Some(deferred.nodes + 20);
                assert!(deferred.negamax(&mut b, 5, 0, -WIN-1, WIN+1).is_err());
                assert_eq!(Position::new(&b), Position::new(game.board()));
            }
        }
    }

    fn reference_evaluate(board: &Board) -> i32 {
        fn value(board: &Board, color: Color) -> i32 {
            let queen = Piece::new(color, Bug::Queen, 1);
            let mut score = pillbug_queen_readiness(board,color);
            if let Some(hex) = board.location(queen) {
                let occupied = hex.neighbors().iter().filter(|&&h| board.is_occupied(h)).count();
                score -= [0, 20, 55, 110, 220, 450, 0][occupied];
                if board.top(hex) != Some(queen) { score -= 80; }
            }
            for piece in Piece::all_for(color, board.game_type()) {
                if let Some(hex) = board.location(piece) {
                    score += 12; // modest development preference
                    if board.top(hex) != Some(piece) { score -= 15; }
                    if board.top(hex) == Some(piece) && board.stack_height(hex) > 1 && matches!(piece.bug, Bug::Beetle | Bug::Mosquito) { score += 12; }
                    if piece.bug != Bug::Queen {
                        if let Some(target) = board.location(Piece::new(color.other(), Bug::Queen, 1)) {
                            score += (if matches!(option_env!("FOULBROOD_CAUTIOUS_STYLE"),Some("pin_develop_v1"|"pin_pressure_v2")) {0}else{3}) * (6 - i32::from(hex.distance(target)).min(6));
                        }
                    }
                }
            }
            score
        }
        value(board, board.side_to_move()) - value(board, board.side_to_move().other())
            +(functional_defense_balance(board)+super::pin_pressure_contracts::reference_pressure_balance(board))
                *if board.side_to_move()==Color::White{1}else{-1}
    }

    #[test]
    fn allocation_free_evaluation_matches_reference_across_variants() {
        let mut count = 0;
        let mut covered = false;
        let mut queen_in_hand = false;
        for flags in 0..8 {
            let game_type = GameType { mosquito: flags & 1 != 0,
                ladybug: flags & 2 != 0, pillbug: flags & 4 != 0 };
            for seed in 1..=8u64 {
                let mut random = seed * 0x9e3779b9 + flags;
                let mut board = Board::new(game_type);
                for _ in 0..100 {
                    assert_eq!(evaluate(&board), reference_evaluate(&board));
                    count += 1;
                    for color in Color::ALL {
                        queen_in_hand |= board.location(Piece::new(color, Bug::Queen, 1)).is_none();
                    }
                    covered |= board.occupied_hexes().any(|h| board.stack(h).unwrap().len() > 1);
                    let moves = board.legal_moves();
                    if moves.is_empty() { break; }
                    let before = Position::new(&board);
                    let ready=Color::ALL.map(|c|pillbug_queen_readiness(&board,c));
                    for c in Color::ALL {assert_eq!(ready[c.index()],pillbug_readiness_after(&board,c,None));}
                    for &mv in moves.iter().step_by((moves.len()/4).max(1)) {
                        for c in Color::ALL {assert_eq!(cached_readiness_after(&board,c,mv,Some(ready)),pillbug_readiness_after(&board,c,Some(mv)));}
                        let parent = piece_total(&board);
                        let old = changed_total(&board,mv);
                        let predicted = projected_ranking_score(&board,mv,1,&Color::ALL.map(|c| board.location(Piece::new(c,Bug::Queen,1))),queen_counts(&board),parent);
                        let delta = piece_move_delta(&board,mv,&Color::ALL.map(|c| board.location(Piece::new(c,Bug::Queen,1))));
                        let undo = board.make_generated(mv);
                        let parts = if queen_moved(mv) {piece_total(&board)} else {parent-old+changed_total(&board,mv)};
                        assert_eq!(if queen_moved(mv) {piece_total(&board)} else {parent+delta}, piece_total(&board));
                        assert_eq!(evaluate_parts(&board,parts), reference_evaluate(&board));
                        if let Some(score)=predicted {assert_eq!(score,-terminal(&board,1).unwrap_or_else(|| evaluate_ordering(&board)));}
                        assert_eq!(evaluate(&board), reference_evaluate(&board));
                        board.undo_generated(undo);
                        assert_eq!(Position::new(&board), before);
                    }
                    random ^= random << 13; random ^= random >> 7; random ^= random << 17;
                    board.make_generated(moves[random as usize % moves.len()]);
                }
            }
        }
        assert!(count > 3000 && covered && queen_in_hand);
    }

    #[test]
    fn stack_evaluation_matches_reference_on_translated_mixed_stacks() {
        for offset in [-12000_i16, 0, 12000] {
            let mut board = Board::new(GameType::mlp());
            let wq = Piece::new(Color::White, Bug::Queen, 1);
            let bq = Piece::new(Color::Black, Bug::Queen, 1);
            let wb = Piece::new(Color::White, Bug::Beetle, 1);
            let bb = Piece::new(Color::Black, Bug::Beetle, 1);
            let hex = |q| crate::Hex::new(offset + q, -offset);
            for (piece, q) in [(wq, 0), (bq, 1), (wb, -1), (bb, 2)] {
                board.make_unchecked(HiveMove::Place { piece, to: hex(q) }).unwrap();
                assert_eq!(evaluate(&board), reference_evaluate(&board));
            }
            for (piece, from) in [(wb, -1), (bb, 2)] {
                let mv = HiveMove::Move { piece, from: hex(from), to: hex(1) };
                let undo = board.make_unchecked(mv).unwrap();
                assert_eq!(evaluate(&board), reference_evaluate(&board));
                board.undo(undo).unwrap();
                assert_eq!(evaluate(&board), reference_evaluate(&board));
                board.make_unchecked(mv).unwrap();
            }
            assert_eq!(board.stack(hex(1)).unwrap().len(), 3);
            // Both sides, including leaving mixed stacks, must match a full total.
            for _ in 0..2 {
                let queens = Color::ALL.map(|c| board.location(Piece::new(c,Bug::Queen,1)));
                let parent = piece_total(&board);
                assert_eq!(piece_move_delta(&board,HiveMove::Pass,&queens),0);
                for mv in board.legal_moves() {
                    let delta = piece_move_delta(&board,mv,&queens);
                    let undo = board.make_generated(mv);
                    if !queen_moved(mv) { assert_eq!(parent+delta,piece_total(&board)); }
                    board.undo_generated(undo);
                }
                board.make_generated(HiveMove::Pass);
            }
        }
    }

    fn exhaustive(board: &mut Board, depth: u8, ply: u8) -> i32 {
        if let Some(s) = terminal(board, ply) { return s; }
        if depth == 0 { return evaluate(board); }
        board.legal_moves().into_iter().map(|mv| {
            let undo = board.make_generated(mv);
            let score = -exhaustive(board, depth - 1, ply + 1);
            board.undo_generated(undo);
            score
        }).max().unwrap()
    }

    #[test]
    fn alpha_beta_matches_exhaustive_and_preserves_board() {
        for game_type in [GameType::base(), GameType::mlp()] {
            let mut board = Board::new(game_type);
            for step in 0..7 {
                let before = format!("{board:?}");
                let expected = exhaustive(&mut board.clone(), 2, 0);
                let result = search(&board, SearchLimit::Depth(2));
                assert_eq!(result.score, Some(expected));
                let mv = result.best_move.unwrap();
                assert!(board.legal_moves().contains(&mv));
                let mut child = board.clone();
                child.make_generated(mv);
                assert_eq!(-exhaustive(&mut child, 1, 1), expected);
                assert_eq!(format!("{board:?}"), before);
                let moves = board.legal_moves();
                board.make_generated(moves[(step * 13) % moves.len()]);
            }
        }
    }

    #[test]
    fn full_mlp_midgames_match_exhaustive_minimax() {
        for text in include_str!("../tests/search_positions.txt").lines() {
            let game = crate::UhpGame::from_game_string(text).unwrap();
            let board = game.board();
            let expected = exhaustive(&mut board.clone(), 3, 0);
            let result = search(board, SearchLimit::Depth(3));
            assert_eq!(result.score, Some(expected));
            let mut child = board.clone();
            child.make_generated(result.best_move.unwrap());
            assert_eq!(-exhaustive(&mut child, 2, 1), expected);
        }
    }

    #[test]
    fn table_bounds_horizons_and_collisions_match_exhaustive() {
        let game = crate::UhpGame::from_game_string(include_str!("../tests/search_positions.txt").lines().next().unwrap()).unwrap();
        let mut board = game.board().clone();
        let expected = exhaustive(&mut board.clone(), 3, 0);
        for slots in [0, 1, 16384] {
            let mut worker = Search { history: None, killers: [[None; 2]; 65], table: vec![None; slots], deadline: None, nodes: 0, node_limit: None };
            for (a,b) in [(expected-2,expected-1),(expected+1,expected+2),(-WIN-1,WIN+1)] {
                let score = worker.negamax(&mut board, 3, 0, a, b).unwrap();
                if score <= a { assert!(expected <= score); }
                else if score >= b { assert!(expected >= score); }
                else { assert_eq!(score, expected); }
            }
            assert_eq!(worker.negamax(&mut board, 2, 0, -WIN-1, WIN+1).unwrap(), exhaustive(&mut board.clone(), 2, 0));
            if slots != 0 {
                let key = Position::new(&board).key();
                let mut wrong = Position::new(&board);
                wrong.pieces[0] ^= 1;
                worker.table[key as usize & (slots-1)] = Some(Entry {key, position:wrong, depth:3, score:12345, bound:Bound::Exact, best_move:None});
                assert_eq!(worker.negamax(&mut board, 3, 0, -WIN-1, WIN+1).unwrap(), expected);
            }
        }
    }

    #[test]
    fn stale_and_duplicate_cutoff_moves_preserve_minimax() {
        let game = crate::UhpGame::from_game_string(include_str!("../tests/search_positions.txt").lines().next().unwrap()).unwrap();
        let mut board = game.board().clone();
        let expected = exhaustive(&mut board.clone(), 2, 0);
        let legal = board.legal_moves()[0];
        let stale = HiveMove::Place { piece: Piece::new(Color::White, Bug::Queen, 1),
            to: crate::Hex::new(100, 100) };
        assert!(!board.legal_moves().contains(&stale));
        for hints in [[Some(stale), Some(legal)], [Some(legal), Some(legal)]] {
            let mut worker = Search { history: None, killers: [hints; 65], table: vec![], deadline: None, nodes: 0, node_limit: None };
            let before = Position::new(&board);
            assert_eq!(worker.negamax(&mut board, 2, 0, -WIN-1, WIN+1).unwrap(), expected);
            assert_eq!(Position::new(&board), before);
        }
    }

    #[test]
    fn table_mate_scores_are_relative_to_the_position() {
        for ply in 0..=32 {
            for score in [WIN-40, -WIN+40, -350, 0, 350] {
                assert_eq!(load_score(store_score(score, ply), ply), score);
            }
        }
        assert_eq!(load_score(store_score(WIN-7, 3), 5), WIN-9);
        assert_eq!(load_score(store_score(-WIN+7, 3), 5), -WIN+9);
    }

    #[test]
    fn last_moved_restriction_is_part_of_pillbug_identity() {
        for game_type in [GameType::base(), GameType::mlp()] {
            let mut board = Board::new(game_type);
            place(&mut board, Color::White, Bug::Queen, 1, 0, 0);
            place(&mut board, Color::Black, Bug::Queen, 1, -1, 0);
            place(&mut board, Color::White, Bug::Ant, 1, 1, 0);
            place(&mut board, Color::Black, Bug::Beetle, 1, -2, 0);
            for _ in 0..8 { board.make_unchecked(HiveMove::Pass).unwrap(); }
            board.make_unchecked(HiveMove::Move {piece:Piece::new(Color::White,Bug::Ant,1),
                from:crate::Hex::new(1,0),to:crate::Hex::new(1,-1)}).unwrap();
            let moved = Position::new(&board);
            board.make_unchecked(HiveMove::Pass).unwrap();
            board.make_unchecked(HiveMove::Pass).unwrap();
            let cleared = Position::new(&board);
            assert_eq!(moved.pieces, cleared.pieces);
            assert_eq!(moved == cleared, !game_type.pillbug);
        }
    }

    #[test]
    fn exact_position_tracks_rule_state_and_restores() {
        for game_type in [GameType::base(),GameType::mlp()] {
            let mut board = Board::new(game_type);
            let first = Position::new(&board);
            let undo = board.make_unchecked(HiveMove::Pass).unwrap();
            assert_ne!(first, Position::new(&board));
            board.undo(undo).unwrap();
            assert_eq!(first, Position::new(&board));
            for step in 0..20 {
                let before = Position::new(&board);
                let moves = board.legal_moves();
                for &mv in moves.iter().take(12) {
                    let undo = board.make_generated(mv);
                    assert_ne!(before, Position::new(&board));
                    board.undo_generated(undo);
                    assert_eq!(before, Position::new(&board));
                }
                board.make_generated(moves[(step*7)%moves.len()]);
            }
        }
    }

    fn place(board: &mut Board, color: Color, bug: Bug, number: u8, q: i16, r: i16) {
        if board.side_to_move() != color { board.make_unchecked(HiveMove::Pass).unwrap(); }
        board.make_unchecked(HiveMove::Place {
            piece: Piece::new(color, bug, number), to: crate::Hex::new(q, r),
        }).unwrap();
    }

    #[test]
    fn finds_immediate_surround_for_either_color_and_handles_forced_pass() {
        for side in Color::ALL {
            let mut board = Board::new(GameType::base());
            place(&mut board, side.other(), Bug::Queen, 1, 0, 0);
            place(&mut board, side, Bug::Queen, 1, -2, 0);
            for (bug, number, q, r) in [
                (Bug::Beetle, 1, 1, -1), (Bug::Spider, 1, 0, -1),
                (Bug::Spider, 2, -1, 0), (Bug::Grasshopper, 1, -1, 1),
                (Bug::Grasshopper, 2, 0, 1), (Bug::Ant, 1, 2, -1),
            ] { place(&mut board, side, bug, number, q, r); }
            if board.side_to_move() != side { board.make_unchecked(HiveMove::Pass).unwrap(); }
            let before = format!("{board:?}");
            let result = search(&board, SearchLimit::Depth(1));
            assert_eq!(result.score, Some(WIN - 1));
            assert_eq!(format!("{board:?}"), before);
            let mut won = board.clone();
            won.make_generated(result.best_move.unwrap());
            assert!(won.queen_surrounded(side.other()));
            let terminal = search(&won, SearchLimit::Depth(4));
            assert_eq!(terminal.best_move, None);
            assert_eq!(terminal.score, Some(-WIN));
            board.make_unchecked(HiveMove::Pass).unwrap();
            assert_eq!(board.legal_moves(), vec![HiveMove::Pass]);
            let forced = search(&board, SearchLimit::Depth(2));
            assert_eq!(forced.best_move, Some(HiveMove::Pass));
            assert_eq!(forced.score, Some(-WIN + 2));
            let mut worker = Search { history: None, killers: [[None; 2]; 65], table: vec![None; 64], deadline: None, nodes: 0, node_limit: None };
            assert_eq!(worker.negamax(&mut board, 2, 0, -WIN-1, WIN+1).unwrap(), -WIN+2);
            assert_eq!(worker.negamax(&mut board, 2, 5, -WIN-1, WIN+1).unwrap(), -WIN+7);
        }
    }

    #[test]
    fn simultaneous_surround_is_a_draw() {
        let mut board = Board::new(GameType::mlp());
        place(&mut board, Color::White, Bug::Queen, 1, 0, 0);
        place(&mut board, Color::Black, Bug::Queen, 1, 1, 0);
        let mut cells = std::collections::BTreeSet::new();
        cells.extend(crate::Hex::ORIGIN.neighbors());
        cells.extend(crate::Hex::new(1, 0).neighbors());
        let mut pieces = Piece::all_for(Color::White, GameType::mlp()).into_iter()
            .filter(|p| p.bug != Bug::Queen);
        for hex in cells {
            if board.is_occupied(hex) { continue; }
            let p = pieces.next().unwrap();
            place(&mut board, p.color, p.bug, p.number, hex.q, hex.r);
        }
        let result = search(&board, SearchLimit::Depth(3));
        assert_eq!(result.best_move, None);
        assert_eq!(result.score, Some(0));
    }

    #[test]
    fn zero_and_short_deadlines_return_legal_moves_without_mutation() {
        let board = Board::new(GameType::mlp());
        let before = format!("{board:?}");
        for time in [Duration::ZERO, Duration::from_millis(20), Duration::MAX] {
            let result = search(&board, SearchLimit::Time(time));
            assert!(board.legal_moves().contains(&result.best_move.unwrap()));
            assert!(result.elapsed < Duration::from_secs(1));
            if time.is_zero() { assert_eq!(result.completed_depth, 0); }
        }
        assert_eq!(format!("{board:?}"), before);
        let mut working = board.clone();
        let mut worker = Search { history: None, killers: [[None; 2]; 65], table: vec![None; 16384], deadline: Some(crate::deadline::Deadline::at(Instant::now())), nodes: 0, node_limit: None };
        assert!(worker.negamax(&mut working, 4, 0, -WIN-1, WIN+1).is_err());
        assert_eq!(format!("{working:?}"), before);
        // Cancel after entering descendants, not merely at the root.
        worker.deadline = None;
        worker.node_limit = Some(10);
        assert!(worker.negamax(&mut working, 4, 0, -WIN-1, WIN+1).is_err());
        assert_eq!(worker.nodes, 10);
        assert_eq!(format!("{working:?}"), before);
    }

    #[test]
    fn fused_leaf_matches_independent_terminal_and_evaluation() {
        let mut checked=0;
        let check=|board:&Board| {
            for ply in [0,3,64] {
                assert_eq!(evaluate_leaf(board,piece_total(board),ply),terminal(board,ply).unwrap_or_else(||reference_evaluate(board)));
                assert_eq!(evaluate_counted_leaf(board,piece_total(board),ply,queen_counts(board)),terminal(board,ply).unwrap_or_else(||reference_evaluate(board)));
                assert_eq!(counted_terminal(board,ply,queen_counts(board)),terminal(board,ply));
            }
        };
        for text in include_str!("../tests/defense_terminal_positions.txt").lines() {
            let game=crate::UhpGame::from_game_string(text).unwrap();check(game.board());
        }
        for mask in 0..8 {
            let mut board=Board::new(GameType{mosquito:mask&1!=0,ladybug:mask&2!=0,pillbug:mask&4!=0});
            for step in 0..100 {
                check(&board);let legal=board.legal_moves();if legal.is_empty(){break;}
                for &mv in &legal {
                    let queens=Color::ALL.map(|c|board.location(Piece::new(c,Bug::Queen,1)));
                    let counts=queen_counts(&board);
                    assert_eq!(projected_queen_counts(&board,HiveMove::Pass,&queens,counts),Some(counts));
                    let projected=projected_queen_counts(&board,mv,&queens,counts);
                    let u=board.make_generated(mv);
                    assert_eq!(projected.unwrap_or_else(||queen_counts(&board)),queen_counts(&board));
                    check(&board);board.undo_generated(u);assert_eq!(queen_counts(&board),counts);checked+=1;
                }
                board.make_generated(legal[(step*17+mask as usize)%legal.len()]);
            }
        }
        assert!(checked>10000);
        eprintln!("fused leaf checked {checked} child positions");
    }
}

#[cfg(test)]
mod repetition_tests {
    use super::*;
    fn worker(history:Vec<Position>) -> Search {
        Search { history:Some(history), table:vec![None;64],killers:[[None;2];65],deadline:None,nodes:0,node_limit:None }
    }
    #[test]
    fn leaf_shortcut_matches_full_history_check_through_archived_draws() {
        let mut draws=0;
        let mut placements=0;
        for line in include_str!("../tests/archive_repetition.txt").lines() {
            let mut fields=line.split('|');let id=fields.next().unwrap();
            let end:usize=fields.next().unwrap().parse().unwrap();
            let mut game=crate::UhpGame::new(crate::GameType::mlp());
            let mut history=vec![Position::new(game.board())];
            for (index,text) in fields.next().unwrap().split(';').take(end).enumerate() {
                game.play(text).unwrap();
                let mut board=game.board().clone();
                let played=board.last_move().unwrap_or(HiveMove::Pass);
                placements+=usize::from(matches!(played,HiveMove::Place{..}));
                let mut full=worker(history.clone());
                let expected=full.negamax(&mut board,0,1,-WIN-1,WIN+1);
                let total=piece_total(&board);let counts=queen_counts(&board);
                let mut fast=worker(history.clone());
                assert_eq!(fast.negamax_parts(&mut board,0,1,-WIN-1,WIN+1,total,counts,Some(played)),expected,"{id} ply {}",index+1);
                assert_eq!(fast.history.as_ref(),Some(&history));
                assert_eq!(fast.nodes,full.nodes);
                if index+1==end {assert_eq!(expected,Ok(0));draws+=1;}
                history.push(Position::new(&board));
            }
        }
        assert_eq!(draws,62);assert!(placements>500);
    }
    #[test]
    fn third_occurrence_is_draw_even_at_leaf_and_restores_path() {
        let g=crate::UhpGame::from_game_string(include_str!("../tests/search_positions.txt").lines().next().unwrap()).unwrap();
        let mut b=g.board().clone();let p=Position::new(&b);
        let mut w=worker(vec![p,p]);
        for depth in [0,2] {
            assert_eq!(w.negamax(&mut b,depth,1,-WIN-1,WIN+1),Ok(0));
            assert_eq!(w.history,Some(vec![p,p]));assert_eq!(Position::new(&b),p);
        }
        // A second occurrence is searched, not adjudicated as a draw.
        let mut w=worker(vec![p]);
        assert_eq!(w.negamax(&mut b,0,1,-WIN-1,WIN+1),Ok(evaluate_counted_leaf(&b,piece_total(&b),1,queen_counts(&b))));
        assert_eq!(w.history,Some(vec![p]));
    }
    #[test]
    fn history_sensitive_search_ignores_cached_scores_and_restores_on_interrupt() {
        let g=crate::UhpGame::from_game_string(include_str!("../tests/search_positions.txt").lines().next().unwrap()).unwrap();
        let mut b=g.board().clone();let p=Position::new(&b);let key=p.key();
        let mut w=worker(vec![]);
        w.table[key as usize & 63]=Some(Entry{key,position:p,depth:2,score:123456,bound:Bound::Exact,best_move:None});
        let expected=worker(vec![]).negamax(&mut b,2,0,-WIN-1,WIN+1);
        assert_eq!(w.negamax(&mut b,2,0,-WIN-1,WIN+1),expected);
        for limit in [0,1,5,20] {
            let mut w=worker(vec![p]);w.node_limit=Some(limit);
            assert!(w.negamax(&mut b,6,1,-WIN-1,WIN+1).is_err());
            assert_eq!(w.history,Some(vec![p]));assert_eq!(Position::new(&b),p);
        }
    }
}

#[cfg(test)]
mod partial_root_tests {
 use super::*;
 #[test]
 fn interrupted_root_choice_beats_incumbent_at_same_depth() {
 let roots: &[&str] = &["Base+MLP;InProgress;White[11];wG1;bS1 \\wG1;wB1 wG1\\;bQ -bS1;wM -wB1;bG1 /bQ;wQ /wM;bB1 -bQ;wP wQ-;bP \\bQ;wA1 wB1/;bG1 bQ/;wA1 \\bP;bQ /wA1;wB2 wA1/;bB1 bP;wQ wP\\;bS2 -bS1;wA2 /wM;bB1 wB2\\", "Base+MLP;InProgress;White[11];wP;bP /wP;wB1 wP/;bS1 /bP;wM wB1-;bA1 bS1-;wQ wB1/;bQ bA1-;wA1 wB1\\;bM bS1\\;wM bQ\\;bM \\wQ;wB2 wM-;bB1 -bM;wB2 wM/;bS1 /wA1;wA2 /wM;bA1 wA1-;wA2 -wM;bB1 bM", "Base+MLP;InProgress;White[11];wS1;bP \\wS1;wS2 /wS1;bL -bP;wL /wS2;bM bP/;wQ -wL;bQ \\bM;wP wQ\\;bA1 /bQ;wQ /wP;bM wQ-;wB1 wS1-;bB1 bM-;wQ -wL;bB1 /wP;wA1 wQ/;bA2 bB1\\;wB1 wS1/;bA2 -wQ", "Base+MLP;InProgress;White[11];wM;bA1 wM/;wB1 -wM;bA2 bA1/;wG1 /wB1;bS1 bA1-;wQ -wG1;bQ bA2/;wP wQ/;bP bQ\\;wG1 wB1/;bA3 bS1\\;wM bQ-;bM /bS1;wB2 wM-;bA2 -wQ;wA1 wB2\\;bM wQ-;bQ /wB2;bA3 /wQ", "Base+MLP;InProgress;White[11];wA1;bM wA1\\;wG1 -wA1;bQ bM\\;wB1 \\wG1;bQ bM-;wQ \\wB1;bB1 bQ\\;wM wA1/;bP /bQ;wM bQ/;bP wA1-;wB2 wM-;bM wQ-;wQ \\bM;bG1 bM-;wB2 wM;bG1 /wQ;wQ bM/;bG1 wQ\\", "Base+MLP;InProgress;White[11];wS1;bG1 /wS1;wQ wS1/;bG2 -bG1;wP \\wQ;bG3 -bG2;wG1 -wQ;bQ /bG1;wA1 -wG1;bP -bQ;wA1 bQ\\;bG3 -wA1;wA1 -bP;bQ wA1\\;wS2 -wA1;bA1 \\bG2;wQ wP/;bG3 wA1/;wS2 bQ\\;wA1 wS2/"];
 let mut changes=0;
 for root in roots {
  let game=crate::UhpGame::from_game_string(root).unwrap();let board=game.board();
  let before=format!("{board:?}"); let history=[Position::new(board)];
  let full=search_with_history(board,SearchLimit::Depth(3),&history);
  for n in 1..20 {
   let cap=(full.nodes*n/20).max(1); let mut last=None;
   let result=search_with_progress_limited(board,SearchLimit::Depth(3),&history,Some(cap),|r|last=Some(r.clone()));
   assert!(board.legal_moves().contains(&result.best_move.unwrap()));
   assert_eq!(before,format!("{board:?}"));
   if let Some(old)=last {
    if old.best_move!=result.best_move {
     changes+=1;assert_eq!(result.score,None);assert_eq!(result.completed_depth,old.completed_depth);
     let mut scores=Vec::new();
     for mv in [old.best_move.unwrap(),result.best_move.unwrap()] {
      let mut b=board.clone();b.make_generated(mv);
      let mut w=Search{history:Some(history.to_vec()),killers:[[None;2];65],table:vec![None;16384],deadline:None,nodes:0,node_limit:None};
      scores.push(-w.negamax(&mut b,old.completed_depth,1,-WIN-1,WIN+1).unwrap());
     }
     assert!(scores[1]>scores[0],"{:?}",scores);
    }
   }
  }
 }
 assert!(changes>0,"must exercise completed alternative during root interruption");
 }
}


#[cfg(test)]
mod development_balance_contracts {
    use super::*;
    use crate::{GameType,Hex,UhpGame};
    use std::collections::HashSet;

    fn setup(side:Color,extra:bool)->Board {
        let mut pieces=vec![
            (Piece::new(Color::White,Bug::Queen,1),Hex::new(-1,0),0),
            (Piece::new(Color::White,Bug::Ant,1),Hex::new(0,0),0),
            (Piece::new(Color::Black,Bug::Queen,1),Hex::new(1,0),0)];
        if extra {pieces.push((Piece::new(Color::Black,Bug::Ant,1),Hex::new(2,0),0));}
        Board::from_setup(GameType::mlp(),side,10,&pieces,None).unwrap()
    }
    fn components(cells:&HashSet<Hex>,skip:Option<Hex>)->usize {
        let mut left=cells.clone();if let Some(h)=skip{left.remove(&h);}let mut n=0;
        while let Some(&start)=left.iter().next(){n+=1;left.remove(&start);let mut todo=vec![start];
            while let Some(h)=todo.pop(){for next in h.neighbors(){if left.remove(&next){todo.push(next);}}}}
        n
    }
    // Independent explicit table: never use the production coefficient helper.
    fn reference_coefficients()->(i32,i32) {
        match option_env!("FOULBROOD_DEVELOPMENT_WEIGHTS").unwrap_or("reference") {
            "reference"=>(8,12), "deployment_lower"=>(6,12),
            "deployment_higher"=>(10,12), "pinning_lower"=>(8,9),
            "pinning_higher"=>(8,15), "support_shortfall"=>(8,12),
            other=>panic!("Unrecognized test configuration: {other}"),
        }
    }
    // Snapshot oracle only: a separately constructed off-turn fixture defines
    // potential after the stun expires. It is not a legal future history or pass.
    fn reference_shortfall(b:&Board,color:Color)->u8 {
        if b.game_over() {return 0;}
        let Some(target)=b.location(Piece::new(color.other(),Bug::Queen,1))else{return 0;};
        let holes=target.neighbors().iter().filter(|&&h|!b.is_occupied(h)).count() as u8;
        if holes==0{return 0;}
        if !b.queen_is_placed(color){return holes;}
        let turn=if b.side_to_move()==color{b.clone()}else{
            let pieces:Vec<_>=b.occupied_stacks().flat_map(|(h,stack)|stack.iter().copied()
                .enumerate().map(move |(z,p)|(p,h,z))).collect();
            Board::from_setup(b.game_type(),color,20,&pieces,None).unwrap()
        };
        let mut support=HashSet::new();
        for mv in turn.legal_moves_all_actors() {
            let (piece,from)=match mv {
                HiveMove::Move{piece,from,..}|HiveMove::Pillbug{piece,from,..}=>(piece,from),
                _=>continue,
            };
            if piece.color==color&&piece.bug!=Bug::Queen
                &&(from.distance(target)!=1||b.stack_height(from)>1){support.insert(piece);}
        }
        holes.saturating_sub(support.len() as u8)
    }
    fn reference_value(deployed:i32,pinned:i32,shortfall:u8)->i32 {
        let (d,p)=reference_coefficients();
        let penalty=match option_env!("FOULBROOD_DEVELOPMENT_WEIGHTS") {
            Some("support_shortfall")=>2*i32::from(shortfall),_=>0,
        };
        if option_env!("FOULBROOD_CAUTIOUS_STYLE")==Some("pin_pressure_v2")
            &&option_env!("FOULBROOD_DEVELOPMENT_WEIGHTS")==Some("deployment_higher") {
            (d*deployed).clamp(0,128)+p*pinned
        }else{(d*deployed+p*pinned-penalty).clamp(0,128)}
    }
    fn reference_limit()->i32 {
        if option_env!("FOULBROOD_CAUTIOUS_STYLE")==Some("pin_pressure_v2")
            &&option_env!("FOULBROOD_DEVELOPMENT_WEIGHTS")==Some("deployment_higher"){284}else{128}
    }
    fn reference_benefits(b:&Board)->[i32;2] {
        let cells:HashSet<_>=b.occupied_hexes().collect();let initial=components(&cells,None);
        Color::ALL.map(|color| {
            let deployed=Piece::all_for(color,b.game_type()).into_iter()
                .filter(|p|p.bug!=Bug::Queen&&b.location(*p).is_some()).count();
            let pinned=Piece::all_for(color.other(),b.game_type()).into_iter().filter(|p|{
                if p.bug==Bug::Queen{return false;}let Some(h)=b.location(*p)else{return false;};
                b.stack_height(h)==1&&components(&cells,Some(h))>initial
            }).count();
            reference_value(deployed as i32,pinned as i32,reference_shortfall(b,color))
        })
    }
    pub(super) fn reference_balance(b:&Board)->i32 {
        let values=reference_benefits(b);values[Color::White.index()]-values[Color::Black.index()]
    }
    fn swapped(b:&Board,mirror:bool)->Board {
        let pieces:Vec<_>=b.occupied_stacks().flat_map(|(h,stack)| {
            let h=if mirror{Hex::new(h.r,h.q)}else{h};
            stack.iter().copied().enumerate().map(move |(z,p)|
                (Piece::new(p.color.other(),p.bug,p.number),h,z))
        }).collect();
        Board::from_setup(b.game_type(),b.side_to_move().other(),20,&pieces,None).unwrap()
    }
    // Frozen pre-treatment feature formula, separate from the candidate helper.
    fn original_correction(b:&Board)->i32 {
        let mode=option_env!("FOULBROOD_STRATEGY").unwrap_or("defense");
        let mut v=if mode=="defense"||mode=="all"{
            functional_defense(b,Color::White)-functional_defense(b,Color::Black)
        }else{0};
        if matches!(mode,"control"|"access"|"beetle"|"all") {
            let side=|color|{
                let f=match mode{"control"=>crate::movement::groundwork_resources(b,color,false),
                    "beetle"=>crate::movement::groundwork_resources(b,color,true),_=>crate::groundwork::features(b,color)};
                (if mode=="control"||mode=="all"{crate::groundwork::control(&f)}else{0})
                +(if mode=="access"||mode=="all"{crate::groundwork::access(&f)}else{0})
                +(if mode=="beetle"||mode=="all"{(if matches!(option_env!("FOULBROOD_CAUTIOUS_STYLE"),Some("pin_develop_v1"|"pin_pressure_v2")){0}else{20})*i32::from(f.queen_cover)+24*i32::from(f.pillbug_cover)+20*i32::from(f.queen_recovery)}else{0})
            };v+=side(Color::White)-side(Color::Black);
        }v
    }
    fn original_leaf(b:&Board,ply:u8)->i32 {
        if let Some(t)=terminal(b,ply){return t;}
        let mut white=piece_total(b)+pillbug_readiness_balance(b)+original_correction(b)
            +super::pin_pressure_contracts::reference_pressure_balance(b);
        for c in Color::ALL {let q=Piece::new(c,Bug::Queen,1);if let Some(h)=b.location(q){
            let count=h.neighbors().iter().filter(|&&n|b.is_occupied(n)).count();
            let penalty=[0,20,55,110,220,450,0][count]+if b.top(h)!=Some(q){80}else{0};
            white+=if c==Color::White{-penalty}else{penalty};
        }}
        if b.side_to_move()==Color::White{white}else{-white}
    }
    fn actual_leaf(b:&Board,ply:u8)->i32 {
        evaluate_windowed_leaf(b,piece_total(b),ply,queen_counts(b),-WIN-1,WIN+1)
    }
    fn worker(history:Vec<Position>)->Search {
        Search{history:Some(history),table:vec![None;64],killers:[[None;2];65],deadline:None,nodes:0,node_limit:None}
    }
    fn terminal_board(side:Color,white:bool,black:bool)->Board {
        let wq=Hex::new(0,0);let bq=Hex::new(1,0);
        let mut cells=std::collections::BTreeSet::new();
        if white{cells.extend(wq.neighbors());}if black{cells.extend(bq.neighbors());}
        cells.remove(&wq);cells.remove(&bq);
        let mut pieces=vec![(Piece::new(Color::White,Bug::Queen,1),wq,0),
                            (Piece::new(Color::Black,Bug::Queen,1),bq,0)];
        let nonqueens=Color::ALL.into_iter().flat_map(|c|Piece::all_for(c,GameType::mlp()))
            .filter(|p|p.bug!=Bug::Queen);
        for (h,p) in cells.into_iter().zip(nonqueens){pieces.push((p,h,0));}
        Board::from_setup(GameType::mlp(),side,20,&pieces,None).unwrap()
    }

    #[test]
    fn fixed_formula_positive_deployment_pin_deltas_and_clamp_match_reference() {
        let (deployment,pin)=reference_coefficients();
        assert_eq!(development_benefit(0,0),0);assert_eq!(development_benefit(1,0),deployment);
        assert_eq!(development_benefit(0,1),pin);assert_eq!(development_benefit(13,13),reference_limit());
        for shortfall in 0..=6 {
            for deployed in 0..=13 {for pins in 0..=13 {
                let actual=development_benefit_with_shortfall(deployed,pins,shortfall);
                assert_eq!(actual,reference_value(i32::from(deployed),i32::from(pins),shortfall));
                assert!((0..=reference_limit()).contains(&actual));
            }}
        }
        let all:Vec<_>=Color::ALL.into_iter().flat_map(|c|Piece::all_for(c,GameType::mlp()))
            .enumerate().map(|(i,p)|(p,Hex::new(i as i16,0),0)).collect();
        let maximum=Board::from_setup(GameType::mlp(),Color::White,20,&all,None).unwrap();
        let maxima=if reference_limit()==284{[272,284]}else{[128,128]};
        // One color's final physical P is a free endpoint in this28cell line;
        // the other13 nonQueens are all internal articulation cells.
        assert_eq!(reference_benefits(&maximum),maxima);
        assert_eq!(reference_balance(&maximum),maxima[0]-maxima[1]);
        assert_eq!(development_balance(&maximum),if development_balance_enabled(){maxima[0]-maxima[1]}else{0});
        for side in Color::ALL {
            let before=setup(side,false);let after=setup(side,true);
            // One White deployment vs one Black pin; then add one Black deployment.
            let before_expected=reference_value(1,0,reference_shortfall(&before,Color::White))
                -reference_value(0,1,reference_shortfall(&before,Color::Black));
            let after_expected=reference_value(1,0,reference_shortfall(&after,Color::White))
                -reference_value(1,1,reference_shortfall(&after,Color::Black));
            assert_eq!(reference_balance(&before),before_expected);
            assert_eq!(reference_balance(&after),after_expected);
            if development_weights_label()=="support_shortfall" {
                assert_eq!(Color::ALL.map(|c|reference_shortfall(&before,c)),[5,5]);
                assert_eq!(Color::ALL.map(|c|reference_shortfall(&after,c)),[4,4]);
                assert_eq!(before_expected,-2);assert_eq!(after_expected,-12);
            }
            let delta=reference_balance(&after)-reference_balance(&before);
            if development_weights_label()!="support_shortfall" {assert_eq!(before_expected,deployment-pin);assert_eq!(after_expected,-pin);assert_eq!(delta,-deployment);}
            assert_eq!(development_balance(&after)-development_balance(&before),if development_balance_enabled(){delta}else{0});
            assert_eq!(reference_balance(&swapped(&after,false))-reference_balance(&swapped(&before,false)),-delta);
            assert_eq!(development_balance(&swapped(&after,false))-development_balance(&swapped(&before,false)),if development_balance_enabled(){-delta}else{0});
            let mut cycle=vec![(Piece::new(Color::White,Bug::Queen,1),Hex::new(-1,0),0),
                (Piece::new(Color::White,Bug::Ant,1),Hex::new(0,0),0),
                (Piece::new(Color::Black,Bug::Queen,1),Hex::new(1,0),0),
                (Piece::new(Color::Black,Bug::Ant,1),Hex::new(0,-1),0),
                (Piece::new(Color::Black,Bug::Spider,1),Hex::new(1,-1),0)];
            let unpinned=Board::from_setup(GameType::mlp(),side,10,&cycle,None).unwrap();
            cycle[3].1=Hex::new(2,-1);
            let pinned=Board::from_setup(GameType::mlp(),side,10,&cycle,None).unwrap();
            let pin_delta=reference_balance(&pinned)-reference_balance(&unpinned);
            if development_weights_label()!="support_shortfall" {assert_eq!(pin_delta,-pin);}
            assert_eq!(development_balance(&pinned)-development_balance(&unpinned),if development_balance_enabled(){pin_delta}else{0});
            assert_eq!(reference_balance(&swapped(&pinned,false))-reference_balance(&swapped(&unpinned,false)),-pin_delta);
            assert_eq!(development_balance(&swapped(&pinned,false))-development_balance(&swapped(&unpinned,false)),if development_balance_enabled(){-pin_delta}else{0});
        }
    }

    #[test]
    fn full_leaf_symmetric_balance_has_correct_sign_on_both_actual_leaf_sides() {
        for side in Color::ALL {for extra in [false,true]{
            let b=setup(side,extra);let expected=if development_balance_enabled(){reference_balance(&b)}else{0};
            let signed=if side==Color::White{expected}else{-expected};
            assert_eq!(actual_leaf(&b,2)-original_leaf(&b,2),signed);
            assert_eq!(evaluate(&b)-evaluate_ordering(&b),
                (original_correction(&b)+expected+super::pin_pressure_contracts::reference_pressure_balance(&b))
                    *if side==Color::White{1}else{-1});
            assert_eq!(evaluate_parts(&b,piece_total(&b)),evaluate(&b));
            assert_eq!(evaluate_leaf(&b,piece_total(&b),2),actual_leaf(&b,2));
        }}
    }

    #[test]
    fn shortage_term_has_no_readiness_cliff_and_cannot_expand_the128_envelope() {
        for deployed in 0..=13 {for pins in 0..=13 {for shortage in 0..=6 {
            let value=development_benefit_with_shortfall(deployed,pins,shortage);
            assert!((0..=reference_limit()).contains(&value));
            if shortage>0 {
                let improved=development_benefit_with_shortfall(deployed,pins,shortage-1);
                assert!(improved>=value,"freeing support must not lower readiness benefit");
                assert!(improved-value<=2,"small fixed shortage slope, no all-deployed switch");
            }
            if deployed<13 {assert!(development_benefit_with_shortfall(deployed+1,pins,shortage)>=value);}
            if pins<13 {assert!(development_benefit_with_shortfall(deployed,pins+1,shortage)>=value);}
        }}}
        if development_weights_label()=="support_shortfall" {
            assert_eq!(development_benefit_with_shortfall(2,0,1),14);
            assert_eq!(development_benefit_with_shortfall(2,0,0),16);
            assert_eq!(development_benefit_with_shortfall(0,0,6),0);
            assert_eq!(development_benefit_with_shortfall(13,13,6),128);
        }
    }

    #[test]
    fn strategy_envelope_and_equality_windows_remain_rigorous_for_every_variant() {
        let base=match option_env!("FOULBROOD_STRATEGY").unwrap_or("defense"){
            "control"=>90,"access"|"beetle"=>64,"all"=>278,_=>60};
        assert_eq!(strategy_bound(),base+if development_balance_enabled(){reference_limit()}else{0});
        for flags in 0..8 {
            let ty=GameType{mosquito:flags&1!=0,ladybug:flags&2!=0,pillbug:flags&4!=0};
            let mut b=Board::new(ty);
            for _ in 0..24 {
                let total=piece_total(&b);let counts=queen_counts(&b);let ply=3;
                let exact=actual_leaf(&b,ply);let expected=original_leaf(&b,ply)
                    +if terminal(&b,ply).is_none()&&development_balance_enabled(){reference_balance(&b)*if b.side_to_move()==Color::White{1}else{-1}}else{0};
                assert_eq!(exact,expected);assert!(functional_defense_balance(&b).abs()<=strategy_bound());
                for (alpha,beta) in [(-WIN-1,WIN+1),(exact-1,exact),(exact,exact+1),(exact-500,exact-499),(exact+499,exact+500)] {
                    let value=evaluate_windowed_leaf(&b,total,ply,counts,alpha,beta);
                    if value<=alpha{assert!(exact<=value);}else if value>=beta{assert!(exact>=value);}else{assert_eq!(value,exact);}
                }
                if b.game_over(){break;}
                let moves=b.legal_moves();if moves.is_empty(){break;}
                // Deterministic typed fixture progression; no game outcome selection.
                b.make_generated(moves[0]);
            }
        }
    }

    #[test]
    fn all_queen_terminal_scores_and_history_draws_dominate_the_finite_bias() {
        for side in Color::ALL {for (white,black) in [(true,false),(false,true),(true,true)]{
            let b=terminal_board(side,white,black);assert_eq!(b.queen_surrounded(Color::White),white);
            assert_eq!(b.queen_surrounded(Color::Black),black);
            for ply in [0,1,23,64]{let exact=terminal(&b,ply).unwrap();
                assert_eq!(actual_leaf(&b,ply),exact);assert_eq!(evaluate_leaf(&b,piece_total(&b),ply),exact);
            }
        }}
        let b=setup(Color::Black,true);let p=Position::new(&b);let mut copy=b.clone();
        let mut s=worker(vec![p,p]);let before=s.history.clone();
        assert_eq!(s.negamax(&mut copy,0,1,-WIN-1,WIN+1),Ok(0));
        assert_eq!(s.history,before);assert_eq!(Position::new(&copy),p);
    }

    #[test]
    fn full_typed_history_feature_calls_and_legal_make_undo_restore_exact_state() {
        let mut game=UhpGame::new(GameType::mlp());
        for line in include_str!("../tests/long_game_raw_history.txt").lines().take(31){
            game.play_raw(crate::uhp::raw_move_from_fields(line).unwrap()).unwrap();
        }
        let before=game.raw_state_json();let history=game.exact_position_history().to_vec();
        let bonus=development_balance(game.board());let original=reference_balance(game.board());
        assert_eq!(bonus,if development_balance_enabled(){original}else{0});
        let legal=game.board().legal_moves();assert!(!legal.is_empty());
        for mv in legal.iter().copied().take(8){
            game.play_raw(mv).unwrap();assert_eq!(game.history().last(),Some(&mv));
            let expected=if development_balance_enabled(){reference_balance(game.board())}else{0};
            assert_eq!(development_balance(game.board()),expected);
            game.undo(1).unwrap();assert_eq!(game.raw_state_json(),before);
            assert_eq!(game.exact_position_history(),history.as_slice());
        }
        assert_eq!(game.board().legal_moves(),legal);
    }

    #[test]
    fn cheap_hce_and_cached_piece_totals_remain_the_unchanged_ordering_formula() {
        let mut b=setup(Color::Black,true);let mut legal=b.legal_moves();
        let mut expected=Vec::new();let before=Position::new(&b);let total=piece_total(&b);
        for &mv in &legal {let undo=b.make_generated(mv);
            let value=-terminal(&b,1).unwrap_or_else(||evaluate_ordering(&b));b.undo_generated(undo);
            expected.push((value,mv));}
        expected.sort_by_key(|&(value,_)|std::cmp::Reverse(value));
        worker(vec![before]).order_moves(&mut b,&mut legal,0).unwrap();
        assert_eq!(legal,expected.into_iter().map(|(_,mv)|mv).collect::<Vec<_>>());
        assert_eq!(Position::new(&b),before);assert_eq!(piece_total(&b),total);
        assert_eq!(evaluate_ordering(&b),evaluate_counted_base(&b,total,0,queen_counts(&b)));
    }
    #[test]
    fn color_swap_and_reflection_are_antisymmetric_for_every_active_variant() {
        for flags in 0..8 {for side in Color::ALL {
            let ty=GameType{mosquito:flags&1!=0,ladybug:flags&2!=0,pillbug:flags&4!=0};
            let b=Board::from_setup(ty,side,10,&[
                (Piece::new(Color::White,Bug::Queen,1),Hex::new(-1,0),0),
                (Piece::new(Color::White,Bug::Ant,1),Hex::new(0,0),0),
                (Piece::new(Color::Black,Bug::Queen,1),Hex::new(1,0),0),
                (Piece::new(Color::Black,Bug::Ant,1),Hex::new(2,0),0)],None).unwrap();
            assert_ne!(reference_balance(&b),0);
            for mirror in [false,true] {
                let other=swapped(&b,mirror);
                assert_eq!(reference_balance(&other),-reference_balance(&b));
                assert_eq!(development_balance(&other),-development_balance(&b));
                assert_eq!(reference_benefits(&other),[reference_benefits(&b)[1],reference_benefits(&b)[0]]);
                // Color and side are swapped together: side-relative full leaf stays equal.
                assert_eq!(actual_leaf(&other,2),actual_leaf(&b,2));
            }
        }}
    }

    #[test]
    fn two_capped_benefits_have_absolute_difference_bound128_not256() {
        for white in 0_i32..=128 {for black in 0_i32..=128 {
            assert!((-128..=128).contains(&(white-black)));
        }}
        assert_eq!(development_benefit(13,13)-development_benefit(0,0),reference_limit());
        assert_eq!(development_benefit(0,0)-development_benefit(13,13),-reference_limit());
        let baseline=match option_env!("FOULBROOD_STRATEGY").unwrap_or("defense"){
            "control"=>90,"access"|"beetle"=>64,"all"=>278,_=>60};
        assert_eq!(strategy_bound()-baseline,if development_balance_enabled(){reference_limit()}else{0});
    }

}

#[cfg(test)]
#[path = "search/cautious_contracts.rs"]
mod cautious_contracts;

#[cfg(test)]
#[path = "search/pin_pressure_contracts.rs"]
mod pin_pressure_contracts;
