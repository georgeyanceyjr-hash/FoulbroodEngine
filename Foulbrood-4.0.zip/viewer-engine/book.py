"""Public top-bot repertoire with exact physical-history context for deep entries."""
import hashlib,json,subprocess
from functools import lru_cache
from pathlib import Path
from legacy_book import transform,action_key,canonical as shallow_canonical
ROOT=Path(__file__).resolve().parent;BOARD=str(ROOT/'book-board')
@lru_cache(maxsize=20000)
def snapshot(game):
 return json.loads(subprocess.check_output([BOARD,'snapshot',game],text=True,timeout=15))
@lru_cache(maxsize=256)
def history(game):
 return json.loads(subprocess.check_output([BOARD,'trace',game],text=True,timeout=30))
def canonical(s,frames=None):
 key,ts=shallow_canonical(s)
 if s['ply']<16:return key,ts
 frames=history(s['game']) if frames is None else frames
 assert len(frames)==s['ply']+1 and frames[-1]['game']==s['game']
 variants=[]
 for t in ts:
  i,q,r=t;events=[]
  for f in frames[1:]:
   m=f['last_move']
   if m is None:events.append(None);continue
   def xy(v):
    if v is None:return None
    x,y=transform(*v,i);return [x-q,y-r]
   events.append([m['piece'],xy(m.get('from')),xy(m['to']),m.get('actor')])
  raw=json.dumps(events,separators=(',',':'));variants.append((raw,t))
 raw=min(v[0] for v in variants)
 return key+'|history:'+hashlib.sha256(raw.encode()).hexdigest(),[t for v,t in variants if v==raw]
def lookup(game,book,rng=None,cache=None):
 if len(game.split(';')[3:])>=book['max_plies']:return None
 import random
 rng=random if rng is None else rng;s=snapshot(game)
 if s['state'] not in ('NotStarted','InProgress') or s['ply']>=book['max_plies']:return None
 if s['ply']>=16:
  shallow,_=shallow_canonical(s)
  if shallow not in book['deep_position_keys']:return None
 key,t=canonical(s);e=book['entries'].get(key)
 if not e:return None
 legal={}
 for m in s['legal']:
  if s['ply']<2 and m['piece'] in ('wQ','bQ'):continue
  legal.setdefault(action_key(m,t),m['move'])
 choices=[c for c in e['choices'] if c['action'] in legal]
 if not choices:return None
 if cache is not None and game in cache:return legal.get(cache[game])
 ticket=rng.randrange(sum(c['weight'] for c in choices))
 for c in choices:
  ticket-=c['weight']
  if ticket<0:
   if cache is not None:cache[game]=c['action']
   return legal[c['action']]
 raise AssertionError('Invalid book weights')

def available_moves(game,book):
 """All legal repertoire choices, without drawing or changing the play cache."""
 if len(game.split(';')[3:])>=book['max_plies']:return []
 s=snapshot(game)
 if s['state'] not in ('NotStarted','InProgress') or s['ply']>=book['max_plies']:return []
 if s['ply']>=16:
  shallow,_=shallow_canonical(s)
  if shallow not in book['deep_position_keys']:return []
 key,ts=canonical(s);entry=book['entries'].get(key)
 if not entry:return []
 actions={c['action'] for c in entry['choices']}
 return list(dict.fromkeys(m['move'] for m in s['legal']
  if not (s['ply']<2 and m['piece'] in ('wQ','bQ')) and action_key(m,ts) in actions))
