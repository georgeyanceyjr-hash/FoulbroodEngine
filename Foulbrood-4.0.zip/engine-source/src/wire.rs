//! Source-versioned, bounded, typed research-state transport. Never UHP replay.
use crate::{Bug, Color, Hex, HiveMove, Piece};

pub(crate) const LIMIT: usize = 64 * 1024 * 1024;
pub(crate) struct Writer { pub bytes: Vec<u8> }
impl Writer {
    pub fn new() -> Self { Self { bytes: Vec::new() } }
    pub fn byte(&mut self, n:u8) { self.bytes.push(n); }
    pub fn u16(&mut self,n:u16) { self.bytes.extend_from_slice(&n.to_le_bytes()); }
    pub fn u32(&mut self,n:u32) { self.bytes.extend_from_slice(&n.to_le_bytes()); }
    pub fn u64(&mut self,n:u64) { self.bytes.extend_from_slice(&n.to_le_bytes()); }
    pub fn i32(&mut self,n:i32) { self.bytes.extend_from_slice(&n.to_le_bytes()); }
    pub fn flag(&mut self,n:bool) { self.byte(u8::from(n)); }
    pub fn text(&mut self,s:&str) { self.u32(s.len() as u32);self.bytes.extend_from_slice(s.as_bytes()); }
    pub fn hex(&mut self,h:Hex) { self.u16(h.q as u16);self.u16(h.r as u16); }
    pub fn piece(&mut self,p:Piece) { self.byte(p.id() as u8); }
    pub fn mv(&mut self,m:HiveMove) {
        match m {
            HiveMove::Place{piece,to}=>{self.byte(0);self.piece(piece);self.hex(to);},
            HiveMove::Move{piece,from,to}=>{self.byte(1);self.piece(piece);self.hex(from);self.hex(to);},
            HiveMove::Pillbug{actor,piece,from,to}=>{self.byte(2);self.piece(actor);self.piece(piece);self.hex(from);self.hex(to);},
            HiveMove::Pass=>self.byte(3),
        }
    }
    pub fn optional_move(&mut self,m:Option<HiveMove>) { self.flag(m.is_some());if let Some(m)=m{self.mv(m);} }
    pub fn moves(&mut self,m:&[HiveMove]) { self.u32(m.len() as u32);for &m in m{self.mv(m);} }
    pub fn finish(self)->Result<Vec<u8>,String> {
        if self.bytes.len()>LIMIT{return Err("wire64MiB fixed envelope".into());}Ok(self.bytes)
    }
}

pub(crate) struct Reader<'a> { bytes:&'a[u8], index:usize }
impl<'a> Reader<'a> {
    pub fn new(bytes:&'a[u8])->Result<Self,String> {
        if bytes.len()>LIMIT{return Err("wire64MiB fixed envelope".into());}Ok(Self{bytes,index:0})
    }
    pub fn take(&mut self,n:usize)->Result<&'a[u8],String> {
        let end=self.index.checked_add(n).ok_or("wire offset overflow")?;
        let raw=self.bytes.get(self.index..end).ok_or("truncated typed wire")?;
        self.index=end;Ok(raw)
    }
    pub fn byte(&mut self)->Result<u8,String>{Ok(self.take(1)?[0])}
    pub fn u16(&mut self)->Result<u16,String>{Ok(u16::from_le_bytes(self.take(2)?.try_into().unwrap()))}
    pub fn u32(&mut self)->Result<u32,String>{Ok(u32::from_le_bytes(self.take(4)?.try_into().unwrap()))}
    pub fn u64(&mut self)->Result<u64,String>{Ok(u64::from_le_bytes(self.take(8)?.try_into().unwrap()))}
    pub fn i32(&mut self)->Result<i32,String>{Ok(i32::from_le_bytes(self.take(4)?.try_into().unwrap()))}
    pub fn flag(&mut self)->Result<bool,String> {
        match self.byte()?{0=>Ok(false),1=>Ok(true),_=>Err("invalid typed option/bool tag".into())}
    }
    pub fn count(&mut self,max:usize)->Result<usize,String> {
        let n=self.u32()? as usize;if n>max{return Err("wire count ceiling".into());}Ok(n)
    }
    pub fn text(&mut self,max:usize)->Result<String,String> {
        let n=self.count(max)?;String::from_utf8(self.take(n)?.to_vec()).map_err(|e|e.to_string())
    }
    pub fn hex(&mut self)->Result<Hex,String>{Ok(Hex::new(self.u16()? as i16,self.u16()? as i16))}
    pub fn piece(&mut self)->Result<Piece,String> {
        let id=usize::from(self.byte()?);
        for color in Color::ALL {for bug in Bug::ALL {for number in 1..=bug.copies(){
            let p=Piece::new(color,bug,number);if p.id()==id{return Ok(p);}
        }}}
        Err("invalid typed piece ID".into())
    }
    pub fn mv(&mut self)->Result<HiveMove,String> {
        Ok(match self.byte()?{
            0=>HiveMove::Place{piece:self.piece()?,to:self.hex()?},
            1=>HiveMove::Move{piece:self.piece()?,from:self.hex()?,to:self.hex()?},
            2=>HiveMove::Pillbug{actor:self.piece()?,piece:self.piece()?,from:self.hex()?,to:self.hex()?},
            3=>HiveMove::Pass,
            _=>return Err("invalid typed move kind".into()),
        })
    }
    pub fn optional_move(&mut self)->Result<Option<HiveMove>,String> {if self.flag()?{Ok(Some(self.mv()?))}else{Ok(None)}}
    pub fn moves(&mut self,max:usize)->Result<Vec<HiveMove>,String> {
        let n=self.count(max)?;let mut out=Vec::with_capacity(n);for _ in 0..n{out.push(self.mv()?);}Ok(out)
    }
    pub fn finish(self)->Result<(),String> {
        if self.index!=self.bytes.len(){return Err("trailing typed wire bytes".into());}Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn raw_pillbug_and_mosquito_actors_never_collapse_to_same_effect() {
        let a=Piece::new(Color::Black,Bug::Ant,1);let p=Piece::new(Color::White,Bug::Pillbug,1);
        let m=Piece::new(Color::White,Bug::Mosquito,1);
        let moves=[HiveMove::Pillbug{actor:p,piece:a,from:Hex::new(-2,3),to:Hex::new(-1,2)},
            HiveMove::Pillbug{actor:m,piece:a,from:Hex::new(-2,3),to:Hex::new(-1,2)},
            HiveMove::Move{piece:a,from:Hex::new(-2,3),to:Hex::new(-1,2)},HiveMove::Pass];
        let mut w=Writer::new();w.moves(&moves);let raw=w.finish().unwrap();
        let mut r=Reader::new(&raw).unwrap();assert_eq!(r.moves(4).unwrap(),moves);r.finish().unwrap();
        let mut first=Writer::new();first.mv(moves[0]);let mut second=Writer::new();second.mv(moves[1]);
        assert_ne!(first.finish().unwrap(),second.finish().unwrap());
    }
    #[test]
    fn typed_wire_rejects_bad_tags_counts_truncation_and_trailing_bytes() {
        assert!(Reader::new(&[2]).unwrap().flag().is_err());
        assert!(Reader::new(&[9]).unwrap().mv().is_err());
        assert!(Reader::new(&[255]).unwrap().piece().is_err());
        assert!(Reader::new(&[1,0,0]).unwrap().count(3).is_err());
        assert!(Reader::new(&[4,0,0,0]).unwrap().moves(3).is_err());
        assert!(Reader::new(&[3]).unwrap().finish().is_err());
    }
}
