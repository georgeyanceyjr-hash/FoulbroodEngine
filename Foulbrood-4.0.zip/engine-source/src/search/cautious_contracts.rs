//! Independent evaluation contracts on synthetic snapshots and a previously
//! qualified public typed fixture. No private game or claimed winning defense.
use super::*;
use crate::{GameType, Hex, UhpGame};
type Entry = (Piece, Hex, usize);
fn p(c: Color, b: Bug, n: u8) -> Piece { Piece::new(c,b,n) }
fn enabled() -> bool { matches!(option_env!("FOULBROOD_CAUTIOUS_STYLE"),Some("pin_develop_v1"|"pin_pressure_v2")) }
fn signed(b:&Board,white:i32)->i32 {if b.side_to_move()==Color::White{white}else{-white}}
fn setup(ty:GameType,side:Color,rows:&[Entry])->Board {
    Board::from_setup(ty,side,20,rows,None).unwrap()
}
fn rows(b:&Board)->Vec<Entry> {
    b.occupied_stacks().flat_map(|(h,s)|s.iter().copied().enumerate()
        .map(move |(z,x)|(x,h,z))).collect()
}
// Inventory/location and independent cube-coordinate distance, not stack_value
// or the production cached delta/distance helper.
fn reference_proximity(b:&Board)->[i32;2] {
    Color::ALL.map(|c| {
        let Some(q)=b.location(p(c.other(),Bug::Queen,1))else{return 0;};
        Piece::all_for(c,b.game_type()).into_iter().filter(|x|x.bug!=Bug::Queen)
            .map(|x|b.location(x).map_or(0,|h|{
                let dq=i32::from(h.q)-i32::from(q.q);let dr=i32::from(h.r)-i32::from(q.r);
                3*(6-dq.abs().max(dr.abs()).max((dq+dr).abs()).min(6))
            })).sum()
    })
}
fn reference_piece_total(b:&Board,cautious:bool)->i32 {
    let values=Color::ALL.map(|c| {
        let mut v=0;
        for x in Piece::all_for(c,b.game_type()) {
            let Some(h)=b.location(x)else{continue;};v+=12;
            if b.top(h)!=Some(x){v-=15;}
            if b.top(h)==Some(x)&&b.stack_height(h)>1&&matches!(x.bug,Bug::Beetle|Bug::Mosquito){v+=12;}
        }
        if !cautious {v+=reference_proximity(b)[c.index()];}
        v
    });
    values[Color::White.index()]-values[Color::Black.index()]
}
fn reference_cheap(b:&Board,cautious:bool)->i32 {
    let mut white=reference_piece_total(b,cautious);
    for c in Color::ALL {
        let mut v=pillbug_queen_readiness(b,c);
        if let Some(h)=b.location(p(c,Bug::Queen,1)) {
            let ring=h.neighbors().iter().filter(|&&n|b.is_occupied(n)).count();
            v-=[0,20,55,110,220,450,0][ring];
            if b.top(h)!=Some(p(c,Bug::Queen,1)){v-=80;}
        }
        white+=if c==Color::White{v}else{-v};
    }
    signed(b,white)
}
fn reference_strategy(b:&Board,cautious:bool)->i32 {
    let mode=option_env!("FOULBROOD_STRATEGY").unwrap_or("defense");
    let mut white=if matches!(mode,"defense"|"all") {
        functional_defense(b,Color::White)-functional_defense(b,Color::Black)
    }else{0};
    if matches!(mode,"control"|"access"|"beetle"|"all") {
        let value=|c| {
            // Full legal-feature extractor is an existing independently checked
            // oracle for the optimized movement::groundwork_resources path.
            let f=crate::groundwork::features(b,c);
            (if matches!(mode,"control"|"all"){crate::groundwork::control(&f)}else{0})
            +(if matches!(mode,"access"|"all"){crate::groundwork::access(&f)}else{0})
            +(if matches!(mode,"beetle"|"all") {
                (if cautious{0}else{20})*i32::from(f.queen_cover)
                    +24*i32::from(f.pillbug_cover)+20*i32::from(f.queen_recovery)
            }else{0})
        };
        white+=value(Color::White)-value(Color::Black);
    }
    if development_balance_enabled(){white+=super::development_balance_contracts::reference_balance(b);}
    white
}
pub(super) fn reference_leaf(b:&Board,ply:u8,cautious:bool)->i32 {
    let surrounded=Color::ALL.map(|c|b.location(p(c,Bug::Queen,1))
        .is_some_and(|h|h.neighbors().iter().all(|&n|b.is_occupied(n))));
    match(surrounded[b.side_to_move().index()],surrounded[b.side_to_move().other().index()]) {
        (true,true)=>0,(true,false)=>-100_000+i32::from(ply),(false,true)=>100_000-i32::from(ply),
        _=>reference_cheap(b,cautious)+signed(b,reference_strategy(b,cautious)
            +super::pin_pressure_contracts::reference_pressure_balance(b)),
    }
}
fn actual(b:&Board,ply:u8)->i32 {
    evaluate_windowed_leaf(b,piece_total(b),ply,queen_counts(b),-WIN-1,WIN+1)
}
fn distance_board(ty:GameType,side:Color,d:i16)->Board {
    let mut v=vec![(p(Color::White,Bug::Queen,1),Hex::new(0,1),0),
        (p(Color::Black,Bug::Queen,1),Hex::new(d,0),0),
        (p(Color::White,Bug::Ant,1),Hex::new(0,0),0)];
    let fillers=[p(Color::White,Bug::Grasshopper,1),p(Color::White,Bug::Grasshopper,2),
        p(Color::White,Bug::Grasshopper,3),p(Color::White,Bug::Spider,1),
        p(Color::White,Bug::Spider,2),p(Color::White,Bug::Ant,2)];
    for x in 1..d {v.push((fillers[(x-1)as usize],Hex::new(x,0),0));}
    setup(ty,side,&v)
}
pub(super) fn cover_board(side:Color)->Board {
    setup(GameType::mlp(),side,&[(p(Color::White,Bug::Queen,1),Hex::new(-1,0),0),
        (p(Color::Black,Bug::Queen,1),Hex::new(0,0),0),
        (p(Color::White,Bug::Beetle,1),Hex::new(0,0),1)])
}
fn pin_board(side:Color)->Board {
    setup(GameType::mlp(),side,&[(p(Color::White,Bug::Queen,1),Hex::new(-1,0),0),
        (p(Color::White,Bug::Ant,1),Hex::new(0,0),0),
        (p(Color::Black,Bug::Queen,1),Hex::new(1,0),0)])
}
pub(super) fn mate_board(side:Color,mover:Color)->Board {
    // Existing independent synthetic immediate-win/forced-pass control.
    setup(GameType::base(),side,&[(p(mover.other(),Bug::Queen,1),Hex::new(0,0),0),
        (p(mover,Bug::Queen,1),Hex::new(-2,0),0),
        (p(mover,Bug::Beetle,1),Hex::new(1,-1),0),
        (p(mover,Bug::Spider,1),Hex::new(0,-1),0),
        (p(mover,Bug::Spider,2),Hex::new(-1,0),0),
        (p(mover,Bug::Grasshopper,1),Hex::new(-1,1),0),
        (p(mover,Bug::Grasshopper,2),Hex::new(0,1),0),
        (p(mover,Bug::Ant,1),Hex::new(2,-1),0)])
}
fn transformed(b:&Board,swap:bool,rotation:u8,mirror:bool)->Board {
    let v:Vec<_>=rows(b).into_iter().map(|(x,h,z)| {
        let(mut q,mut r)=(h.q,h.r);if mirror{std::mem::swap(&mut q,&mut r);}
        for _ in 0..rotation{(q,r)=(-r,q+r);}
        (p(if swap{x.color.other()}else{x.color},x.bug,x.number),Hex::new(q+11,r-9),z)
    }).collect();setup(b.game_type(),if swap{b.side_to_move().other()}else{b.side_to_move()},&v)
}
#[test]
fn cautious_compile_gate_off_and_invalid_labels_are_explicit() {
    assert_eq!(checked_cautious_style_label(None),"off");assert_eq!(checked_cautious_style_label(Some("off")),"off");
    assert_eq!(checked_cautious_style_label(Some("pin_develop_v1")),"pin_develop_v1");
    for x in["","cautious","pin_develop_v2","PIN_DEVELOP_V1"] {
        assert!(std::panic::catch_unwind(||checked_cautious_style_label(Some(x))).is_err());
    }
    assert_eq!(cautious_style_label(),match option_env!("FOULBROOD_CAUTIOUS_STYLE"){Some("pin_develop_v1")=>"pin_develop_v1",Some("pin_pressure_v2")=>"pin_pressure_v2",_=>"off"});
    assert_eq!(proximity_weight(),if enabled(){0}else{3});
}
#[test]
fn all_variant_approach_and_cover_components_match_independent_formula() {
    for flags in 0..8 {for side in Color::ALL {for d in 1..=7 {
        let ty=GameType{mosquito:flags&1!=0,ladybug:flags&2!=0,pillbug:flags&4!=0};let b=distance_board(ty,side,d);
        let before=Position::new(&b);assert_eq!(evaluate_ordering(&b),reference_cheap(&b,enabled()));
        assert_eq!(actual(&b,3),reference_leaf(&b,3,enabled()));
        let removed=reference_proximity(&b);assert!(removed.iter().all(|x|(0..=234).contains(x)));
        assert!((reference_leaf(&b,3,true)-reference_leaf(&b,3,false)).abs()<=254);
        assert_eq!(Position::new(&b),before);
    }}}
    for flags in 0..8 {
        let ty=GameType{mosquito:flags&1!=0,ladybug:flags&2!=0,pillbug:flags&4!=0};
        let empty=Board::new(ty);assert_eq!(reference_proximity(&empty),[0,0]);assert_eq!(actual(&empty,0),0);
        let queens=setup(ty,Color::White,&[(p(Color::White,Bug::Queen,1),Hex::new(0,0),0),(p(Color::Black,Bug::Queen,1),Hex::new(1,0),0)]);
        let locations=Color::ALL.map(|c|queens.location(p(c,Bug::Queen,1)));
        for c in Color::ALL {let q=p(c,Bug::Queen,1);let h=queens.location(q).unwrap();assert_eq!(stack_value(&queens,h,&[q],&locations),if c==Color::White{12}else{-12});}
    }
    for mask in 0..8 {
        let mut f=crate::groundwork::Features::default();f.queen_cover=mask&1!=0;f.pillbug_cover=mask&2!=0;f.queen_recovery=mask&4!=0;
        assert_eq!(beetle_strategy_value(&f),(if enabled(){0}else{20})*i32::from(f.queen_cover)+24*i32::from(f.pillbug_cover)+20*i32::from(f.queen_recovery));
    }
}
#[test]
fn actual_queen_danger_recovery_and_support_keep_full_strength() {
    assert_eq!((PILLBUG_SUPPORT,PILLBUG_TWO_WINDOWS,PILLBUG_ONE_WINDOW),(69,12,5));
    let mut f=crate::groundwork::Features::default();f.pillbug_cover=true;f.queen_recovery=true;
    assert_eq!(beetle_strategy_value(&f),44);
    for side in Color::ALL {
        let b=cover_board(side);let counts=queen_counts(&b);
        let safety=evaluate_counted_base(&b,piece_total(&b),0,counts)-signed(&b,piece_total(&b)+pillbug_readiness_balance(&b));
        let independent=Color::ALL.into_iter().map(|c| {
            let q=p(c,Bug::Queen,1);let h=b.location(q).unwrap();let n=h.neighbors().iter().filter(|&&x|b.is_occupied(x)).count();
            let damage=[0,20,55,110,220,450,0][n]+if b.top(h)!=Some(q){80}else{0};if c==Color::White{-damage}else{damage}
        }).sum();assert_eq!(safety,signed(&b,independent));
        assert_eq!(actual(&b,0),reference_leaf(&b,0,enabled()));
    }
}
#[test]
fn pin_and_deployment_marginals_outweigh_removed_optional_attack_credit() {
    let(d,pin)=development_coefficients();assert!(d>0&&pin>0);
    assert_eq!(development_benefit(1,0),d);assert_eq!(development_benefit(0,1),pin);
    if development_weights_label()=="deployment_higher"{assert_eq!((d,pin),(10,12));}
    assert_eq!(development_benefit(13,13),if option_env!("FOULBROOD_CAUTIOUS_STYLE")==Some("pin_pressure_v2")&&development_weights_label()=="deployment_higher"{284}else{128});
    if enabled(){assert_eq!(proximity_weight()*6,0);let mut f=crate::groundwork::Features::default();f.queen_cover=true;assert_eq!(beetle_strategy_value(&f),0);}
    for side in Color::ALL {
        let b=pin_board(side);let independent=super::development_balance_contracts::reference_balance(&b);
        assert_eq!(development_balance(&b),if development_balance_enabled(){independent}else{0});
    }
    // This compares isolated optional components, not every actual Queen danger
    // or a universal forced tactical/playing-strength preference.
}
#[test]
fn cautious_cached_deltas_eager_values_and_lazy_windows_match_oracle() {
    let residual=match option_env!("FOULBROOD_STRATEGY").unwrap_or("defense") {"control"=>90,"access"|"beetle"=>64,"all"=>278,_=>60}
        +if development_balance_enabled(){if option_env!("FOULBROOD_CAUTIOUS_STYLE")==Some("pin_pressure_v2")&&development_weights_label()=="deployment_higher"{284}else{128}}else{0};assert_eq!(strategy_bound(),residual);
    let mut queen_seen=false;
    for mut b in[distance_board(GameType::mlp(),Color::White,2),cover_board(Color::Black),pin_board(Color::White),mate_board(Color::White,Color::White)] {
        let before=Position::new(&b);let legal=b.legal_moves_all_actors();let total=piece_total(&b);let queens=Color::ALL.map(|c|b.location(p(c,Bug::Queen,1)));
        assert_eq!(evaluate_ordering(&b),reference_cheap(&b,enabled()));
        let mut samples:Vec<_>=legal.iter().step_by((legal.len()/12).max(1)).take(12).copied().collect();
        if let Some(mv)=legal.iter().copied().find(|mv|queen_moved(*mv)) {if !samples.contains(&mv){samples.push(mv);}}
        for mv in samples {
            let delta=piece_move_delta(&b,mv,&queens);let q=queen_moved(mv);let u=b.make_generated(mv);
            queen_seen|=q;
            let cached=if q{piece_total(&b)}else{total+delta};
            assert_eq!(cached,reference_piece_total(&b,enabled()));
            assert_eq!(piece_total(&b),reference_piece_total(&b,enabled()));
            let exact=reference_leaf(&b,2,enabled());assert_eq!(actual(&b,2),exact);assert!(functional_defense_balance(&b).abs()<=residual);
            for(a,z)in[(-WIN-1,WIN+1),(exact-1,exact),(exact,exact+1),(exact-1000,exact-999),(exact+999,exact+1000)] {
                let x=evaluate_windowed_leaf(&b,piece_total(&b),2,queen_counts(&b),a,z);
                if x<=a{assert!(exact<=x);}else if x>=z{assert!(exact>=x);}else{assert_eq!(x,exact);}
            }
            b.undo_generated(u);assert_eq!(Position::new(&b),before);
        }
    }
    assert!(queen_seen,"A real generated Queen move exercises the full-recompute branch");
}
#[test]
fn cautious_geometric_color_symmetry_and_queries_do_not_mutate_state() {
    let b=cover_board(Color::White);let before=format!("{b:?}");let legal=b.legal_moves_all_actors();let exact=actual(&b,1);
    for swap in[false,true]{for mirror in[false,true]{for rotation in 0..6 {
        let other=transformed(&b,swap,rotation,mirror);assert_eq!(actual(&other,1),exact);
        assert_eq!(actual(&other,1),reference_leaf(&other,1,enabled()));
    }}}
    assert_eq!(format!("{b:?}"),before);assert_eq!(b.legal_moves_all_actors(),legal);
}
#[test]
fn nonzero_attack_features_never_override_mate_or_forced_countermate() {
    for mover in Color::ALL {
        let b=mate_board(mover,mover);assert!(reference_proximity(&b)[mover.index()]>0);
        let before=format!("{b:?}");let result=search(&b,SearchLimit::Depth(1));assert_eq!(result.score,Some(99_999));
        let mut won=b.clone();won.make_generated(result.best_move.unwrap());assert!(won.queen_surrounded(mover.other()));
        for ply in[0,1,23,64]{assert_eq!(actual(&won,ply),-100_000+i32::from(ply));}
        let forced=mate_board(mover.other(),mover);assert_eq!(forced.legal_moves(),vec![HiveMove::Pass]);
        let reply=search(&forced,SearchLimit::Depth(2));assert_eq!(reply.best_move,Some(HiveMove::Pass));assert_eq!(reply.score,Some(-99_998));
        assert_eq!(format!("{b:?}"),before);
    }
}
#[test]
fn cautious_typed_actor_history_513_and_make_undo_restore_exact_source() {
    fn checkpoint(game: &mut UhpGame, engine: &mut crate::UhpEngine) {
        let state=game.raw_state_json();let history=game.exact_position_history().to_vec();
        let legal=game.board().legal_moves_all_actors();
        assert_eq!(engine.execute("state_raw"),vec![state.clone()]);
        assert_eq!(actual(game.board(),0),reference_leaf(game.board(),0,enabled()));
        let _=search_with_history(game.board(),SearchLimit::Depth(1),&history);
        assert_eq!(game.raw_state_json(),state);
        for mv in legal.iter().copied().take(3) {
            let mut expected=game.clone();expected.play_raw_all_actors(mv).unwrap();
            let fields=crate::uhp::raw_move_fields(mv);
            let probe=engine.execute(&format!("probe_raw_all_actors {fields}"));
            assert_eq!(probe.len(),1);
            assert!(probe[0].contains("\"membership_domain\":\"all_legal_actor_aliases_v1\""));
            assert!(probe[0].contains(&format!("\"raw_move\":{}",crate::search::residual::raw_action_json(mv))));
            assert!(probe[0].contains(&format!("\"state\":{}",expected.raw_state_json())));
            assert_eq!(engine.execute("state_raw"),vec![state.clone()]);
            game.play_raw_all_actors(mv).unwrap();assert_eq!(game.history().last(),Some(&mv));
            assert_eq!(game.raw_state_json(),expected.raw_state_json());
            let committed=engine.execute(&format!("play_raw_all_actors {fields}"));
            assert_eq!(committed.len(),1);assert!(committed[0].contains(&format!("\"state\":{}",expected.raw_state_json())));
            game.undo(1).unwrap();let _=engine.execute("undo 1");
            assert_eq!(engine.execute("state_raw"),vec![state.clone()]);
            assert_eq!(game.raw_state_json(),state);assert_eq!(game.exact_position_history(),history.as_slice());
        }
        assert_eq!(game.board().legal_moves_all_actors(),legal);
    }
    let mut game=UhpGame::new(GameType::mlp());let mut engine=crate::UhpEngine::default();
    let _=engine.execute("newgame Base+MLP");
    let source=include_str!("../../tests/long_game_raw_history.txt");
    assert_eq!(source.lines().count(),510,"Frozen qualified source prefix length");
    for(i,line)in source.lines().enumerate() {
        let mv=crate::uhp::raw_move_from_fields(line).unwrap();
        game.play_raw_all_actors(mv).unwrap();
        let committed=engine.execute(&format!("play_raw_all_actors {}",crate::uhp::raw_move_fields(mv)));
        assert_eq!(committed.len(),1);assert!(!committed[0].starts_with("invalidmove "));
        assert_eq!(game.board().ply(),(i+1)as u16);
        if [255,256,510].contains(&(i+1)){checkpoint(&mut game,&mut engine);}
    }
    let prefix=game.history().to_vec();let state510=game.raw_state_json();
    for ply in [511_u16,512,513] {
        // As in the qualified counter contracts: choose only the first genuinely
        // legal nonterminal engineering extension. No evaluation/search/ranking
        // selects this whole actor, and no display/UHP actor is reconstructed.
        let(mv,expected)=game.board().legal_moves_all_actors().into_iter().find_map(|mv| {
            let mut child=game.clone();child.play_raw_all_actors(mv).unwrap();
            (child.state()==crate::GameState::InProgress).then_some((mv,child))
        }).expect("Qualified510 prefix has a genuine nonterminal counter extension");
        game.play_raw_all_actors(mv).unwrap();
        let committed=engine.execute(&format!("play_raw_all_actors {}",crate::uhp::raw_move_fields(mv)));
        assert_eq!(committed.len(),1);assert!(committed[0].contains(&format!("\"state\":{}",expected.raw_state_json())));
        assert_eq!(game.raw_state_json(),expected.raw_state_json());assert_eq!(game.board().ply(),ply);
        assert_eq!(game.history().len(),usize::from(ply));assert_eq!(&game.history()[..510],prefix.as_slice());
        assert_eq!(game.exact_position_history().len(),usize::from(ply)+1);
        assert_eq!(game.board().turns_taken(Color::White),(ply+1)/2);
        assert_eq!(game.board().turns_taken(Color::Black),ply/2);
        checkpoint(&mut game,&mut engine);
    }
    game.undo(3).unwrap();let _=engine.execute("undo 3");
    assert_eq!(game.raw_state_json(),state510);assert_eq!(engine.execute("state_raw"),vec![state510]);
}
#[test]
#[ignore="bounded external owner explicitly runs synthetic/public diagnostic"]
fn cautious_diagnostic() {
    let cases=vec![("approach_near",distance_board(GameType::mlp(),Color::White,2)),
        ("approach_far",distance_board(GameType::mlp(),Color::White,7)),("actual_queen_cover",cover_board(Color::White)),
        ("ground_pin",pin_board(Color::White)),("immediate_mate",mate_board(Color::White,Color::White)),
        ("forced_countermate",mate_board(Color::Black,Color::White))];
    let mut cases:Vec<_>=cases.into_iter().map(|(name,b)| {let history=vec![Position::new(&b)];(name,b,history)}).collect();
    for count in[11,13] {
        let mut game=UhpGame::new(GameType::mlp());
        for line in include_str!("../../tests/cautious_public_pin_reply.raw").lines().take(count){game.play_raw(crate::uhp::raw_move_from_fields(line).unwrap()).unwrap();}
        cases.push((if count==11{"public_before_pin"}else{"public_after_pin_reply"},game.board().clone(),game.exact_position_history().to_vec()));
    }
    for(name,b,history)in cases {
        println!("CAUTIOUS_CASE name={name} label={} proximity={:?} off_leaf={} mode_leaf={}",cautious_style_label(),reference_proximity(&b),reference_leaf(&b,0,false),actual(&b,0));
        for depth in[3,4] {let result=search_with_history(&b,SearchLimit::Depth(depth),&history);println!("CAUTIOUS_SEARCH name={name} depth={depth} completed={} score={:?} raw_action={:?} nodes={} elapsed_ns={}",result.completed_depth,result.score,result.best_move,result.nodes,result.elapsed.as_nanos());}
    }
}
