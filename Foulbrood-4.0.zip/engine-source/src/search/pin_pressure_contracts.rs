//! Independent whole-actor/make-undo oracle and fixed synthetic/public controls.
//! Off-turn oracle pass exists ONLY in tests, labels potential, never a source
//! history or production prediction. No private game/fit/strength claim.
use super::*;
use crate::{GameType,Hex,UhpGame};
use crate::movement::{ring_pressure_access,RingAccess};
type Entry=(Piece,Hex,usize);
fn p(c:Color,b:Bug,n:u8)->Piece {Piece::new(c,b,n)}
fn enabled()->bool {option_env!("FOULBROOD_CAUTIOUS_STYLE")==Some("pin_pressure_v2")}
fn setup(ty:GameType,side:Color,rows:&[Entry])->Board {Board::from_setup(ty,side,20,rows,None).unwrap()}
fn rows(b:&Board)->Vec<Entry> {b.occupied_stacks().flat_map(|(h,s)|s.iter().copied().enumerate().map(move|(z,p)|(p,h,z))).collect()}
fn ring(b:&Board,q:Hex)->usize {q.neighbors().iter().filter(|&&h|b.is_occupied(h)).count()}
fn oracle_turn(b:&Board,color:Color)->Board {
    let mut turn=b.clone();
    if turn.side_to_move()!=color {turn.make_generated(HiveMove::Pass);}
    turn
}
fn oracle_moves(b:&Board,color:Color)->Vec<HiveMove> {
    let target_piece=p(color.other(),Bug::Queen,1);let Some(q)=b.location(target_piece)else{return vec![];};
    let before=ring(b,q);let mut turn=oracle_turn(b,color);let original=Position::new(&turn);
    let mut found=Vec::new();
    for mv in turn.legal_moves_all_actors() {
        let piece=match mv {HiveMove::Place{piece,..}|HiveMove::Move{piece,..}|HiveMove::Pillbug{piece,..}=>piece,HiveMove::Pass=>continue};
        if piece==target_piece{continue;}
        let u=turn.make_generated(mv);
        if turn.location(target_piece)==Some(q)&&ring(&turn,q)==before+1{found.push(mv);}
        turn.undo_generated(u);assert_eq!(Position::new(&turn),original);
    }
    found
}
fn check_access(b:&Board,color:Color) {
    let state=format!("{b:?}");let expected=oracle_moves(b,color);let got=ring_pressure_access(b,color);
    assert_eq!(got.potential_only,b.side_to_move()!=color);
    match got.status {
        RingAccess::Found(mv)=>assert!(expected.contains(&mv),"{mv:?} not in independent wholeactor oracle"),
        RingAccess::None=>assert!(expected.is_empty(),"false absence: {expected:?}"),
        RingAccess::Unknown=>{}, // Explicit conservative no-discount, not false absence.
    }
    assert_eq!(format!("{b:?}"),state);
}
pub(super) fn reference_pressure_balance(b:&Board)->i32 {
    if !enabled()||b.game_over(){return 0;}
    let mut white=0;
    for target in Color::ALL {
        let Some(q)=b.location(p(target,Bug::Queen,1))else{continue;};let n=ring(b,q);
        if (2..=5).contains(&n)&&oracle_moves(b,target.other()).is_empty() {
            let drop=[0,20,55,110,220,450][n]-20;
            white+=if target==Color::White{drop}else{-drop};
        }
    }
    white
}
fn exact(b:&Board,ply:u8)->i32 {evaluate_windowed_leaf(b,piece_total(b),ply,queen_counts(b),-WIN-1,WIN+1)}
fn reference(b:&Board,ply:u8)->i32 {super::cautious_contracts::reference_leaf(b,ply,cautious_style_label()!="off")}
fn dense(side:Color,supported:bool)->Board {
    let w=Color::White;let b=Color::Black;
    let mut v=vec![(p(b,Bug::Queen,1),Hex::new(0,0),0),(p(w,Bug::Queen,1),Hex::new(-2,0),0),
        (p(w,Bug::Ant,1),Hex::new(-1,0),0),(p(w,Bug::Spider,1),Hex::new(-1,1),0),
        (p(w,Bug::Spider,2),Hex::new(0,1),0),(p(w,Bug::Grasshopper,1),Hex::new(1,0),0)];
    if supported{v.push((p(w,Bug::Ant,2),Hex::new(2,-1),0));}
    setup(GameType::mlp(),side,&v)
}
fn donor(side:Color,enemy_donor:bool,stunned:bool)->Board {
    let w=Color::White;let b=Color::Black;
    let mut v=vec![(p(b,Bug::Queen,1),Hex::new(0,0),0),(p(w,Bug::Queen,1),Hex::new(-2,0),0),
        (p(w,Bug::Ant,1),Hex::new(-1,0),0),(p(w,Bug::Spider,1),Hex::new(0,1),0),
        (p(w,Bug::Pillbug,1),Hex::new(1,0),0)];
    if enemy_donor{v.push((p(b,Bug::Ant,1),Hex::new(2,0),0));}
    Board::from_setup(GameType::mlp(),side,20,&v,stunned.then_some((p(w,Bug::Pillbug,1),Hex::new(3,0)))).unwrap()
}
fn own_queen(side:Color)->Board {
    let w=Color::White;let b=Color::Black;
    setup(GameType::mlp(),side,&[(p(b,Bug::Queen,1),Hex::new(0,0),0),
        (p(w,Bug::Queen,1),Hex::new(-2,0),0),(p(w,Bug::Spider,1),Hex::new(-2,1),0),
        (p(w,Bug::Grasshopper,1),Hex::new(-1,1),0),(p(w,Bug::Spider,2),Hex::new(0,1),0)])
}
fn transformed(b:&Board,swap:bool,rotation:u8,mirror:bool)->Board {
    let v:Vec<_>=rows(b).into_iter().map(|(x,h,z)|{
        let(mut q,mut r)=(h.q,h.r);if mirror{std::mem::swap(&mut q,&mut r);}for _ in 0..rotation{(q,r)=(-r,q+r);}
        (p(if swap{x.color.other()}else{x.color},x.bug,x.number),Hex::new(q+8,r-7),z)
    }).collect();setup(b.game_type(),if swap{b.side_to_move().other()}else{b.side_to_move()},&v)
}
fn mate(side:Color,mover:Color)->Board {
    let mut b=super::cautious_contracts::mate_board(side,mover);
    let mut v=rows(&b);v.push((p(mover,Bug::Ant,2),Hex::new(-2,1),0));
    b=setup(GameType::base(),side,&v);b
}
fn all_deployed()->Board {
    let v:Vec<_>=Color::ALL.into_iter().flat_map(|c|Piece::all_for(c,GameType::mlp())).enumerate()
        .map(|(i,p)|(p,Hex::new(i as i16,0),0)).collect();setup(GameType::mlp(),Color::White,&v)
}
#[test]
fn style_gate_old_modes_and_new_fixed_formula_are_distinct() {
    assert_eq!(checked_cautious_style_label(None),"off");assert_eq!(checked_cautious_style_label(Some("off")),"off");
    assert_eq!(checked_cautious_style_label(Some("pin_develop_v1")),"pin_develop_v1");
    assert_eq!(checked_cautious_style_label(Some("pin_pressure_v2")),"pin_pressure_v2");
    for bad in["","PIN_PRESSURE_V2","pressure","pin_pressure_v3"]{assert!(std::panic::catch_unwind(||checked_cautious_style_label(Some(bad))).is_err());}
    assert_eq!(proximity_weight(),if cautious_style_label()=="off"{3}else{0});
    let mut f=crate::groundwork::Features::default();f.queen_cover=true;f.pillbug_cover=true;f.queen_recovery=true;
    assert_eq!(beetle_strategy_value(&f),if cautious_style_label()=="off"{64}else{44});
}
#[test]
fn targeted_ring_access_matches_independent_whole_actor_oracle() {
    for flags in 0..8 {
        let ty=GameType{mosquito:flags&1!=0,ladybug:flags&2!=0,pillbug:flags&4!=0};let mut b=Board::new(ty);
        for step in 0..48 {
            for c in Color::ALL{check_access(&b,c);}
            if b.game_over(){break;}
            let legal=b.legal_moves_all_actors();let mv=legal[(step*29+flags*7)%legal.len()];b.make_generated(mv);
        }
    }
    for b in[dense(Color::White,false),dense(Color::Black,true),donor(Color::White,true,false),own_queen(Color::White)] {
        for c in Color::ALL{check_access(&b,c);}
    }
}
#[test]
fn placements_and_queen_obligations_use_exact_existing_domain() {
    for flags in 0..8 {
        let ty=GameType{mosquito:flags&1!=0,ladybug:flags&2!=0,pillbug:flags&4!=0};let mut b=Board::new(ty);
        for step in 0..10 {
            let actual=b.legal_moves_all_actors();
            for c in Color::ALL {for bug in Bug::ALL {
                let Some(piece)=b.canonical_piece_in_hand(c,bug)else{continue;};
                for q in -2..=2{for r in -2..=2 {let to=Hex::new(q,r);let expected=oracle_turn(&b,c).legal_moves_all_actors().contains(&HiveMove::Place{piece,to});
                    assert_eq!(b.is_legal_placement_for_color(c,piece,to),expected);
                    if c==b.side_to_move(){assert_eq!(b.is_legal_placement_hint(piece,to),expected);}
                }}
            }}
            let mv=actual[step%actual.len()];b.make_generated(mv);if b.game_over(){break;}
        }
    }
}
#[test]
fn transported_enemy_donor_pinned_actor_and_target_queen_exclusion_are_exact() {
    let b=donor(Color::White,true,false);let expected=oracle_moves(&b,Color::White);
    assert!(expected.iter().any(|mv|matches!(mv,HiveMove::Pillbug{actor,piece,..}if actor.bug==Bug::Pillbug&&piece.color==Color::Black&&piece.bug==Bug::Ant)));
    assert!(matches!(ring_pressure_access(&b,Color::White).status,RingAccess::Found(HiveMove::Pillbug{piece,..})if piece.color==Color::Black));
    let no=donor(Color::White,false,false);assert!(oracle_moves(&no,Color::White).is_empty());assert_eq!(ring_pressure_access(&no,Color::White).status,RingAccess::None);
    let q=own_queen(Color::White);assert!(oracle_moves(&q,Color::White).iter().any(|mv|matches!(mv,HiveMove::Move{piece,..}if piece.bug==Bug::Queen)));
    assert!(matches!(ring_pressure_access(&q,Color::White).status,RingAccess::Found(HiveMove::Move{piece,..})if piece.bug==Bug::Queen));
}
#[test]
fn actual_stun_and_other_turn_potential_never_mutate_source() {
    let actual=donor(Color::White,true,true);let before=format!("{actual:?}");
    assert!(oracle_moves(&actual,Color::White).is_empty());assert_eq!(ring_pressure_access(&actual,Color::White).status,RingAccess::None);
    let potential=donor(Color::Black,true,true);let got=ring_pressure_access(&potential,Color::White);assert!(got.potential_only);assert!(matches!(got.status,RingAccess::Found(_)));
    check_access(&actual,Color::White);check_access(&potential,Color::White);assert_eq!(format!("{actual:?}"),before);
}
#[test]
fn ordinary_species_mosquito_topology_and_conservative_unknown_are_exact() {
    // Duplicate P/M actors remain distinct whole legal actions. The helper
    // may return either one, or a separate ordinary net fill; no alias rewrite.
    let w=Color::White;let black=Color::Black;
    let mut v=rows(&donor(w,true,false));
    v.retain(|(x,_,_)|*x!=p(w,Bug::Pillbug,1));
    v.push((p(w,Bug::Mosquito,1),Hex::new(1,0),0));
    v.push((p(w,Bug::Pillbug,1),Hex::new(2,-1),0));
    let duplicate=setup(GameType::mlp(),w,&v);let actions=oracle_moves(&duplicate,w);
    for bug in[Bug::Mosquito,Bug::Pillbug] {
        assert!(actions.iter().any(|m|matches!(m,HiveMove::Pillbug{actor,piece,to,..}
            if actor.bug==bug&&*piece==p(black,Bug::Ant,1)&&*to==Hex::new(1,-1))));
    }
    check_access(&duplicate,w);
    // An elevated M acts as a Beetle, and its lower piece keeps the old ring
    // source occupied, so this move really adds a ring cell.
    let elevated=setup(GameType::mlp(),w,&[
        (p(black,Bug::Queen,1),Hex::new(0,0),0),(p(w,Bug::Queen,1),Hex::new(-2,0),0),
        (p(w,Bug::Ant,1),Hex::new(-1,0),0),(p(w,Bug::Spider,1),Hex::new(1,0),0),
        (p(w,Bug::Mosquito,1),Hex::new(1,0),1)]);
    assert!(oracle_moves(&elevated,w).contains(&HiveMove::Move{piece:p(w,Bug::Mosquito,1),from:Hex::new(1,0),to:Hex::new(1,-1)}));
    check_access(&elevated,w);
    // Legal ordinary ring-to-ring movement is net zero and is NOT pressure.
    let zero=setup(GameType::base(),w,&[
        (p(black,Bug::Queen,1),Hex::new(0,0),0),(p(w,Bug::Queen,1),Hex::new(-2,1),0),
        (p(w,Bug::Beetle,1),Hex::new(-1,0),0),(p(w,Bug::Spider,1),Hex::new(-1,1),0)]);
    let neutral=HiveMove::Move{piece:p(w,Bug::Beetle,1),from:Hex::new(-1,0),to:Hex::new(0,-1)};
    assert!(zero.legal_moves_all_actors().contains(&neutral));assert!(!oracle_moves(&zero,w).contains(&neutral));
    assert_eq!(ring_pressure_access(&zero,w).status,RingAccess::None);check_access(&zero,w);
    let mut b=dense(Color::White,true);let a=p(Color::White,Bug::Ant,2);
    b.make_generated(HiveMove::Move{piece:a,from:Hex::new(2,-1),to:Hex::new(1,0)});
    let mut writer=crate::wire::Writer::new();b.write_wire(&mut writer).unwrap();let bytes=writer.finish().unwrap();
    let mut reader=crate::wire::Reader::new(&bytes).unwrap();let imported=Board::read_wire(&mut reader).unwrap();
    assert_eq!(ring_pressure_access(&imported,Color::White).status,RingAccess::Unknown);
    let mut wide=Board::new(GameType::mlp());
    for mv in[HiveMove::Place{piece:p(Color::White,Bug::Queen,1),to:Hex::new(-16000,-16000)},
        HiveMove::Place{piece:p(Color::Black,Bug::Queen,1),to:Hex::new(16769,16769)},
        HiveMove::Place{piece:p(Color::White,Bug::Pillbug,1),to:Hex::new(-15999,-16000)},HiveMove::Pass]{wide.make_unchecked(mv).unwrap();}
    let mut writer=crate::wire::Writer::new();wide.write_wire(&mut writer).unwrap();let bytes=writer.finish().unwrap();
    let mut reader=crate::wire::Reader::new(&bytes).unwrap();let wide=Board::read_wire(&mut reader).unwrap();
    let before=format!("{wide:?}");assert_eq!(ring_pressure_access(&wide,Color::White).status,RingAccess::None);assert_eq!(format!("{wide:?}"),before);
    let mut edge=Board::new(GameType::base());edge.make_unchecked(HiveMove::Place{piece:p(Color::White,Bug::Queen,1),to:Hex::new(0,0)}).unwrap();edge.make_unchecked(HiveMove::Place{piece:p(Color::Black,Bug::Queen,1),to:Hex::new(i16::MAX,0)}).unwrap();
    assert_eq!(ring_pressure_access(&edge,Color::White).status,RingAccess::Unknown);
}
#[test]
fn unsupported_hostile_ring_is_flat_but_supported_and_terminal_are_retained() {
    for side in Color::ALL {
        let b=dense(side,false);let q=b.location(p(Color::Black,Bug::Queen,1)).unwrap();assert_eq!(ring(&b,q),4);
        assert!(q.neighbors().into_iter().filter_map(|h|b.top(h)).all(|p|p.color==Color::White));
        assert_eq!(ring_pressure_access(&b,Color::White).status,RingAccess::None);
        assert_eq!(reference_pressure_balance(&b),if enabled(){-200}else{0});assert_eq!(pressure_adjustment(&b,queen_counts(&b)),reference_pressure_balance(&b));
        let ready=dense(side,true);assert!(matches!(ring_pressure_access(&ready,Color::White).status,RingAccess::Found(_)));assert_eq!(pressure_adjustment(&ready,queen_counts(&ready)),reference_pressure_balance(&ready));
        assert_eq!(exact(&b,0),reference(&b,0));assert_eq!(exact(&ready,0),reference(&ready,0));
    }
}
#[test]
fn fully_deployed_marginal_pins_and_all_compile_label_bounds_are_exact() {
    let changed=enabled()&&development_weights_label()=="deployment_higher";let limit=if changed{284}else{128};assert_eq!(development_envelope(),limit);
    let(d,pin)=development_coefficients();
    for deployed in 0..=13 {for pins in 0..=13 {
        let expected=if changed{(d*i32::from(deployed)).min(128)+pin*i32::from(pins)}else{(d*i32::from(deployed)+pin*i32::from(pins)).min(128)};
        if development_weights_label()!="support_shortfall"{assert_eq!(development_benefit(deployed,pins),expected);}
        assert!((0..=limit).contains(&development_benefit(deployed,pins)));
    }}
    if changed{for pins in 0..13{assert_eq!(development_benefit(13,pins+1)-development_benefit(13,pins),12);}}
    for flags in 0..8 {
        let ty=GameType{mosquito:flags&1!=0,ladybug:flags&2!=0,pillbug:flags&4!=0};
        for c in Color::ALL {
            let maximum=Piece::all_for(c,ty).into_iter().filter(|p|p.bug!=Bug::Queen).count();
            assert!(maximum<=13);
            let independent=if changed{(10*maximum as i32).min(128)+12*maximum as i32}else{128};
            assert!(independent<=limit);
        }
    }
    let b=all_deployed();assert_eq!(development_balance(&b),if development_balance_enabled(){super::development_balance_contracts::reference_balance(&b)}else{0});
}
#[test]
fn independent_full_reference_and_lazy_uncertainty_windows_are_sound() {
    // All12 axial isometries, translation, both colors and actual sides;
    // the unsupported hostile ring has a NONZERO drop in the new mode.
    for original in[dense(Color::White,false),dense(Color::Black,true),donor(Color::White,true,false)] {
        for swap in[false,true]{for rotation in 0..6{for mirror in[false,true]{
            let b=transformed(&original,swap,rotation,mirror);
            assert_eq!(pressure_adjustment(&b,queen_counts(&b)),reference_pressure_balance(&b));
            assert_eq!(pressure_adjustment(&b,queen_counts(&b)),if swap{-reference_pressure_balance(&original)}else{reference_pressure_balance(&original)});
            assert_eq!(exact(&b,2),exact(&original,2));
            for color in Color::ALL{check_access(&b,color);}
        }}}
    }
    for mut b in[dense(Color::White,false),dense(Color::Black,true),donor(Color::White,true,false),own_queen(Color::Black),mate(Color::White,Color::White)] {
        for _ in 0..6 {
            let counts=queen_counts(&b);let exact=reference(&b,2);assert_eq!(self::exact(&b,2),exact);assert_eq!(evaluate_parts(&b,piece_total(&b)),evaluate(&b));
            let adjust=pressure_adjustment(&b,counts);assert_eq!(adjust,reference_pressure_balance(&b));let signed=if b.side_to_move()==Color::White{adjust}else{-adjust};let(lo,hi)=pressure_interval(&b,counts);assert!(lo<=signed&&signed<=hi);
            assert!(functional_defense_balance(&b).abs()<=strategy_bound());
            for(a,z)in[(-WIN-1,WIN+1),(exact-1,exact),(exact,exact+1),(exact-1000,exact-999),(exact+999,exact+1000)] {
                let found=evaluate_windowed_leaf(&b,piece_total(&b),2,counts,a,z);
                if found<=a{assert!(exact<=found);}else if found>=z{assert!(exact>=found);}else{assert_eq!(found,exact);}
            }
            if b.game_over(){break;}let moves=b.legal_moves_all_actors();b.make_generated(moves[0]);
        }
    }
}
#[test]
fn cached_delta_and_old_cheap_ordering_remain_explicit_approximation() {
    let mut b=dense(Color::White,true);let queens=Color::ALL.map(|c|b.location(p(c,Bug::Queen,1)));let counts=queen_counts(&b);let total=piece_total(&b);let before=Position::new(&b);
    for mv in b.legal_moves_all_actors() {
        let projected=projected_ranking_score(&b,mv,1,&queens,counts,total);let delta=piece_move_delta(&b,mv,&queens);let u=b.make_generated(mv);
        assert_eq!(if queen_moved(mv){piece_total(&b)}else{total+delta},piece_total(&b));
        if let Some(value)=projected{assert_eq!(value,-terminal(&b,1).unwrap_or_else(||evaluate_ordering(&b)));}
        assert_eq!(exact(&b,1),reference(&b,1));b.undo_generated(u);assert_eq!(Position::new(&b),before);
    }
    let stalled=dense(Color::White,false);if enabled(){assert_ne!(evaluate(&stalled)-evaluate_ordering(&stalled),functional_defense_balance(&stalled));}
}
#[test]
fn forced_win_countermate_and_both_color_safety_dominate_nonzero_terms() {
    for flags in 0..8 {for mover in Color::ALL {
        let ty=GameType{mosquito:flags&1!=0,ladybug:flags&2!=0,pillbug:flags&4!=0};
        let mut b=mate(mover,mover);
        if mover==Color::Black {b=transformed(&mate(Color::White,Color::White),true,0,false);}
        b=setup(ty,b.side_to_move(),&rows(&b));
        assert!(reference_pressure_balance(&b)!=0||!enabled());let before=Position::new(&b);
        let result=search(&b,SearchLimit::Depth(1));assert_eq!(result.score,Some(99_999));let u=b.make_generated(result.best_move.unwrap());
        assert!(b.queen_surrounded(mover.other()));assert_eq!(exact(&b,23),-100_000+23);b.undo_generated(u);assert_eq!(Position::new(&b),before);
        let mut forced=mate(mover.other(),mover);if mover==Color::Black{forced=transformed(&mate(Color::Black,Color::White),true,0,false);}
        forced=setup(ty,forced.side_to_move(),&rows(&forced));
        assert_eq!(forced.legal_moves(),vec![HiveMove::Pass]);let loss=search(&forced,SearchLimit::Depth(2));assert_eq!(loss.score,Some(-99_998));
    }}
}
#[test]
fn typed_history_513_queries_and_make_undo_restore_pressure_state() {
    let mut game=UhpGame::new(GameType::mlp());
    fn check(game:&mut UhpGame) {
        let state=game.raw_state_json();let history=game.exact_position_history().to_vec();
        for c in Color::ALL{check_access(game.board(),c);}
        assert_eq!(exact(game.board(),0),reference(game.board(),0));
        let _=search_with_history(game.board(),SearchLimit::Depth(1),&history);
        assert_eq!(game.raw_state_json(),state);
        for mv in game.board().legal_moves_all_actors().into_iter().take(2){game.play_raw_all_actors(mv).unwrap();game.undo(1).unwrap();assert_eq!(game.raw_state_json(),state);}
    }
    for(i,line)in include_str!("../../tests/long_game_raw_history.txt").lines().enumerate(){game.play_raw_all_actors(crate::uhp::raw_move_from_fields(line).unwrap()).unwrap();if[255,256,510].contains(&(i+1)){check(&mut game);}}
    let state=game.raw_state_json();let prefix=game.history().to_vec();
    for ply in[511,512,513] {
        let mv=game.board().legal_moves_all_actors().into_iter().find(|&m|{let mut c=game.clone();c.play_raw_all_actors(m).unwrap();c.state()==crate::GameState::InProgress}).unwrap();game.play_raw_all_actors(mv).unwrap();assert_eq!(game.board().ply(),ply);assert_eq!(&game.history()[..510],prefix.as_slice());check(&mut game);
    }
    game.undo(3).unwrap();assert_eq!(game.raw_state_json(),state);
}
#[test]
#[ignore="root-admitted fixed synthetic/public ABBA diagnostic only"]
fn pin_pressure_diagnostic() {
    let cases=vec![("dense_unsupported_hostile_ring",dense(Color::White,false)),("supported_ring",dense(Color::White,true)),
        ("enemy_donor_pinned_actor",donor(Color::White,true,false)),("fully_deployed_pins",all_deployed()),
        ("actual_queen_cover",super::cautious_contracts::cover_board(Color::White)),("immediate_mate",mate(Color::White,Color::White)),("forced_countermate",mate(Color::Black,Color::White))];
    let mut cases:Vec<_>=cases.into_iter().map(|(n,b)|{let h=vec![Position::new(&b)];(n,b,h)}).collect();
    for count in[11,13] {let mut g=UhpGame::new(GameType::mlp());for line in include_str!("../../tests/cautious_public_pin_reply.raw").lines().take(count){g.play_raw_all_actors(crate::uhp::raw_move_from_fields(line).unwrap()).unwrap();}cases.push((if count==11{"public_before_pin"}else{"public_after_pin_reply"},g.board().clone(),g.exact_position_history().to_vec()));}
    for(name,b,history)in cases {
        println!("PIN_PRESSURE_CASE name={name} label={} base_leaf={} full_leaf={}",cautious_style_label(),evaluate_counted_base(&b,piece_total(&b),0,queen_counts(&b)),exact(&b,0));
        for depth in[3,4]{let r=search_with_history(&b,SearchLimit::Depth(depth),&history);println!("PIN_PRESSURE_SEARCH name={name} depth={depth} completed={} score={:?} raw_action={:?} nodes={} elapsed_ns={}",r.completed_depth,r.score,r.best_move,r.nodes,r.elapsed.as_nanos());}
    }
}
