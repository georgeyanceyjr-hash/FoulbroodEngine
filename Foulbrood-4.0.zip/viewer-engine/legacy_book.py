import json,subprocess
from pathlib import Path
from functools import lru_cache
ROOT=Path(__file__).resolve().parent
BOARD=str(ROOT/'book-board')
@lru_cache(maxsize=20000)
def snapshot(game):
 return json.loads(subprocess.check_output([BOARD,'snapshot',game],text=True,timeout=15))
def transform(q,r,i):
 if i>=6:q,r=r,q
 for _ in range(i%6):q,r=-r,q+r
 return q,r
def canonical(s):
 pieces=s['pieces'];choices=[]
 for i in range(12):
  rows=[(p['id'],*transform(p['q'],p['r'],i),p['level']) for p in pieces]
  anchor=min(rows) if rows else ('',0,0,0);oq,orr=anchor[1:3]
  rows=sorted((p,q-oq,r-orr,l) for p,q,r,l in rows)
  choices.append((json.dumps(rows,separators=(',',':')),i,oq,orr))
 raw,i,oq,orr=min(choices)
 moves=s['game'].split(';')[3:];last=moves[-1].split()[0] if moves else None
 return json.dumps([s['game'].split(';')[0],s['side'],s['ply'],last,raw],separators=(',',':')),[x[1:] for x in choices if x[0]==raw]
def action_key(m,t):
 if isinstance(t,list):return min(action_key(m,x) for x in t)
 i,q,r=t
 dest=None if m.get('to') is None else transform(*m['to'],i)
 return json.dumps([m['piece'],None if dest is None else [dest[0]-q,dest[1]-r],m.get('actor')],separators=(',',':'))
def lookup(game,book,rng=None,cache=None):
 import random
 rng=random if rng is None else rng
 s=snapshot(game)
 if s['ply']>=book['max_plies'] or s['state'] not in ['NotStarted','InProgress']:return None
 key,t=canonical(s);e=book['entries'].get(key)
 if not e:return None
 legal={}
 for m in s['legal']:
  if s['ply']<2 and m['piece'] in ['wQ','bQ']:continue
  legal.setdefault(action_key(m,t),m['move'])
 choices=[c for c in e['choices'] if c['action'] in legal]
 if not choices:return None
 if cache is not None and game in cache:
  return legal.get(cache[game])
 total=sum(c['weight'] for c in choices)
 draw=rng.randrange(total)
 for c in choices:
  draw-=c['weight']
  if draw<0:
   if cache is not None:cache[game]=c['action']
   return legal[c['action']]
 raise AssertionError('Invalid book weights')
