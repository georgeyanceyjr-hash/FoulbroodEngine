// One source of features for labels and runtime ordering. No outcome input.
pub const FEATURE_COUNT:usize=22;
pub const FEATURE_VERSION:&str="residual-refuter-context-v1";
pub(super) fn feature_vector(board:&Board,mv:HiveMove,depth:u8,ply:u8,alpha:i32,beta:i32,
    prefix_count:usize,hce_index:usize,tail_len:usize,tt_hit:bool)->[f64;FEATURE_COUNT]{
    let bit=|x:bool|if x{1.0}else{0.0};
    let side=board.side_to_move();let own=board.location(Piece::new(side,Bug::Queen,1));
    let enemy=board.location(Piece::new(side.other(),Bug::Queen,1));
    let (kind,actor,piece,from,to)=match mv{
        HiveMove::Place{piece,to}=>(0,piece,piece,None,Some(to)),
        HiveMove::Move{piece,from,to}=>(1,piece,piece,Some(from),Some(to)),
        HiveMove::Pillbug{actor,piece,from,to}=>(2,actor,piece,Some(from),Some(to)),
        HiveMove::Pass=>(3,Piece::new(side,Bug::Queen,1),Piece::new(side,Bug::Queen,1),None,None),
    };
    let distance=|a:Option<crate::Hex>,b:Option<crate::Hex>|match(a,b){(Some(a),Some(b))=>a.distance(b) as f64/8.0,_=>0.0};
    let counts=queen_counts(board);let sign=if side==Color::White{1.0}else{-1.0};
    [1.0, f64::from(depth)/8.0,f64::from(ply)/8.0,f64::from(alpha.clamp(-1000,1000))/1000.0,
     f64::from(beta.clamp(-1000,1000))/1000.0,f64::from((beta-alpha).clamp(0,2000))/2000.0,
     prefix_count as f64/3.0,hce_index as f64/tail_len.max(1) as f64,(tail_len.min(256) as f64)/256.0,
     bit(kind==0),bit(kind==1),bit(kind==2),bit(kind==3),
     bit(piece.bug==Bug::Queen),bit(piece.bug==Bug::Ant),bit(actor.bug==Bug::Mosquito),
     if piece.color==side{1.0}else{-1.0},distance(to,enemy)-distance(from,enemy),
     distance(to,own)-distance(from,own),f64::from(counts[side.index()])/6.0,
     f64::from(counts[side.other().index()])/6.0,sign*bit(tt_hit)]
}
impl Snapshot{
    pub fn features(&self,index:usize)->Result<[f64;FEATURE_COUNT],String>{
        let mv=*self.tail.get(index).ok_or("feature raw index")?;
        let rank=self.hce_tail.as_ref().and_then(|v|v.iter().position(|&x|x==mv)).ok_or("feature HCE permutation")?;
        let key=Position::new(&self.board).key();
        let hit=self.table[(key as usize)&(self.table.len()-1)].is_some_and(|e|e.key==key&&e.position==Position::new(&self.board));
        Ok(feature_vector(&self.board,mv,self.depth,self.ply,self.alpha,self.beta,self.prefix.len(),rank,self.tail.len(),hit))
    }
}
