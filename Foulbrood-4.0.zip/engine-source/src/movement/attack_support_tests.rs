//! Snapshot feature contracts only, never actual-history or surround proofs.
//! The oracle enumerates the COMPLETE current-side actor domain, unlike the
//! production existence-only movement loops. Off-turn comparisons construct a
//! separate explicitly hypothetical setup with no last-turn stun; no pass or
//! side mutation is applied to the source Board.

use super::*;
use crate::GameType;
use std::collections::HashSet;

type Entry = (Piece, Hex, usize);

fn piece(color: Color, bug: Bug, number: u8) -> Piece {
    Piece::new(color, bug, number)
}
fn bit(p: Piece) -> u32 { 1_u32 << p.id() }
fn setup(variant: GameType, side: Color, entries: &[Entry], last: Option<Piece>) -> Board {
    Board::from_setup(variant, side, 10, entries,
        last.map(|p| (p, Hex::new(80, 80)))).unwrap()
}
fn entries(board: &Board) -> Vec<Entry> {
    board.occupied_stacks().flat_map(|(h, stack)| {
        stack.iter().copied().enumerate().map(move |(z, p)| (p, h, z))
    }).collect()
}

/// Distinct physical moved pieces, not actors, aliases, or destination count.
fn full_actor_oracle(board: &Board) -> AttackSupport {
    let color = board.side_to_move();
    let mut expected = AttackSupport::default();
    if board.game_over() { return expected; }
    let Some(target) = board.location(piece(color.other(), Bug::Queen, 1)) else {
        return expected;
    };
    let ring: HashSet<_> = target.neighbors().into_iter().collect();
    expected.target_present = true;
    expected.unfilled_ring = ring.iter().filter(|&&h| board.top(h).is_none()).count() as u8;
    if !board.queen_is_placed(color) { return expected; }
    for mv in board.legal_moves_all_actors() {
        let (physical, from, transport) = match mv {
            HiveMove::Move { piece, from, .. } => (piece, from, false),
            HiveMove::Pillbug { actor, piece, from, .. } => {
                assert_eq!(actor.color, color);
                (piece, from, true)
            }
            HiveMove::Place { .. } | HiveMove::Pass => continue,
        };
        if physical.color != color || physical.bug == Bug::Queen { continue; }
        assert_eq!(board.top(from), Some(physical));
        // Independent cell-occupancy formulation: a singleton ring source is
        // already filling a required cell. A lifted stack top leaves it filled.
        if ring.contains(&from) && board.stack(from).unwrap().len() == 1 { continue; }
        if transport { expected.transported_mask |= bit(physical); }
        else { expected.ordinary_mask |= bit(physical); }
    }
    expected
}

fn check_current(board: &Board) -> AttackSupport {
    let before = format!("{board:?}");
    let position = crate::position::Position::new(board);
    let legal = board.legal_moves_all_actors();
    let counters = Color::ALL.map(|c| board.turns_taken(c));
    let last = board.last_move();
    let actual = attack_support(board, board.side_to_move());
    assert_eq!(actual, full_actor_oracle(board), "{board:?}");
    assert!(!actual.potential_only);
    let combined = development_readiness_counts(board);
    let counts = development_counts(board);
    for color in Color::ALL {
        assert_eq!(combined[color.index()].0, counts[color.index()]);
        assert_eq!(combined[color.index()].1, attack_support(board, color));
    }
    assert_eq!(format!("{board:?}"), before);
    assert_eq!(crate::position::Position::new(board), position);
    assert_eq!(Color::ALL.map(|c| board.turns_taken(c)), counters);
    assert_eq!(board.last_move(), last);
    assert_eq!(board.legal_moves_all_actors(), legal);
    actual
}

fn component_count(board: &Board, omit: Option<Hex>) -> usize {
    let mut remaining: HashSet<_> = board.occupied_hexes().filter(|&h| Some(h) != omit).collect();
    let mut count = 0;
    while let Some(&start) = remaining.iter().next() {
        remaining.remove(&start);
        let mut work = vec![start];
        count += 1;
        while let Some(h) = work.pop() {
            for next in h.neighbors() {
                if remaining.remove(&next) { work.push(next); }
            }
        }
    }
    count
}

fn pinned_actor(color: Color, bug: Bug, own_recipient: bool) -> (Board, Piece, Piece) {
    let actor = piece(color, bug, 1);
    let moved = piece(if own_recipient { color } else { color.other() }, Bug::Ant, 1);
    let mut rows = vec![(actor, Hex::ORIGIN, 0),
        (piece(color, Bug::Queen, 1), Hex::new(-1, 0), 0),
        (piece(color.other(), Bug::Queen, 1), Hex::new(1, 0), 0),
        (moved, Hex::new(0, -1), 0)];
    if bug == Bug::Mosquito {
        // Enemy donor is sufficient. It is not an own physical recipient.
        rows.push((piece(color.other(), Bug::Pillbug, 1), Hex::new(-1, 1), 0));
    }
    (setup(GameType::mlp(), color, &rows, None), actor, moved)
}

fn overlap(color: Color) -> Board {
    setup(GameType::mlp(), color, &[
        (piece(color, Bug::Queen, 1), Hex::new(-1, 0), 0),
        (piece(color, Bug::Pillbug, 1), Hex::ORIGIN, 0),
        (piece(color, Bug::Mosquito, 1), Hex::new(1, 0), 0),
        (piece(color.other(), Bug::Queen, 1), Hex::new(2, 0), 0),
        (piece(color, Bug::Ant, 1), Hex::new(0, 1), 0),
    ], None)
}

fn ring_top(color: Color, stacked: bool) -> (Board, Piece) {
    let top = piece(color, Bug::Beetle, 1);
    let mut rows = vec![
        (piece(color.other(), Bug::Queen, 1), Hex::ORIGIN, 0),
        (piece(color, Bug::Queen, 1), Hex::new(2, -1), 0),
        (piece(color.other(), Bug::Spider, 1), Hex::new(1, -1), 0),
    ];
    if stacked { rows.push((piece(color, Bug::Ant, 1), Hex::new(1, 0), 0)); }
    rows.push((top, Hex::new(1, 0), usize::from(stacked)));
    (setup(GameType::mlp(), color, &rows, None), top)
}

#[test]
fn current_side_pool_matches_complete_all_actor_oracle_on_fixed_snapshots() {
    for color in Color::ALL {
        let mut fixtures = vec![overlap(color), ring_top(color, false).0, ring_top(color, true).0];
        for bug in [Bug::Pillbug, Bug::Mosquito] {
            fixtures.push(pinned_actor(color, bug, true).0);
            fixtures.push(pinned_actor(color, bug, false).0);
        }
        for board in fixtures { check_current(&board); }
    }
}

#[test]
fn pinned_pillbug_and_mosquito_enable_own_recipients_without_counting_actor() {
    for color in Color::ALL { for bug in [Bug::Pillbug, Bug::Mosquito] {
        let (board, actor, moved) = pinned_actor(color, bug, true);
        assert!(component_count(&board, Some(Hex::ORIGIN)) > component_count(&board, None));
        let exact = HiveMove::Pillbug { actor, piece: moved, from: Hex::new(0, -1), to: Hex::new(1, -1) };
        assert!(board.legal_moves_all_actors().contains(&exact), "{color:?} {bug:?}");
        let f = check_current(&board);
        assert_eq!(f.transported_mask & bit(moved), bit(moved));
        assert_eq!(f.ordinary_mask & bit(actor), 0);
        assert_eq!(f.available_mask() & bit(actor), 0);
    }}
}

#[test]
fn enemy_only_transports_do_not_turn_stationary_own_actor_into_filler() {
    for color in Color::ALL { for bug in [Bug::Pillbug, Bug::Mosquito] {
        let (board, actor, enemy) = pinned_actor(color, bug, false);
        let exact = HiveMove::Pillbug { actor, piece: enemy, from: Hex::new(0, -1), to: Hex::new(1, -1) };
        assert!(board.legal_moves_all_actors().contains(&exact));
        let f = check_current(&board);
        assert_eq!(f.available_mask(), 0, "Enemy-only ability is not an own moved-piece resource");
        assert_eq!(f.transported_mask & bit(enemy), 0);
    }}
}

#[test]
fn recipient_union_deduplicates_two_actors_multiple_destinations_and_ordinary_mode() {
    for color in Color::ALL {
        let board = overlap(color);
        let ant = piece(color, Bug::Ant, 1);
        let from = Hex::new(0, 1); let to = Hex::new(1, -1);
        let all = board.legal_moves_all_actors();
        for bug in [Bug::Pillbug, Bug::Mosquito] {
            assert!(all.contains(&HiveMove::Pillbug { actor: piece(color, bug, 1), piece: ant, from, to }));
        }
        assert!(all.contains(&HiveMove::Move { piece: ant, from, to }));
        assert!(all.iter().filter(|mv| matches!(mv, HiveMove::Move { piece, .. } if *piece == ant)).count() > 1);
        let f = check_current(&board);
        assert_eq!(f.transported_mask, bit(ant));
        assert_eq!(f.ordinary_mask & bit(ant), bit(ant));
        assert_eq!(f.available_mask(), bit(ant));
    }
}

#[test]
fn singleton_ring_source_is_excluded_but_top_leaving_occupied_stack_is_available() {
    for color in Color::ALL {
        let (single, top) = ring_top(color, false);
        assert!(single.legal_moves_all_actors().iter().any(|mv| matches!(mv, HiveMove::Move { piece, .. } if *piece == top)));
        assert_eq!(check_current(&single).available_mask() & bit(top), 0);
        let (stacked, top) = ring_top(color, true);
        assert!(stacked.legal_moves_all_actors().iter().any(|mv| matches!(mv, HiveMove::Move { piece, .. } if *piece == top)));
        let f = check_current(&stacked);
        assert_eq!(f.ordinary_mask & bit(top), bit(top));
        assert_eq!(f.available_mask() & bit(piece(color, Bug::Ant, 1)), 0);
        assert_eq!(stacked.stack(Hex::new(1, 0)).unwrap().len(), 2);
    }
}

#[test]
fn covered_recipients_covered_actors_and_reserve_pieces_are_not_free_support() {
    for color in Color::ALL {
        let (base, actor, ant) = pinned_actor(color, Bug::Pillbug, true);
        for (covered, h) in [(ant, Hex::new(0, -1)), (actor, Hex::ORIGIN)] {
            let mut rows = entries(&base);
            rows.push((piece(color.other(), Bug::Beetle, 1), h, 1));
            let board = setup(GameType::mlp(), color, &rows, None);
            let f = check_current(&board);
            assert_eq!(f.available_mask() & bit(covered), 0);
            assert_eq!(f.transported_mask & bit(ant), 0);
            assert_eq!(f.available_mask() & bit(piece(color, Bug::Ladybug, 1)), 0);
        }
    }
}

#[test]
fn current_stun_and_offturn_structural_potential_are_distinct_without_source_mutation() {
    for color in Color::ALL {
        let (clean, actor, ant) = pinned_actor(color, Bug::Pillbug, true);
        assert_ne!(check_current(&clean).transported_mask & bit(ant), 0);
        let rows = entries(&clean);
        let recipient_stunned = setup(GameType::mlp(), color, &rows, Some(ant));
        assert_eq!(check_current(&recipient_stunned).available_mask() & bit(ant), 0);
        let actor_stunned = setup(GameType::mlp(), color, &rows, Some(actor));
        assert_eq!(check_current(&actor_stunned).transported_mask & bit(ant), 0);
        let offturn = setup(GameType::mlp(), color.other(), &rows, Some(ant));
        let before = format!("{offturn:?}");
        let counters = Color::ALL.map(|c| offturn.turns_taken(c));
        let actual = attack_support(&offturn, color);
        let mut expected = full_actor_oracle(&clean); expected.potential_only = true;
        assert_eq!(actual, expected);
        assert!(actual.potential_only);
        assert_eq!(offturn.last_physically_moved_piece(), Some(ant));
        assert_eq!(format!("{offturn:?}"), before);
        assert_eq!(Color::ALL.map(|c| offturn.turns_taken(c)), counters);
        check_current(&offturn);
    }
}

#[test]
fn target_own_queen_and_terminal_gates_do_not_invent_support() {
    let white = Color::White; let black = Color::Black;
    let no_target = Board::from_setup(GameType::mlp(), white, 2,
        &[(piece(white, Bug::Queen, 1), Hex::ORIGIN, 0)], None).unwrap();
    assert_eq!(check_current(&no_target), AttackSupport::default());
    let missing_own = Board::from_setup(GameType::mlp(), white, 3, &[
        (piece(black, Bug::Queen, 1), Hex::ORIGIN, 0),
        (piece(white, Bug::Ant, 1), Hex::new(1, 0), 0)], None).unwrap();
    let f = check_current(&missing_own);
    assert!(f.target_present && f.unfilled_ring > 0);
    assert_eq!(f.available_mask(), 0);
    assert_eq!(f.available_mask() & bit(piece(white, Bug::Queen, 1)), 0);
    let mut rows = vec![(piece(black, Bug::Queen, 1), Hex::ORIGIN, 0),
        (piece(white, Bug::Queen, 1), Hex::new(-2, 0), 0)];
    let bugs = [Bug::Ant, Bug::Spider, Bug::Grasshopper];
    for (i, h) in Hex::ORIGIN.neighbors().into_iter().enumerate() {
        rows.push((piece(if i % 2 == 0 { white } else { black }, bugs[i / 2], 1), h, 0));
    }
    let terminal = setup(GameType::mlp(), white, &rows, None);
    assert!(terminal.game_over());
    assert_eq!(check_current(&terminal), AttackSupport::default());
}

#[test]
fn covered_target_stays_present_and_mobile_own_queen_is_never_extra_support() {
    for color in Color::ALL {
        let own_queen = piece(color, Bug::Queen, 1);
        let top = piece(color, Bug::Beetle, 1);
        let board = setup(GameType::mlp(), color, &[
            (piece(color.other(), Bug::Queen, 1), Hex::ORIGIN, 0),
            (top, Hex::ORIGIN, 1),
            (piece(color.other(), Bug::Spider, 1), Hex::new(1, -1), 0),
            (own_queen, Hex::new(2, -1), 0),
        ], None);
        assert!(board.legal_moves_all_actors().iter().any(|mv|
            matches!(mv, HiveMove::Move { piece, .. } if *piece == own_queen)));
        let f = check_current(&board);
        assert!(f.target_present);
        assert_eq!(f.unfilled_ring, 5);
        assert_eq!(f.available_mask() & bit(own_queen), 0);
        assert_eq!(f.ordinary_mask & bit(top), bit(top));
    }
}

#[test]
fn active_variant_inventory_and_shared_development_counts_match_full_oracle() {
    for mask in 0..8 { for color in Color::ALL {
        let variant = GameType { mosquito: mask & 1 != 0, ladybug: mask & 2 != 0, pillbug: mask & 4 != 0 };
        let mut rows = vec![(piece(color, Bug::Queen, 1), Hex::new(-1, 0), 0),
            (piece(color.other(), Bug::Queen, 1), Hex::new(2, 0), 0),
            (piece(color.other(), Bug::Spider, 1), Hex::ORIGIN, 0),
            (piece(color, Bug::Beetle, 1), Hex::new(1, 0), 0),
            (piece(color, Bug::Ant, 1), Hex::new(0, 1), 0)];
        for (bug, h) in [(Bug::Mosquito, Hex::new(1, -1)), (Bug::Ladybug, Hex::new(0, -1)),
                         (Bug::Pillbug, Hex::new(-1, 1))] {
            if variant.includes(bug) { rows.push((piece(color, bug, 1), h, 0)); }
        }
        let board = setup(variant, color, &rows, None);
        let f = check_current(&board);
        let active_mask = Piece::all_for(color, variant).into_iter().fold(0_u32, |m, p| m | bit(p));
        assert_eq!(f.available_mask() & !active_mask, 0);
        assert_eq!(f.available_mask() & bit(piece(color, Bug::Queen, 1)), 0);
    }}
}

fn swapped_mask(mask: u32) -> u32 {
    Color::ALL.into_iter().flat_map(|c| Piece::all_for(c, GameType::mlp())).fold(0, |m, p| {
        if mask & bit(p) == 0 { m } else { m | bit(piece(p.color.other(), p.bug, p.number)) }
    })
}

#[test]
fn color_swap_rotation_translation_and_reflection_preserve_physical_support_inventory() {
    let original = overlap(Color::White);
    let wanted = attack_support(&original, Color::White);
    for transform in 0..4 { for swap in [false, true] {
        let rows: Vec<_> = entries(&original).into_iter().map(|(p, h, z)| {
            let h = match transform { 0 => h, 1 => Hex::new(h.q + 17, h.r - 13),
                2 => Hex::new(-h.r, h.q + h.r), _ => Hex::new(h.r, h.q) };
            let p = if swap { piece(p.color.other(), p.bug, p.number) } else { p };
            (p, h, z)
        }).collect();
        let color = if swap { Color::Black } else { Color::White };
        let board = setup(GameType::mlp(), color, &rows, None);
        let actual = check_current(&board);
        assert_eq!(actual.target_present, wanted.target_present);
        assert_eq!(actual.unfilled_ring, wanted.unfilled_ring);
        assert_eq!(actual.ordinary_mask, if swap { swapped_mask(wanted.ordinary_mask) } else { wanted.ordinary_mask });
        assert_eq!(actual.transported_mask, if swap { swapped_mask(wanted.transported_mask) } else { wanted.transported_mask });
    }}
}

#[test]
fn generated_whole_actor_move_and_undo_restore_support_and_complete_board_snapshot() {
    for color in Color::ALL {
        let mut board = overlap(color);
        let mv = HiveMove::Pillbug { actor: piece(color, Bug::Pillbug, 1),
            piece: piece(color, Bug::Ant, 1), from: Hex::new(0, 1), to: Hex::new(1, -1) };
        assert!(board.legal_moves_all_actors().contains(&mv));
        let before = format!("{board:?}");
        let inventory = Color::ALL.map(|c| attack_support(&board, c));
        let position = crate::position::Position::new(&board);
        let undo = board.make_unchecked(mv).unwrap();
        check_current(&board);
        assert_eq!(board.last_move(), Some(mv));
        board.undo(undo).unwrap();
        assert_eq!(format!("{board:?}"), before);
        assert_eq!(crate::position::Position::new(&board), position);
        assert_eq!(Color::ALL.map(|c| attack_support(&board, c)), inventory);
        check_current(&board);
    }
}

#[test]
fn shortage_uses_distinct_piece_inventory_without_claiming_joint_hole_reachability() {
    let board = overlap(Color::White);
    let f = check_current(&board);
    assert!(f.unfilled_ring > 1);
    assert_eq!(f.available_mask().count_ones(), 1);
    assert_eq!(f.shortfall(), f.unfilled_ring - 1);
    assert!(f.needs_preparation());
    let mut enough = f;
    enough.ordinary_mask = (1_u32 << f.unfilled_ring) - 1;
    enough.transported_mask = enough.ordinary_mask;
    assert!(!enough.needs_preparation()); // duplicate modes do not add pieces
    assert_eq!(enough.shortfall(), 0);
    enough.target_present = false;
    enough.ordinary_mask = 0; enough.transported_mask = 0;
    assert!(!enough.needs_preparation());
    assert_eq!(enough.shortfall(), 0);
    let mut filled = f; filled.unfilled_ring = 0;
    assert!(!filled.needs_preparation());
    // This threshold test makes no assertion that independent movable pieces
    // can consecutively reach different holes or survive opponent replies.
}
