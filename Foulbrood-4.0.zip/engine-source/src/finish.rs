//! Explicit single-request completion allowance. Ordinary limits/results stay unchanged.
use super::*;

const MAX_MILLISECONDS: u64 = 86_400_000;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct CompletionBudget { soft_ms: u64, hard_ms: u64 }
impl CompletionBudget {
    pub fn new(soft_ms: u64, hard_ms: u64) -> Result<Self, String> {
        if soft_ms > hard_ms || hard_ms > MAX_MILLISECONDS {
            return Err("finish_ms requires 0 <= soft <= hard <= 86400000".into());
        }
        Ok(Self { soft_ms, hard_ms })
    }
    pub fn soft_ms(self) -> u64 { self.soft_ms }
    pub fn hard_ms(self) -> u64 { self.hard_ms }
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct CompletionMeta {
    pub extended: bool,
    pub finished: bool,
    pub goal_depth: Option<u8>,
}
impl CompletionMeta {
    pub fn json(self, budget: CompletionBudget) -> String {
        format!(r#"{{"soft_ms":{},"hard_ms":{},"extended":{},"finished":{},"goal_depth":{}}}"#,
            budget.soft_ms, budget.hard_ms, self.extended, self.finished,
            self.goal_depth.map_or("null".into(), |d| d.to_string()))
    }
}

#[derive(Clone, Debug)]
pub struct FinishResult {
    pub result: SearchResult,
    pub budget: CompletionBudget,
    pub completion: CompletionMeta,
    original_start: Instant,
}
impl FinishResult {
    /// Final serialization is charged to the SAME request, not a fresh timer.
    /// The transport must still charge its actual write/response wall time.
    pub(crate) fn check_publication(&self) -> Result<(), String> {
        check_publication(self.original_start, self.budget)
    }
}

fn check_publication(start: Instant, budget: CompletionBudget) -> Result<(), String> {
    // A zero allowance is the existing immediate legal fallback convention:
    // no search nodes, with unavoidable fallback/serialization overhead.
    if budget.hard_ms > 0 && start.elapsed() >= Duration::from_millis(budget.hard_ms) {
        return Err("finish_ms publication exceeded the original hard allowance".into());
    }
    Ok(())
}

pub(crate) fn partial_improver(incumbent: Option<HiveMove>, old_score: Option<i32>,
                    best: Option<HiveMove>, alpha: i32) -> bool {
    best.is_some() && best != incumbent
        && alpha > -WIN + i32::from(MAX_DEPTH)
        && !old_score.is_some_and(|v| v.abs() >= WIN - i32::from(MAX_DEPTH))
}

struct Gate {
    soft_phase: bool,
    soft_deadline: Option<crate::deadline::Deadline>,
    hard_deadline: Option<crate::deadline::Deadline>,
    #[cfg(test)] node_budget: Option<(u64, u64)>,
}
impl Gate {
    fn open(&mut self, worker: &mut Search, incumbent: Option<HiveMove>,
            old_score: Option<i32>, best: Option<HiveMove>, alpha: i32) -> bool {
        // No arbitrary error, observer phase deadline, or failed publication can
        // grant time. Only the original soft boundary may open this ONE gate.
        if !self.soft_phase || residual::phase_expired() || coverage::phase_expired()
            || !partial_improver(incumbent, old_score, best, alpha) {
            return false;
        }
        #[cfg(test)]
        let at_soft = self.node_budget.map(|(soft, _)| worker.nodes >= soft)
            .unwrap_or_else(|| self.soft_deadline.is_some_and(|d| d.expired()));
        #[cfg(not(test))]
        let at_soft = self.soft_deadline.is_some_and(|d| d.expired());
        if !at_soft || self.hard_deadline.is_some_and(|d| d.expired()) { return false; }
        #[cfg(test)]
        if self.node_budget.is_some_and(|(_, hard)| worker.nodes >= hard) { return false; }
        worker.deadline = self.hard_deadline;
        #[cfg(test)]
        if let Some((_, hard)) = self.node_budget { worker.node_limit = Some(hard); }
        self.soft_phase = false;
        true
    }
}

pub(crate) fn search_with_progress(board: &Board, history: &[Position], budget: CompletionBudget,
    progress: impl FnMut(&SearchResult, &CompletionMeta) -> Result<(), String>) -> Result<FinishResult, String> {
    #[cfg(test)]
    { run(board, history, budget, None, progress) }
    #[cfg(not(test))]
    { run(board, history, budget, progress) }
}

/// Explicit threaded Finish; one thread delegates directly to the original run.
/// The origin precedes every parallel allocation, hash, clone and worker spawn.
pub(crate) fn search_with_threads_and_progress(board: &Board, history: &[Position],
    budget: CompletionBudget, threads: u8,
    mut progress: impl FnMut(&SearchResult, &CompletionMeta) -> Result<(), String>)
    -> Result<FinishResult,String>
{
    if threads==1 {return search_with_progress(board,history,budget,progress);}
    let start=Instant::now();
    parallel::validate_threads(threads)?;
    if residual::is_active() || coverage::is_active() {
        return Err("finish_ms cannot run inside a snapshot/census observer".into());
    }
    if trained::mode()!="original" {return Err("finish_ms requires original compile mode".into());}
    validate_search_headroom(board,SearchLimit::Time(Duration::from_millis(budget.hard_ms)))?;
    let stop_at=|ms| {
        let time=Duration::from_millis(ms);
        crate::deadline::Deadline::at(start.checked_add(time.saturating_sub((time/20).min(Duration::from_millis(10))))
            .unwrap_or(start))
    };
    let (result,completion)=parallel::finish(board,history,threads,start,stop_at(budget.soft_ms),
        stop_at(budget.hard_ms),budget.soft_ms<budget.hard_ms,|row,meta| {
            progress(row,meta)?;
            check_publication(start,budget)
        })?;
    let finished=FinishResult{result,budget,completion,original_start:start};
    finished.check_publication()?;
    Ok(finished)
}

fn run(board: &Board, history: &[Position], budget: CompletionBudget,
    #[cfg(test)] node_budget: Option<(u64, u64)>,
    mut progress: impl FnMut(&SearchResult, &CompletionMeta) -> Result<(), String>) -> Result<FinishResult, String> {
    let start = Instant::now();
    if residual::is_active() || coverage::is_active() {
        return Err("finish_ms cannot run inside a snapshot/census observer".into());
    }
    if trained::mode() != "original" { return Err("finish_ms requires original compile mode".into()); }
    validate_search_headroom(board, SearchLimit::Time(Duration::from_millis(budget.hard_ms)))?;
    let stop_at = |ms| {
        let time = Duration::from_millis(ms);
        crate::deadline::Deadline::at(start.checked_add(time.saturating_sub((time / 20).min(Duration::from_millis(10))))
            .unwrap_or(start))
    };
    let mut gate = Gate { soft_phase: budget.soft_ms < budget.hard_ms,
        soft_deadline: Some(stop_at(budget.soft_ms)), hard_deadline: Some(stop_at(budget.hard_ms)),
        #[cfg(test)] node_budget };
    #[cfg(test)]
    if let Some((soft, hard)) = node_budget {
        if soft > hard { return Err("invalid deterministic node budget".into()); }
        gate.soft_phase = soft < hard; gate.soft_deadline = None; gate.hard_deadline = None;
    }
    trained::start_search();
    let mut worker = Search { history: Some(history.to_vec()), killers: [[None; 2]; 65],
        table: vec![None; 16384], deadline: gate.soft_deadline, nodes: 0,
        #[cfg(test)] node_limit: node_budget.map(|(soft, _)| soft) };
    let mut result = SearchResult { best_move: None, score: terminal(board, 0),
        completed_depth: 0, nodes: 0, elapsed: Duration::ZERO };
    let mut completion = CompletionMeta::default();
    let root_position = Position::new(board);
    if result.score.is_none() && history.iter().filter(|p| root_position.same_repetition(p, board)).take(3).count() == 3 {
        result.score = Some(0);
    }
    if result.score.is_none() {
        let mut moves = board.legal_moves();
        result.best_move = moves.first().copied();
        let mut position = board.clone();
        let root_queens = Color::ALL.map(|c| board.location(Piece::new(c, Bug::Queen, 1)));
        let root_total = piece_total_q(board, &root_queens);
        let root_counts = queen_counts(board);
        for depth in 1..=MAX_DEPTH {
            if worker.expired() { break; }
            if depth == 2 && worker.order_moves(&mut position, &mut moves, 0).is_err() { break; }
            if let Some(i) = moves.iter().position(|m| Some(*m) == result.best_move) { moves.swap(0, i); }
            let mut best = None;
            let mut alpha = -WIN - 1;
            let mut complete = true;
            let mut index = 0;
            while index < moves.len() {
                if worker.expired() {
                    if gate.open(&mut worker, result.best_move, result.score, best, alpha) {
                        completion.extended = true; completion.goal_depth = Some(depth);
                    } else { complete = false; break; }
                }
                let mv = moves[index];
                let delta = piece_move_delta(&position, mv, &root_queens);
                let next_counts = projected_queen_counts(&position, mv, &root_queens, root_counts);
                let undo = position.make_generated(mv);
                let child_counts = next_counts.unwrap_or_else(|| queen_counts(&position));
                let child_total = if queen_moved(mv) { piece_total(&position) } else { root_total + delta };
                let child = worker.negamax_parts(&mut position, depth - 1, 1, -WIN - 1, -alpha,
                    child_total, child_counts, Some(mv));
                position.undo_generated(undo);
                match child {
                    Ok(value) => { let score = -value; if score > alpha { alpha = score; best = Some(mv); } index += 1; }
                    Err(()) => {
                        #[cfg(test)] {
                            assert_eq!(worker.history.as_deref(), Some(history));
                            assert_eq!(Position::new(&position), root_position);
                        }
                        if gate.open(&mut worker, result.best_move, result.score, best, alpha) {
                            completion.extended = true; completion.goal_depth = Some(depth);
                            // Retry SAME raw child/window, from restored state, with
                            // the same worker/table/killers/cumulative node count.
                            continue;
                        }
                        complete = false; break;
                    }
                }
            }
            if !complete {
                if partial_improver(result.best_move, result.score, best, alpha) {
                    result.best_move = best; result.score = None;
                }
                break;
            }
            result.best_move = best.or(result.best_move); result.score = Some(alpha);
            result.completed_depth = depth; result.nodes = worker.nodes; result.elapsed = start.elapsed();
            if completion.extended { completion.finished = true; }
            // Publication errors abort the request, never reopen any allowance.
            progress(&result, &completion)?;
            check_publication(start, budget)?;
            if completion.extended || alpha.abs() >= WIN - i32::from(MAX_DEPTH) { break; }
        }
    }
    result.nodes = worker.nodes; result.elapsed = start.elapsed();
    let finished = FinishResult { result, budget, completion, original_start: start };
    finished.check_publication()?;
    Ok(finished)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{GameType, UhpGame};

    fn budget() -> CompletionBudget { CompletionBudget::new(86_400_000,86_400_000).unwrap() }
    fn worker(nodes:u64) -> Search {
        Search {history:None,table:vec![None;64],killers:[[None;2];65],deadline:None,
            nodes,node_limit:Some(5)}
    }
    fn node_gate() -> Gate {
        Gate {soft_phase:true,soft_deadline:None,hard_deadline:None,node_budget:Some((5,10))}
    }
    fn archived(plies:usize) -> UhpGame {
        let line=include_str!("../tests/archive_repetition.txt").lines().next().unwrap();
        let mut game=UhpGame::new(GameType::mlp());
        for text in line.split('|').nth(2).unwrap().split(';').take(plies) {game.play(text).unwrap();}
        game
    }

    #[test]
    fn budget_and_partial_improver_require_explicit_safe_allowances() {
        assert!(CompletionBudget::new(5,4).is_err());
        assert!(CompletionBudget::new(0,86_400_001).is_err());
        assert_eq!(CompletionBudget::new(0,0).unwrap().soft_ms(),0);
        assert_eq!(CompletionBudget::new(5,10).unwrap().hard_ms(),10);
        let moves=Board::new(GameType::base()).legal_moves();
        let (old,new)=(Some(moves[0]),Some(moves[1]));
        assert!(!partial_improver(old,Some(0),None,1));
        assert!(!partial_improver(old,Some(0),old,1));
        assert!(!partial_improver(old,Some(WIN-3),new,1));
        assert!(!partial_improver(old,Some(-WIN+3),new,1));
        assert!(!partial_improver(old,Some(0),new,-WIN+i32::from(MAX_DEPTH)));
        assert!(partial_improver(old,Some(0),new,1));
    }

    #[test]
    fn only_actual_soft_expiry_opens_one_cumulative_hard_allowance() {
        let moves=Board::new(GameType::base()).legal_moves();
        let (old,new)=(Some(moves[0]),Some(moves[1]));
        let mut worker=worker(4);let mut gate=node_gate();
        assert!(!gate.open(&mut worker,old,Some(0),new,1),"not at soft boundary");
        assert_eq!(worker.node_limit,Some(5));
        worker.nodes=5;assert!(worker.expired());
        assert!(gate.open(&mut worker,old,Some(0),new,1));
        assert_eq!(worker.nodes,5);assert_eq!(worker.node_limit,Some(10));
        assert!(!worker.expired());assert!(!gate.soft_phase);
        assert!(!gate.open(&mut worker,old,Some(0),new,1));
        worker.nodes=10;gate.soft_phase=true;
        assert!(!gate.open(&mut worker,old,Some(0),new,1));assert!(worker.expired());
    }

    #[test]
    fn hard_wall_and_publication_checks_never_restart_the_original_clock() {
        let moves=Board::new(GameType::base()).legal_moves();
        let mut worker=worker(5);let mut gate=node_gate();
        gate.hard_deadline=Some(crate::deadline::Deadline::at(Instant::now()));
        assert!(!gate.open(&mut worker,Some(moves[0]),Some(0),Some(moves[1]),1));
        assert!(gate.soft_phase);assert_eq!(worker.node_limit,Some(5));
        let before=Instant::now()-Duration::from_secs(2);
        assert!(check_publication(before,CompletionBudget::new(1,1000).unwrap()).is_err());
        assert!(check_publication(before,CompletionBudget::new(0,0).unwrap()).is_ok());
    }

    #[test]
    fn deterministic_real_search_finishes_one_goal_or_retains_unscored_partial() {
        if trained::mode()!="original" {return;}
        let mut completed=0;let mut interrupted=0;
        // Exactly the historical six DEV literals, now with COMPLETE actual
        // played Position history; no Board-only reconstruction or fit data.
        for root in include_str!("../tests/finish_iteration_positions.txt").lines() {
            let game=UhpGame::from_game_string(root).unwrap();let board=game.board();
            let history=game.exact_position_history();let before=game.raw_state_json();
            let full=game.search(SearchLimit::Depth(3));
            for fraction in 1..20 {
                let soft=(full.nodes*fraction/20).max(1);let hard=soft*4;
                let plain=search_with_progress_limited(board,SearchLimit::Depth(MAX_DEPTH),history,Some(soft),|_|{});
                let mut reports=Vec::new();
                let run=run(board,history,budget(),Some((soft,hard)),|row,meta| {
                    reports.push((row.clone(),*meta));Ok(())
                }).unwrap();
                let result=&run.result;assert!(result.nodes<=hard);
                assert_eq!(game.raw_state_json(),before);
                assert!(board.legal_moves().contains(&result.best_move.unwrap()));
                if run.completion.extended {
                    assert!(plain.score.is_none(),"ordinary partial improver is the only trigger");
                    let goal=run.completion.goal_depth.unwrap();
                    assert!(reports.iter().all(|(r,_)|r.completed_depth<=goal));
                    if run.completion.finished {
                        completed+=1;assert_eq!(result.completed_depth,goal);
                        assert_eq!(reports.last().unwrap().0.nodes,result.nodes,"no deeper work after goal");
                        let exact=game.search(SearchLimit::Depth(goal));
                        assert_eq!((result.best_move,result.score),(exact.best_move,exact.score));
                        assert!(result.score.is_some());
                    } else {
                        interrupted+=1;assert!(result.completed_depth<goal);
                        assert!(result.score.is_none(),"partial selected line has no attached complete score");
                    }
                } else {
                    assert!(!run.completion.finished);assert_eq!(run.completion.goal_depth,None);
                    assert_eq!((result.best_move,result.score,result.completed_depth,result.nodes),
                        (plain.best_move,plain.score,plain.completed_depth,plain.nodes));
                }
                // Disabling extension must match the unchanged ordinary path
                // under the SAME cumulative node boundary and full history.
                let equal=run_without_extension(board,history,soft);
                assert_eq!((equal.best_move,equal.score,equal.completed_depth,equal.nodes),
                    (plain.best_move,plain.score,plain.completed_depth,plain.nodes));
            }
        }
        assert!(completed>0,"actual successful one-goal completion exercised");
        assert!(interrupted>0,"actual hard interruption/restoration exercised");
    }
    fn run_without_extension(board:&Board,history:&[Position],nodes:u64)->SearchResult {
        run(board,history,budget(),Some((nodes,nodes)),|_,_|Ok(())).unwrap().result
    }

    #[test]
    fn zero_soft_never_uses_the_hard_allowance_and_preserves_full_history() {
        if trained::mode()!="original" {return;}
        let game=archived(17);let before=game.raw_state_json();
        let expected=game.search(SearchLimit::Time(Duration::ZERO));
        for hard in [0,1000] {
            let actual=game.finish_with_progress(CompletionBudget::new(0,hard).unwrap(),|_,_|panic!("no iteration")).unwrap();
            assert_eq!((actual.result.best_move,actual.result.score,actual.result.completed_depth,actual.result.nodes),
                (expected.best_move,expected.score,expected.completed_depth,expected.nodes));
            assert_eq!(actual.completion,CompletionMeta::default());
            assert_eq!(game.raw_state_json(),before);
        }
    }

    #[test]
    fn progress_error_aborts_immediately_without_reopening_or_live_mutation() {
        if trained::mode()!="original" {return;}
        let game=archived(17);let before=game.raw_state_json();let mut reports=0;
        let error=run(game.board(),game.exact_position_history(),budget(),Some((100_000,400_000)),|row,meta| {
            reports+=1;assert_eq!(row.completed_depth,1);assert!(!meta.extended);
            Err("synthetic durable progress publication failure".into())
        }).unwrap_err();
        assert_eq!(reports,1);assert!(error.contains("synthetic durable progress"));
        assert_eq!(game.raw_state_json(),before);
    }

    #[test]
    fn active_snapshot_and_census_observers_are_always_refused_before_work() {
        // Deliberately also runs in the trained build: observer refusal is
        // unconditional, not conditional on which evaluator is compiled.
        let game=archived(17);let before=game.raw_state_json();let b=CompletionBudget::new(0,0).unwrap();
        let config=residual::CaptureConfig {generation_depth:6,remaining_depth:5,original_search_ply:1,
            minimum_tail:8,maximum_tail:4096,absolute_deadline:Instant::now()+Duration::from_secs(30)};
        let captured=residual::capture_with_progress(&game,config,|_| {
            assert!(game.finish_with_progress(b,|_,_|panic!("refuse before callback")).unwrap_err().contains("observer"));
            assert!(game.finish_with_threads_and_progress(b,4,|_,_|panic!("refuse threaded observer")).unwrap_err().contains("observer"));
            Err("stop original snapshot fixture after its actual first row".into())
        }).unwrap();
        assert!(captured.error.is_some());assert!(!residual::is_active());
        let census=coverage::census(&game,Instant::now()+Duration::from_secs(30),|_| {
            assert!(game.finish_with_progress(b,|_,_|panic!("refuse before callback")).unwrap_err().contains("observer"));
            assert!(game.finish_with_threads_and_progress(b,4,|_,_|panic!("refuse threaded observer")).unwrap_err().contains("observer"));
            Err("stop census fixture after its actual first row".into())
        }).unwrap();
        assert!(census.error.is_some());assert!(!coverage::is_active());assert_eq!(game.raw_state_json(),before);
    }

    #[test]
    fn original_threefold_history_is_kept_and_trained_mode_is_refused() {
        let game=archived(17);let before=game.raw_state_json();
        if trained::mode()!="original" {
            assert!(game.finish_with_progress(budget(),|_,_|panic!("no trained Finish")).unwrap_err().contains("original compile mode"));
            assert_eq!(game.raw_state_json(),before);return;
        }
        let line=include_str!("../tests/archive_repetition.txt").lines().next().unwrap();
        let end=line.split('|').nth(1).unwrap().parse().unwrap();let repeated=archived(end);
        let expected=repeated.search(SearchLimit::Time(Duration::ZERO));
        let actual=repeated.finish_with_progress(CompletionBudget::new(0,0).unwrap(),|_,_|panic!("terminal history")).unwrap();
        assert_eq!((actual.result.best_move,actual.result.score,actual.result.nodes),(expected.best_move,Some(0),0));
        assert_eq!(actual.completion,CompletionMeta::default());assert_eq!(game.raw_state_json(),before);
    }

    #[test]
    fn finite_ply_headroom_is_rejected_before_search_or_callback() {
        if trained::mode()!="original" {return;}
        // Storage-only diagnostic, not a legal-game or repetition claim.
        let mut board=Board::new(GameType::base());
        for _ in 0..u16::MAX {board.make_unchecked(HiveMove::Pass).unwrap();}
        let before=format!("{board:?}");let history=[Position::new(&board)];let mut called=false;
        let error=search_with_progress(&board,&history,CompletionBudget::new(0,0).unwrap(),|_,_|{called=true;Ok(())}).unwrap_err();
        assert!(error.contains("headroom"));assert!(!called);assert_eq!(format!("{board:?}"),before);
    }

    #[test]
    fn threaded_zero_soft_keeps_legal_fallback_and_original_serial_delegate() {
        let game=archived(19);let before=game.raw_state_json();
        if trained::mode()!="original" {
            for threads in [1,2,4,8,12] {
                assert!(game.finish_with_threads_and_progress(CompletionBudget::new(0,0).unwrap(),threads,
                    |_,_|panic!("no trained Finish callback")).unwrap_err().contains("original compile mode"));
            }
            assert_eq!(game.raw_state_json(),before);return;
        }
        let expected=game.search(SearchLimit::Time(Duration::ZERO));
        for threads in [1,2,4,8,12] {for hard in [0,1000] {
            let actual=game.finish_with_threads_and_progress(CompletionBudget::new(0,hard).unwrap(),threads,
                |_,_|panic!("zero soft cannot complete an iteration")).unwrap();
            assert_eq!((actual.result.best_move,actual.result.score,actual.result.completed_depth,actual.result.nodes),
                (expected.best_move,expected.score,expected.completed_depth,expected.nodes));
            assert_eq!(actual.completion,CompletionMeta::default());
            if threads>1 {
                let stats=parallel::report_json(threads,actual.result.nodes);
                assert!(stats.contains("\"spawned\":0")&&stats.contains("\"joined\":0"));
            }
        }}
        let old=game.finish_with_progress(CompletionBudget::new(0,0).unwrap(),|_,_|panic!()).unwrap();
        let new=game.finish_with_threads_and_progress(CompletionBudget::new(0,0).unwrap(),1,|_,_|panic!()).unwrap();
        assert_eq!((old.result.best_move,old.result.score,old.result.completed_depth,old.result.nodes,old.completion),
            (new.result.best_move,new.result.score,new.result.completed_depth,new.result.nodes,new.completion));
        assert_eq!(game.raw_state_json(),before);
    }

    #[test]
    fn invalid_threaded_count_never_allocates_search_or_calls_progress() {
        let game=archived(19);let before=game.raw_state_json();
        for threads in [0,13,255] {
            assert!(game.finish_with_threads_and_progress(CompletionBudget::new(0,0).unwrap(),threads,
                |_,_|panic!("invalid count cannot publish")).unwrap_err().contains("Threads requires"));
        }
        assert_eq!(game.raw_state_json(),before);
    }
}
