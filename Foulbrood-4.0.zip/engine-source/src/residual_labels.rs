//! Opt-in LABEL-FEASIBILITY draft, never a move-ordering or fitting interface.
//! The original scalar search is wrapped with its ORIGINAL window. A completed
//! scalar is a conservative window envelope, not necessarily an exact value.
use super::*;
use crate::UhpGame;
use std::cell::RefCell;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum BoundKind { Exact, Lower, Upper }

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct ScoreBound { pub score: i32, pub kind: BoundKind }

impl ScoreBound {
    pub fn from_window(score: i32, alpha: i32, beta: i32) -> Result<Self, String> {
        if !(-WIN-1..=WIN+1).contains(&alpha) || !(-WIN-1..=WIN+1).contains(&beta)
            || alpha >= beta || !(-WIN-1..=WIN+1).contains(&score) {
            return Err("invalid original window or returned score".into());
        }
        Ok(Self { score, kind: if score <= alpha { BoundKind::Upper }
            else if score >= beta { BoundKind::Lower } else { BoundKind::Exact } })
    }
    pub fn negate(self) -> Self {
        Self { score: -self.score, kind: match self.kind {
            BoundKind::Exact => BoundKind::Exact,
            BoundKind::Lower => BoundKind::Upper,
            BoundKind::Upper => BoundKind::Lower,
        }}
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum RefuterLabel { CertifiedRefuter, CertifiedNonRefuter, Unknown }

pub fn refuter_label(parent: ScoreBound, beta: i32) -> RefuterLabel {
    match parent.kind {
        BoundKind::Exact => if parent.score >= beta { RefuterLabel::CertifiedRefuter }
            else { RefuterLabel::CertifiedNonRefuter },
        BoundKind::Lower if parent.score >= beta => RefuterLabel::CertifiedRefuter,
        BoundKind::Upper if parent.score < beta => RefuterLabel::CertifiedNonRefuter,
        _ => RefuterLabel::Unknown,
    }
}

#[derive(Clone, Debug)]
pub struct CaptureConfig {
    pub generation_depth: u8,
    pub remaining_depth: u8,
    pub original_search_ply: u8,
    pub minimum_tail: usize,
    pub maximum_tail: usize,
    pub absolute_deadline: Instant,
}

impl CaptureConfig {
    fn validate(&self) -> Result<(), String> {
        if self.generation_depth != 6 || self.remaining_depth != 5
            || self.original_search_ply != 1 || self.minimum_tail != 8
            || self.maximum_tail == 0 || self.maximum_tail > 4096 {
            return Err("this draft admits only fixed D6 / first D5-ply1 / tail>=8, cap<=4096".into());
        }
        if self.absolute_deadline <= Instant::now() { return Err("expired capture phase".into()); }
        Ok(())
    }
}

#[derive(Clone, Debug)]
pub struct PrefixResult {
    pub raw_move: HiveMove,
    pub entry_alpha: i32,
    pub beta: i32,
    pub child: ScoreBound,
    pub parent: ScoreBound,
}

/// All search state is owned and deep-cloned, not a live shared-TT reference.
pub struct Snapshot {
    pub root_literal: String,
    pub root_raw_history: Vec<HiveMove>,
    pub generated_path: Vec<HiveMove>,
    pub depth: u8,
    pub ply: u8,
    pub entry_alpha: i32,
    pub alpha: i32,
    pub beta: i32,
    pub tail: Vec<HiveMove>,
    pub full_legal: Vec<HiveMove>,
    pub hce_tail: Option<Vec<HiveMove>>,
    pub prefix: Vec<PrefixResult>,
    board: Board,
    history: Vec<Position>,
    table: Vec<Option<Entry>>,
    killers: [[Option<HiveMove>; 2]; 65],
    total: i32,
    counts: [u8; 2],
    nodes_at_capture: u64,
    absolute_deadline: Instant,
    transport_original_hard_unix_ms: Option<u64>,
}

pub struct Generation {
    pub result: SearchResult,
    pub snapshot: Option<Snapshot>,
    pub error: Option<String>,
}

struct State {
    transport_probe_deadline: Option<(Instant,u64)>,
    config: CaptureConfig,
    root_literal: String,
    root_raw_history: Vec<HiveMove>,
    path: Vec<HiveMove>,
    snapshot: Option<Snapshot>,
    error: Option<String>,
}

thread_local! { static ACTIVE: RefCell<Option<State>> = const { RefCell::new(None) }; }

/// FULL UhpGame only: setup/Board-only roots are rejected. No source selection,
/// family guard, TRAIN release or external physical proof is performed here.
pub fn capture(game: &UhpGame, config: CaptureConfig) -> Result<Generation, String> {
    config.validate()?;
    let literal = game.game_string();
    if literal.split(';').next().is_some_and(|h| h.contains('~'))
        || game.history().len() != usize::from(game.board().ply())
        || game.history().len() < 8 || game.history().len() > 248 {
        return Err("full actual history of 8..248 plies required".into());
    }
    ACTIVE.with(|cell| {
        let mut active = cell.borrow_mut();
        if active.is_some() { return Err("nested capture is prohibited".to_string()); }
        *active = Some(State { transport_probe_deadline: None, config: config.clone(), root_literal: literal,
            root_raw_history: game.history().to_vec(), path: Vec::new(), snapshot: None, error: None });
        Ok(())
    })?;
    let result = game.search(SearchLimit::Depth(config.generation_depth));
    let state = ACTIVE.with(|cell| cell.borrow_mut().take()).expect("capture scope installed");
    if !state.path.is_empty() { return Err("generation raw path failed to unwind".into()); }
    Ok(Generation { result, snapshot: state.snapshot, error: state.error })
}

/// New opt-in frontend: every ACTUAL completed iteration is offered to the
/// caller's durable sink. A sink error sets the same State.error checked by
/// Search::expired; no search window/order/history changes or fallback follow.
/// The callback runs without an ACTIVE RefCell borrow. Original capture and
/// Snapshot::probe_raw remain separate and unchanged.
pub fn capture_with_progress(game: &UhpGame, config: CaptureConfig,
    progress: impl FnMut(&SearchResult) -> Result<(), String>) -> Result<Generation, String> {
    capture_progress_inner(game,config,None,progress)
}
/// New transport-only entry: generation has its own earlier cap, while the
/// retained Snapshot belongs to ONE prospectively frozen common campaign end.
pub fn capture_for_transport(game:&UhpGame,config:CaptureConfig,original_probe_deadline:Instant,original_hard_unix_ms:u64,
    progress:impl FnMut(&SearchResult)->Result<(),String>)->Result<Generation,String>{
    if original_probe_deadline<config.absolute_deadline{return Err("probe horizon precedes capture phase".into());}
    capture_progress_inner(game,config,Some((original_probe_deadline,original_hard_unix_ms)),progress)
}
fn capture_progress_inner(game: &UhpGame, config: CaptureConfig, transport_probe_deadline:Option<(Instant,u64)>,
    mut progress: impl FnMut(&SearchResult) -> Result<(), String>) -> Result<Generation, String> {
    config.validate()?;
    let literal = game.game_string();
    if literal.split(';').next().is_some_and(|h| h.contains('~'))
        || game.history().len() != usize::from(game.board().ply())
        || game.history().len() < 8 || game.history().len() > 248 {
        return Err("full actual history of 8..248 plies required".into());
    }
    let end = config.absolute_deadline;
    ACTIVE.with(|cell| {
        let mut active = cell.borrow_mut();
        if active.is_some() { return Err("nested capture is prohibited".to_string()); }
        *active = Some(State { transport_probe_deadline, config: config.clone(), root_literal: literal,
            root_raw_history: game.history().to_vec(), path: Vec::new(), snapshot: None, error: None });
        Ok(())
    })?;
    let result = game.search_with_progress(SearchLimit::Depth(config.generation_depth), |row| {
        // Persist the actual completed row before deciding whether its sink or
        // cost failed. The next existing expiry check unwinds the same search.
        let published = progress(row);
        let error = published.err().map(|e| format!("progress publication failed: {e}"))
            .or_else(|| (Instant::now() >= end).then(|| "progress publication reached original phase deadline".to_string()));
        if let Some(error) = error {
            ACTIVE.with(|cell| {
                if let Some(state) = cell.borrow_mut().as_mut() {
                    if state.error.is_none() { state.error = Some(error); }
                }
            });
        }
    });
    let mut state = ACTIVE.with(|cell| cell.borrow_mut().take()).expect("capture scope installed");
    if !state.path.is_empty() && state.error.is_none() {
        // Return the actual result to the frontend for durable final/partial
        // capture BEFORE it rejects this correctness failure.
        state.error = Some("generation raw path failed to unwind".into());
    }
    Ok(Generation { result, snapshot: state.snapshot, error: state.error })
}

impl Snapshot {
    /// Source metadata only; this accessor does not mutate the captured state.
    pub fn nodes_at_capture(&self) -> u64 { self.nodes_at_capture }
}

pub(super) fn phase_expired() -> bool {
    ACTIVE.with(|cell| cell.borrow().as_ref().is_some_and(|s|
        s.error.is_some() || Instant::now() >= s.config.absolute_deadline))
}

#[cfg(test)]
mod progress_contract_tests {
    use super::*;
    fn game_at(plies:usize)->UhpGame {
        let line=include_str!("../tests/archive_repetition.txt").lines().next().unwrap();
        let moves=line.split('|').nth(2).unwrap();
        let mut game=UhpGame::new(crate::GameType::mlp());
        for text in moves.split(';').take(plies) {game.play(text).unwrap();}
        game
    }
    fn config()->CaptureConfig {
        CaptureConfig {generation_depth:6,remaining_depth:5,original_search_ply:1,
            minimum_tail:8,maximum_tail:4096,absolute_deadline:Instant::now()+Duration::from_secs(60)}
    }
    #[test]
    fn progress_sink_error_keeps_actual_completed_iteration_and_unwinds() {
        let game=game_at(17);
        let ordinary=game.search(SearchLimit::Depth(1));
        let mut seen=Vec::new();
        let generated=capture_with_progress(&game,config(),|row| {
            // This borrow proves the callback is not called inside a held
            // ACTIVE RefCell borrow. The original state itself stays installed.
            assert!(ACTIVE.with(|cell|cell.borrow_mut().is_some()));
            seen.push((row.best_move,row.score,row.completed_depth,row.nodes));
            Err("synthetic durable sink failure".into())
        }).unwrap();
        assert_eq!(seen,vec![(ordinary.best_move,ordinary.score,1,ordinary.nodes)]);
        assert_eq!((generated.result.best_move,generated.result.score,generated.result.completed_depth,generated.result.nodes),seen[0]);
        assert!(generated.error.unwrap().contains("synthetic durable sink failure"));
        assert!(generated.snapshot.is_none());
        assert!(!is_active());
    }
    #[test]
    fn successful_progress_rows_preserve_ordinary_fullhistory_results() {
        let game=game_at(17);
        let ordinary=game.search(SearchLimit::Depth(2));
        let mut seen=Vec::new();
        let generated=capture_with_progress(&game,config(),|row| {
            seen.push((row.best_move,row.score,row.completed_depth,row.nodes));
            if row.completed_depth==2 {Err("fixed test stop AFTER durable depth2".into())} else {Ok(())}
        }).unwrap();
        assert_eq!(seen.len(),2);
        assert_eq!(seen[0].2,1);
        assert_eq!(seen[1],(ordinary.best_move,ordinary.score,2,ordinary.nodes));
        assert_eq!((generated.result.best_move,generated.result.score,generated.result.completed_depth,generated.result.nodes),seen[1]);
        assert!(generated.error.unwrap().contains("AFTER durable depth2"));
        assert!(generated.snapshot.is_none());
        assert!(!is_active());
    }
    #[test]
    fn progress_rejects_short_history_before_callback_or_active_scope() {
        let game=game_at(7);
        let mut called=false;
        assert!(capture_with_progress(&game,config(),|_|{called=true;Ok(())}).is_err());
        assert!(!called && !is_active());
    }
    #[test]
    fn raw_descriptor_preserves_actor_piece_and_pass_envelope() {
        let actor=Piece::new(Color::Black,Bug::Pillbug,1);
        let piece=Piece::new(Color::White,Bug::Ant,1);
        let from=crate::Hex::new(-2,1); let to=crate::Hex::new(-1,1);
        let expected=format!("{{\"kind\":2,\"actor\":{},\"piece\":{},\"from\":[-2,1],\"to\":[-1,1]}}",actor.id(),piece.id());
        assert_ne!(actor,piece);
        assert_eq!(raw_action_json(HiveMove::Pillbug{actor,piece,from,to}),expected);
        assert_eq!(raw_action_json(HiveMove::Pass),"{\"kind\":3,\"actor\":28,\"piece\":28,\"from\":null,\"to\":null}");
        assert_eq!(raw_action_json(HiveMove::Place{piece,to}),format!("{{\"kind\":0,\"actor\":{},\"piece\":{},\"from\":null,\"to\":[-1,1]}}",piece.id(),piece.id()));
        assert_eq!(raw_action_json(HiveMove::Move{piece,from,to}),format!("{{\"kind\":1,\"actor\":{},\"piece\":{},\"from\":[-2,1],\"to\":[-1,1]}}",piece.id(),piece.id()));
    }
}

pub(super) fn is_active() -> bool { ACTIVE.with(|cell| cell.borrow().is_some()) }

// Exact abs(beta)<WIN-MAX_DEPTH without an abs(i32::MIN) overflow path.
// This is entry-context selection BEFORE any residual child probe/label.
fn finite_cutoff_beta(beta:i32)->bool {
    beta > -WIN+i32::from(MAX_DEPTH) && beta < WIN-i32::from(MAX_DEPTH)
}

pub(super) fn push(mv: HiveMove) {
    ACTIVE.with(|cell| { if let Some(s) = cell.borrow_mut().as_mut() { s.path.push(mv); } });
}
pub(super) fn pop(mv: HiveMove) {
    ACTIVE.with(|cell| {
        if let Some(s) = cell.borrow_mut().as_mut() {
            if s.path.pop() != Some(mv) { s.error = Some("raw path pop mismatch".into()); }
        }
    });
}

/// FIRST eligible transition after preferred moves fail, BEFORE HCE tail sort.
pub(super) fn observe(worker: &Search, board: &Board, depth: u8, ply: u8,
    entry_alpha: i32, alpha: i32, beta: i32, total: i32, counts: [u8; 2],
    tail: &[HiveMove], full_legal:&[HiveMove], prefix: &[PrefixResult]) {
    ACTIVE.with(|cell| {
        let mut active = cell.borrow_mut();
        let Some(s) = active.as_mut() else { return; };
        if s.snapshot.is_some() || s.error.is_some() || depth != s.config.remaining_depth
            || ply != s.config.original_search_ply || tail.len() < s.config.minimum_tail
            || !finite_cutoff_beta(beta) { return; }
        if Color::ALL.iter().any(|&c| board.location(Piece::new(c, Bug::Queen, 1)).is_none()) { return; }
        if tail.len() > s.config.maximum_tail || s.path.len() != usize::from(ply)
            || worker.history.is_none() || alpha >= beta {
            s.error = Some("first residual context violates fixed capture contract".into());
            return;
        }
        s.snapshot = Some(Snapshot { root_literal: s.root_literal.clone(),
            root_raw_history: s.root_raw_history.clone(), generated_path: s.path.clone(),
            depth, ply, entry_alpha, alpha, beta, tail: tail.to_vec(),full_legal:full_legal.to_vec(), hce_tail:None, prefix: prefix.to_vec(),
            board: board.clone(), history: worker.history.clone().expect("checked Some"),
            table: worker.table.clone(), killers: worker.killers, total, counts,
            nodes_at_capture: worker.nodes, absolute_deadline: s.transport_probe_deadline.map_or(s.config.absolute_deadline,|x|x.0),
            transport_original_hard_unix_ms:s.transport_probe_deadline.map(|x|x.1) });
    });
}

pub(super) fn after_hce(depth:u8,ply:u8,ordered:&[HiveMove]) {
    ACTIVE.with(|cell| {
        let mut active=cell.borrow_mut();
        let Some(s)=active.as_mut() else{return};
        let Some(snapshot)=s.snapshot.as_mut() else{return};
        if snapshot.depth!=depth || snapshot.ply!=ply || snapshot.generated_path!=s.path {return;}
        let old:std::collections::HashSet<_>=snapshot.tail.iter().copied().collect();
        let new:std::collections::HashSet<_>=ordered.iter().copied().collect();
        if old!=new || old.len()!=snapshot.tail.len() || new.len()!=ordered.len() || snapshot.hce_tail.is_some() {
            s.error=Some("actual HCE tail is not one complete raw permutation at captured node".into());return;
        }
        snapshot.hce_tail=Some(ordered.to_vec());
    });
}

#[derive(Debug)]
pub struct ChildObservation {
    pub raw_index: usize,
    pub raw_move: HiveMove,
    pub child_alpha: i32,
    pub child_beta: i32,
    pub original_child_ply: u8,
    pub child_depth: u8,
    pub child_bound: Option<ScoreBound>,
    pub parent_bound: Option<ScoreBound>,
    pub label: RefuterLabel,
    pub node_delta: u64,
    pub clone_ns: u128,
    pub search_ns: u128,
    pub restore_check_ns: u128,
    pub whole_ns: u128,
    pub state_restored: bool,
    pub clone_start_exact: bool,
    pub disposable_storage_identical: bool,
    pub interrupted: bool,
    pub error: Option<String>,
}

impl Snapshot {
    /// Exact raw actors/indices, not shorthand aliases or invented GameStrings.
    pub fn raw_descriptors_json(&self)->String {
        let array=|moves:&[HiveMove]|format!("[{}]",moves.iter().map(|&mv|raw_action_json(mv)).collect::<Vec<_>>().join(","));
        format!("{{\"root_raw_history\":{},\"generated_path\":{},\"full_legal\":{},\"generator_tail\":{},\"actual_hce_tail\":{}}}",
            array(&self.root_raw_history),array(&self.generated_path),array(&self.full_legal),array(&self.tail),
            self.hce_tail.as_ref().map_or("null".into(),|moves|array(moves)))
    }
    /// Stable *source-pinned* field dump contract, not an engine GameString.
    /// Debug text includes every table slot/Entry/Position field and actual raw
    /// actor moves; independent binary/JSON witness encoding remains required.
    pub fn state_text(&self) -> String {
        format!("ROOT={:?}\nROOT_MOVES={:?}\nPATH={:?}\nBOARD={:?}\nHISTORY={:?}\nTT={:?}\nKILLERS={:?}\nDEPTH={}\nPLY={}\nENTRY_ALPHA={}\nALPHA={}\nBETA={}\nTOTAL={}\nCOUNTS={:?}\nNODES={}\nPREFIX={:?}\nGENERATOR_TAIL={:?}\nACTUAL_HCE_TAIL={:?}\nFULL_RAW_LEGAL={:?}\n",
            self.root_literal, self.root_raw_history, self.generated_path, self.board,
            self.history, self.table, self.killers, self.depth, self.ply, self.entry_alpha,
            self.alpha, self.beta, self.total, self.counts, self.nodes_at_capture, self.prefix, self.tail,self.hce_tail,self.full_legal)
    }

    /// The caller MUST durably save state_text + all tail slots before this API.
    /// Each invocation clones the SAME snapshot; no sibling probe state leaks.
    pub fn probe_raw(&self, raw_index: usize, child_end: Instant) -> Result<ChildObservation, String> {
        if ACTIVE.with(|cell| cell.borrow().is_some()) { return Err("probe capture callback must be disabled".into()); }
        if self.hce_tail.is_none() {return Err("actual captured-node HCE permutation missing".into());}
        let &mv = self.tail.get(raw_index).ok_or("raw index outside fixed tail")?;
        let started = Instant::now();
        let end = child_end.min(self.absolute_deadline);
        let mut worker = Search { history: Some(self.history.clone()), table: self.table.clone(),
            killers: self.killers, deadline: Some(crate::deadline::Deadline::at(end)),
            nodes: self.nodes_at_capture, #[cfg(test)] node_limit: None };
        let mut board = self.board.clone();
        let before_board = format!("{:?}", board);
        let logical_board=logical_board_text(&board);
        let before_history = worker.history.clone();
        let clone_start_exact=before_board==format!("{:?}",self.board)
            &&worker.history.as_ref()==Some(&self.history)&&worker.table==self.table&&worker.killers==self.killers;
        if !clone_start_exact{return Err("fresh child clone does not exactly match captured state".into());}
        let clone_ns = started.elapsed().as_nanos();
        let search_started = Instant::now();
        let queens = Color::ALL.map(|c| board.location(Piece::new(c, Bug::Queen, 1)));
        let delta = piece_move_delta(&board, mv, &queens);
        let next_counts = projected_queen_counts(&board, mv, &queens, self.counts);
        let undo = board.make_generated(mv);
        let child_counts = next_counts.unwrap_or_else(|| queen_counts(&board));
        let child_total = if queen_moved(mv) { piece_total(&board) } else { self.total + delta };
        let result = worker.negamax_parts(&mut board, self.depth-1, self.ply+1,
            -self.beta, -self.alpha, child_total, child_counts, Some(mv));
        board.undo_generated(undo);
        let search_ns = search_started.elapsed().as_nanos();
        let restore_started = Instant::now();
        let storage_identical=format!("{:?}",board)==before_board;
        let restored=logical_board_text(&board)==logical_board&&worker.history==before_history;
        let restore_check_ns = restore_started.elapsed().as_nanos();
        let mut row = ChildObservation { raw_index, raw_move: mv, child_alpha: -self.beta,
            child_beta: -self.alpha, original_child_ply: self.ply+1, child_depth: self.depth-1,
            child_bound: None, parent_bound: None, label: RefuterLabel::Unknown,
            node_delta: worker.nodes.checked_sub(self.nodes_at_capture).ok_or("node counter regressed")?,
            clone_ns, search_ns, restore_check_ns, whole_ns: started.elapsed().as_nanos(),
            state_restored: restored, clone_start_exact,disposable_storage_identical:storage_identical,
            interrupted: result.is_err(), error: None };
        if !restored { row.error = Some("exact Board/history restoration failed".into()); return Ok(row); }
        if let Ok(score) = result {
            let child = ScoreBound::from_window(score, -self.beta, -self.alpha)?;
            let parent = child.negate();
            row.child_bound = Some(child); row.parent_bound = Some(parent);
            row.label = refuter_label(parent, self.beta);
        }
        Ok(row)
    }
}

pub fn raw_action_json(mv:HiveMove)->String {
    let hex=|h:Option<crate::Hex>|h.map_or("null".into(),|h|format!("[{},{}]",h.q,h.r));
    let (kind,actor,piece,from,to)=match mv {
        HiveMove::Place{piece,to}=>(0,piece.id(),piece.id(),None,Some(to)),
        HiveMove::Move{piece,from,to}=>(1,piece.id(),piece.id(),Some(from),Some(to)),
        HiveMove::Pillbug{actor,piece,from,to}=>(2,actor.id(),piece.id(),Some(from),Some(to)),
        HiveMove::Pass=>(3,28,28,None,None),
    };
    format!("{{\"kind\":{},\"actor\":{},\"piece\":{},\"from\":{},\"to\":{}}}",kind,actor,piece,hex(from),hex(to))
}

fn logical_board_text(board:&Board)->String {
    format!("{:?}|{:?}|{:?}|{}|{}|{}|{:?}",Position::new(board),board.game_type(),
        board.side_to_move(),board.ply(),board.turns_taken(Color::White),board.turns_taken(Color::Black),board.last_move())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn finite_beta_selection_rejects_first_root_sentinel_and_mate_band() {
        let first_root_alpha=-WIN-1;
        assert!(!finite_cutoff_beta(-first_root_alpha));
        for beta in [-WIN-1,-WIN,-WIN+i32::from(MAX_DEPTH),WIN-i32::from(MAX_DEPTH),WIN,WIN+1,i32::MIN,i32::MAX] {
            assert!(!finite_cutoff_beta(beta));
        }
        for beta in [-995,-1,0,1,995,WIN-i32::from(MAX_DEPTH)-1,-WIN+i32::from(MAX_DEPTH)+1] {
            assert!(finite_cutoff_beta(beta));
        }
        // A finite beta admits both refuter and nonrefuter possibilities;
        // eligibility does not depend on either later label.
        assert_eq!(refuter_label(ScoreBound{score:51,kind:BoundKind::Exact},50),RefuterLabel::CertifiedRefuter);
        assert_eq!(refuter_label(ScoreBound{score:49,kind:BoundKind::Exact},50),RefuterLabel::CertifiedNonRefuter);
    }
    fn archived_mlp_prefix(plies:usize)->(UhpGame,Vec<Position>) {
        let line=include_str!("../tests/archive_repetition.txt").lines().next().unwrap();
        let texts=line.split('|').nth(2).unwrap();
        let mut game=UhpGame::new(crate::GameType::mlp());
        let mut history=vec![Position::new(game.board())];
        for text in texts.split(';').take(plies) {
            game.play(text).unwrap(); history.push(Position::new(game.board()));
        }
        (game,history)
    }
    // Separate full-width shallow oracle: no TT, killers, alpha-beta pruning,
    // windowed shortcut or incremental evaluation. History is still real.
    fn oracle(board: &mut Board, history: &mut Vec<Position>, depth: u8, ply: u8) -> i32 {
        let position = Position::new(board);
        let repeated = history.iter().filter(|p| position.same_repetition(p, board)).take(2).count() == 2;
        history.push(position);
        let answer = if let Some(v) = terminal(board, ply) { v }
            else if repeated { 0 }
            else if depth == 0 { evaluate(board) }
            else {
                let mut best = -WIN-1;
                for mv in board.legal_moves() {
                    let undo = board.make_generated(mv);
                    let score = -oracle(board, history, depth-1, ply+1);
                    board.undo_generated(undo);
                    best = best.max(score);
                }
                best
            };
        history.pop(); answer
    }

    #[test]
    fn complete_window_envelopes_contain_independent_shallow_oracle_at_equalities() {
        for depth in 0..=2 {
            let board = Board::new(crate::GameType::base());
            let exact = oracle(&mut board.clone(), &mut Vec::new(), depth, 3);
            for (alpha,beta) in [(exact-1,exact),(exact,exact+1),(exact-1,exact+1),(-101,-100),(100,101)] {
                let mut worker = Search { history: Some(Vec::new()), table: vec![None;64],
                    killers: [[None;2];65], deadline: None, nodes:0, node_limit:None };
                let score = worker.negamax(&mut board.clone(),depth,3,alpha,beta).unwrap();
                let typed = ScoreBound::from_window(score,alpha,beta).unwrap();
                match typed.kind {
                    BoundKind::Exact => assert_eq!(score,exact),
                    BoundKind::Lower => assert!(exact>=score),
                    BoundKind::Upper => assert!(exact<=score),
                }
                assert_eq!(worker.history,Some(Vec::new()));
            }
        }
    }

    #[test]
    fn real_mlp_history_both_queens_and_deployed_pillbug_match_fullwidth_oracle() {
        let (game,history)=archived_mlp_prefix(16);
        for color in Color::ALL {
            assert!(game.board().location(Piece::new(color,Bug::Queen,1)).is_some());
        }
        assert!(Color::ALL.into_iter().any(|c|game.board().location(Piece::new(c,Bug::Pillbug,1)).is_some()));
        let prior=history[..history.len()-1].to_vec();
        for depth in 0..=2 {
            let exact=oracle(&mut game.board().clone(),&mut prior.clone(),depth,5);
            for (alpha,beta) in [(exact-1,exact),(exact,exact+1),(exact-1,exact+1)] {
                let mut worker=Search{history:Some(prior.clone()),table:vec![None;64],
                    killers:[[None;2];65],deadline:None,nodes:0,node_limit:None};
                let score=worker.negamax(&mut game.board().clone(),depth,5,alpha,beta).unwrap();
                match ScoreBound::from_window(score,alpha,beta).unwrap().kind {
                    BoundKind::Exact=>assert_eq!(score,exact),
                    BoundKind::Lower=>assert!(exact>=score),
                    BoundKind::Upper=>assert!(exact<=score),
                }
                assert_eq!(worker.history,Some(prior.clone()));
            }
        }
    }

    #[test]
    fn terminal_search_envelope_keeps_actual_ply_in_mate_band() {
        let wq=Piece::new(Color::White,Bug::Queen,1);
        let bugs=[(Bug::Queen,1),(Bug::Spider,1),(Bug::Spider,2),
            (Bug::Beetle,1),(Bug::Beetle,2),(Bug::Grasshopper,1)];
        let mut pieces=vec![(wq,crate::Hex::new(0,0),0)];
        for ((bug,number),hex) in bugs.into_iter().zip(crate::Hex::new(0,0).neighbors()) {
            pieces.push((Piece::new(Color::Black,bug,number),hex,0));
        }
        let board=Board::from_setup(crate::GameType::base(),Color::White,8,&pieces,None).unwrap();
        for ply in [0,5,17] {
            let exact=-WIN+i32::from(ply);
            let mut worker=Search{history:Some(Vec::new()),table:vec![None;64],
                killers:[[None;2];65],deadline:None,nodes:0,node_limit:None};
            let value=worker.negamax(&mut board.clone(),2,ply,exact-1,exact+1).unwrap();
            assert_eq!(ScoreBound::from_window(value,exact-1,exact+1).unwrap(),ScoreBound{score:exact,kind:BoundKind::Exact});
        }
    }

    #[test]
    fn real_archived_repetition_and_inactive_observer_preserve_ordinary_results() {
        let line=include_str!("../tests/archive_repetition.txt").lines().next().unwrap();
        let end:usize=line.split('|').nth(1).unwrap().parse().unwrap();
        let (draw,history)=archived_mlp_prefix(end);
        assert_eq!(draw.state(),crate::GameState::Draw);
        let prior=history[..history.len()-1].to_vec();
        let mut worker=Search{history:Some(prior.clone()),table:vec![None;64],
            killers:[[None;2];65],deadline:None,nodes:0,node_limit:None};
        assert_eq!(worker.negamax(&mut draw.board().clone(),2,7,-1,1),Ok(0));
        assert_eq!(worker.history,Some(prior));
        let (game,_)=archived_mlp_prefix(16);
        let a=game.search(SearchLimit::Depth(2));
        ACTIVE.with(|cell|*cell.borrow_mut()=Some(State{transport_probe_deadline:None,config:CaptureConfig{
            generation_depth:6,remaining_depth:5,original_search_ply:1,minimum_tail:8,maximum_tail:4096,
            absolute_deadline:Instant::now()+Duration::from_secs(60)},root_literal:game.game_string(),
            root_raw_history:game.history().to_vec(),path:Vec::new(),snapshot:None,error:None}));
        let b=game.search(SearchLimit::Depth(2));
        let scope=ACTIVE.with(|cell|cell.borrow_mut().take()).unwrap();
        assert!(scope.path.is_empty() && scope.error.is_none() && scope.snapshot.is_none());
        assert_eq!((a.best_move,a.score,a.completed_depth,a.nodes),(b.best_move,b.score,b.completed_depth,b.nodes));
    }

    #[test]
    fn independent_child_clones_restore_even_on_interruption_and_do_not_share_tt() {
        let board = Board::new(crate::GameType::base());
        let snapshot = Snapshot { root_literal:"Base;NotStarted;White[1]".into(),
            root_raw_history:Vec::new(),generated_path:Vec::new(),depth:2,ply:3,
            entry_alpha:-100001,alpha:-100001,beta:100001,tail:board.legal_moves(),full_legal:board.legal_moves(),hce_tail:Some(board.legal_moves()),prefix:Vec::new(),
            history:vec![Position::new(&board)],board,table:vec![None;64],killers:[[None;2];65],
            total:0,counts:[0;2],nodes_at_capture:27,absolute_deadline:Instant::now()+Duration::from_secs(5),transport_original_hard_unix_ms:None };
        let before = snapshot.state_text();
        let first = snapshot.probe_raw(0,Instant::now()+Duration::from_secs(2)).unwrap();
        let second = snapshot.probe_raw(0,Instant::now()+Duration::from_secs(2)).unwrap();
        assert!(first.state_restored && second.state_restored);
        assert_eq!(first.child_bound,second.child_bound);
        assert_eq!(first.node_delta,second.node_delta);
        let expired = snapshot.probe_raw(0,Instant::now()-Duration::from_millis(1)).unwrap();
        assert!(expired.interrupted && expired.state_restored);
        assert_eq!(expired.label,RefuterLabel::Unknown);
        assert_eq!(expired.child_bound,None);
        assert_eq!(snapshot.state_text(),before);
    }

    #[test]
    fn full_history_repetition_return_is_sound_under_original_ply_window() {
        let board = Board::new(crate::GameType::base());
        let p = Position::new(&board);
        let mut worker = Search { history:Some(vec![p,p]),table:vec![None;64],
            killers:[[None;2];65],deadline:None,nodes:0,node_limit:None };
        let value = worker.negamax(&mut board.clone(),3,7,-1,1).unwrap();
        assert_eq!(ScoreBound::from_window(value,-1,1).unwrap(),ScoreBound{score:0,kind:BoundKind::Exact});
        assert_eq!(worker.history,Some(vec![p,p]));
    }
    #[test]
    fn bound_negation_and_equality_do_not_turn_unknown_into_negative() {
        let b = 20;
        assert_eq!(refuter_label(ScoreBound { score:20, kind:BoundKind::Lower }, b), RefuterLabel::CertifiedRefuter);
        assert_eq!(refuter_label(ScoreBound { score:20, kind:BoundKind::Upper }, b), RefuterLabel::Unknown);
        assert_eq!(refuter_label(ScoreBound { score:19, kind:BoundKind::Upper }, b), RefuterLabel::CertifiedNonRefuter);
        assert_eq!(refuter_label(ScoreBound { score:19, kind:BoundKind::Lower }, b), RefuterLabel::Unknown);
        assert_eq!(ScoreBound { score:-20, kind:BoundKind::Upper }.negate(), ScoreBound { score:20, kind:BoundKind::Lower });
        assert!(ScoreBound::from_window(0, 1, 1).is_err());
    }
    #[test]
    fn mate_normalization_preserves_original_search_ply() {
        for ply in [0,1,6,63] {
            for score in [WIN-12,-WIN+12,83,-41] {
                assert_eq!(load_score(store_score(score,ply),ply),score);
            }
        }
    }
}

include!("residual_transport.rs");

include!("residual_features.rs");

#[cfg(test)]
#[path = "trained_feature_tests.rs"]
mod trained_feature_tests;
